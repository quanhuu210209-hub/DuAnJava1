<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Người dùng — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Quản lý người dùng</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header"><span></span><a href="${pageContext.request.contextPath}/admin/user?action=new" class="btn-solid">+ Thêm người dùng</a></div>
    <div class="table-card"><table>
        <thead><tr><th>ID</th><th>Họ tên</th><th>Email</th><th>SĐT</th><th>Vai trò</th><th>Chi nhánh</th><th>Trạng thái</th><th>Đăng nhập gần nhất</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="u" items="${users}">
            <tr>
                <td>${u.userId}</td>
                <td><c:out value="${u.fullName}"/></td>
                <td><c:out value="${u.email}"/></td>
                <td><c:out value="${u.phone}"/></td>
                <td><c:out value="${u.role.roleName}"/></td>
                <td><c:out value="${u.branch.branchName}"/></td>
                <td>${u.active ? 'Hoạt động' : 'Đã khóa'}</td>
                <td><t:dt value="${u.lastLoginAt}"/></td>
                <td>
                    <a href="${pageContext.request.contextPath}/admin/user?action=edit&id=${u.userId}" class="btn-xs ghost">Sửa</a>
                    <c:if test="${u.active and u.userId != sessionScope.loginUser.userId}">
                        <form method="post" action="${pageContext.request.contextPath}/admin/user" class="inline"
                              onsubmit="return confirm('Khóa tài khoản này?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="${u.userId}">
                            <button type="submit" class="btn-xs danger">Khóa</button>
                        </form>
                    </c:if>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
