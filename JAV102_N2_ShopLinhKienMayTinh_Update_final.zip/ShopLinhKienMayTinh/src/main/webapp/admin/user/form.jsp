<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<c:set var="isNew" value="${editUser.userId == 0}"/>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Người dùng — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>${isNew ? 'Thêm người dùng' : 'Sửa người dùng'}</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="post" action="${pageContext.request.contextPath}/admin/user" data-validate data-one-of="email,phone">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="userId" value="${editUser.userId}">
        <div class="form-row">
            <label for="fullName">Họ tên *</label>
            <input id="fullName" name="fullName" type="text" value="<c:out value='${editUser.fullName}'/>"
                   required maxlength="100" data-label="Họ tên">
            <span class="field-error" data-for="fullName"><c:out value="${errors.fullName}"/></span>
        </div>
        <div class="form-row">
            <label for="email">Email</label>
            <input id="email" name="email" type="text" value="<c:out value='${editUser.email}'/>"
                   maxlength="150" data-type="email" data-label="Email">
            <span class="field-error" data-for="email"><c:out value="${errors.email}"/></span>
        </div>
        <div class="form-row">
            <label for="phone">Số điện thoại</label>
            <input id="phone" name="phone" type="text" value="<c:out value='${editUser.phone}'/>"
                   data-type="phone" data-label="Số điện thoại">
            <span class="field-error" data-for="phone"><c:out value="${errors.phone}"/></span>
        </div>
        <div class="form-row">
            <label for="roleId">Vai trò *</label>
            <select id="roleId" name="roleId" required data-label="Vai trò">
                <option value="">-- Chọn vai trò --</option>
                <c:forEach var="r" items="${roles}">
                    <option value="${r.roleId}" data-code="${r.roleCode}" ${editUser.roleId == r.roleId ? 'selected' : ''}><c:out value="${r.roleName}"/></option>
                </c:forEach>
            </select>
            <span class="field-error" data-for="roleId"><c:out value="${errors.roleId}"/></span>
        </div>
        <div class="form-row" id="branchRow">
            <label for="branchId">Chi nhánh (bắt buộc với Quản lý/Nhân viên)</label>
            <select id="branchId" name="branchId" data-label="Chi nhánh">
                <option value="">-- Chọn chi nhánh --</option>
                <c:forEach var="b" items="${branches}">
                    <option value="${b.branchId}" ${editUser.branchId == b.branchId ? 'selected' : ''}><c:out value="${b.branchName}"/></option>
                </c:forEach>
            </select>
            <span class="field-error" data-for="branchId"><c:out value="${errors.branchId}"/></span>
        </div>
        <div class="form-row">
            <label for="password">Mật khẩu ${isNew ? '*' : '(để trống nếu không đổi)'}</label>
            <input id="password" name="password" type="password" minlength="6" maxlength="72"
                   ${isNew ? 'required' : ''} data-label="Mật khẩu" autocomplete="new-password">
            <span class="field-error" data-for="password"><c:out value="${errors.password}"/></span>
        </div>
        <div class="form-row">
            <label><input type="checkbox" name="active" ${editUser.active ? 'checked' : ''}> Tài khoản đang hoạt động</label>
        </div>
        <button type="submit">Lưu</button>
        <a href="${pageContext.request.contextPath}/admin/user">Hủy</a>
    </form>

  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
<script src="${pageContext.request.contextPath}/assets/js/admin/user-form.js"></script>
</body>
</html>
