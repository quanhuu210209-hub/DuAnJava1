<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cấu hình hệ thống — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Cấu hình hệ thống</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="table-card"><table>
        <thead><tr><th>Khóa</th><th>Mô tả</th><th>Giá trị</th><th>Cập nhật</th></tr></thead>
        <tbody>
        <c:forEach var="x" items="${settings}">
            <tr>
                <td><c:out value="${x.settingKey}"/></td>
                <td><c:out value="${x.description}"/></td>
                <td>
                    <form method="post" action="${pageContext.request.contextPath}/admin/setting" class="inline">
                        <input type="hidden" name="settingKey" value="${x.settingKey}">
                        <input type="text" name="settingValue" value="<c:out value='${x.settingValue}'/>" required maxlength="500">
                        <button type="submit" class="btn-xs ghost">Lưu</button>
                    </form>
                </td>
                <td><t:dt value="${x.updatedAt}"/></td>
            </tr>
        </c:forEach>
        <c:if test="${empty settings}"><tr><td colspan="4">Chưa có cấu hình.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
