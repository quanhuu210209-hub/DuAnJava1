<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Nhật ký hệ thống — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Nhật ký hệ thống</h1>
    </div>
  </div>

  <div class="content">
    <div class="page-header">
      <form method="get" action="${pageContext.request.contextPath}/admin/audit" class="inline">
        <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Tìm đối tượng, chi tiết hoặc người thực hiện...">
        <select name="action">
          <option value="">Tất cả hành động</option>
          <c:forEach var="a" items="${actions}">
            <option value="${a}" ${action == a ? 'selected' : ''}><c:out value="${a}"/></option>
          </c:forEach>
        </select>
        <button type="submit" class="btn-xs ghost">Lọc</button>
      </form>
    </div>
    <div class="table-card"><table>
        <thead><tr><th>Thời điểm</th><th>Người thực hiện</th><th>Hành động</th><th>Đối tượng</th><th>Mã</th><th>Chi tiết</th></tr></thead>
        <tbody>
        <c:forEach var="l" items="${logs}">
            <tr>
                <td><t:dt value="${l.createdAt}"/></td>
                <td><c:out value="${empty l.user ? 'Hệ thống' : l.user.fullName}"/></td>
                <td><c:out value="${l.action}"/></td>
                <td><c:out value="${l.entityType}"/></td>
                <td><c:out value="${l.entityId}"/></td>
                <td><c:out value="${l.detail}"/></td>
            </tr>
        </c:forEach>
        <c:if test="${empty logs}"><tr><td colspan="6">Chưa có nhật ký.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
