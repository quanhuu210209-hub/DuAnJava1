<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<c:set var="isNew" value="${category.categoryId == 0}"/>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Danh mục — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>${isNew ? 'Thêm danh mục' : 'Sửa danh mục'}</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="post" action="${pageContext.request.contextPath}/admin/category" data-validate>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="categoryId" value="${category.categoryId}">
        <div class="form-row">
            <label for="categoryName">Tên danh mục *</label>
            <input id="categoryName" name="categoryName" type="text" value="<c:out value='${category.categoryName}'/>"
                   required maxlength="100" data-label="Tên danh mục">
            <span class="field-error" data-for="categoryName"><c:out value="${errors.categoryName}"/></span>
        </div>
        <div class="form-row">
            <label for="description">Mô tả</label>
            <input id="description" name="description" type="text" value="<c:out value='${category.description}'/>"
                   maxlength="255" data-label="Mô tả">
            <span class="field-error" data-for="description"><c:out value="${errors.description}"/></span>
        </div>
        <div class="form-row">
            <label><input type="checkbox" name="active" ${category.active ? 'checked' : ''}> Đang sử dụng</label>
        </div>
        <button type="submit">Lưu</button>
        <a href="${pageContext.request.contextPath}/admin/category">Hủy</a>
    </form>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>
