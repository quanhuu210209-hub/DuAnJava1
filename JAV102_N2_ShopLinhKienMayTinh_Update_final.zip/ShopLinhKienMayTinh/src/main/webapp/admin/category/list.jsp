<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Danh mục — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Danh mục sản phẩm</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header"><span></span><a href="${pageContext.request.contextPath}/admin/category?action=new" class="btn-solid">+ Thêm danh mục</a></div>
    <div class="table-card"><table>
        <thead><tr><th>ID</th><th>Tên danh mục</th><th>Mô tả</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="c" items="${categories}">
            <tr>
                <td>${c.categoryId}</td>
                <td><c:out value="${c.categoryName}"/></td>
                <td><c:out value="${c.description}"/></td>
                <td>${c.active ? 'Đang dùng' : 'Ẩn'}</td>
                <td>
                    <a href="${pageContext.request.contextPath}/admin/category?action=edit&id=${c.categoryId}" class="btn-xs ghost">Sửa</a>
                    <form method="post" action="${pageContext.request.contextPath}/admin/category" class="inline"
                          onsubmit="return confirm('Xóa danh mục này?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="${c.categoryId}">
                        <button type="submit" class="btn-xs danger">Xóa</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty categories}"><tr><td colspan="5">Chưa có danh mục.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
