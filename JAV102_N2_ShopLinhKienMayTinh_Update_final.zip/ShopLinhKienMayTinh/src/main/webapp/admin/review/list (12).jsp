<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Kiểm duyệt đánh giá — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Kiểm duyệt đánh giá</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="get" action="${pageContext.request.contextPath}/admin/review" class="filter-form">
        <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Tìm theo sản phẩm hoặc nội dung">
        <select name="status">
            <option value="">-- Tất cả --</option>
            <option value="visible" ${status == 'visible' ? 'selected' : ''}>Đang hiện</option>
            <option value="hidden" ${status == 'hidden' ? 'selected' : ''}>Đang ẩn</option>
        </select>
        <button type="submit">Lọc</button>
    </form>
    <div class="table-card"><table>
        <thead><tr><th>ID</th><th>Sản phẩm</th><th>Khách hàng</th><th>Sao</th><th>Nội dung</th><th>Thời gian</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="r" items="${reviews}">
            <tr>
                <td>${r.reviewId}</td>
                <td><c:out value="${r.product.productName}"/></td>
                <td><c:out value="${r.customer.fullName}"/></td>
                <td>${r.rating}/5</td>
                <td><c:out value="${r.comment}"/></td>
                <td><t:dt value="${r.createdAt}"/></td>
                <td>${r.visible ? 'Đang hiện' : 'Đã ẩn'}</td>
                <td>
                    <form method="post" action="${pageContext.request.contextPath}/admin/review" class="inline">
                        <input type="hidden" name="action" value="${r.visible ? 'hide' : 'show'}">
                        <input type="hidden" name="id" value="${r.reviewId}">
                        <input type="hidden" name="status" value="${status}">
                        <input type="hidden" name="q" value="<c:out value='${q}'/>">
                        <button type="submit" class="btn-xs ${r.visible ? 'danger' : 'ghost'}">${r.visible ? 'Ẩn' : 'Hiện'}</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty reviews}"><tr><td colspan="8">Không có đánh giá.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
