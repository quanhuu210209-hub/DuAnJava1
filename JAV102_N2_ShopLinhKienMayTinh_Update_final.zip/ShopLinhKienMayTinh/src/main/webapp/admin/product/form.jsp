<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<c:set var="isNew" value="${product.productId == 0}"/>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sản phẩm — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>${isNew ? 'Thêm sản phẩm' : 'Sửa sản phẩm'}</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <c:choose>
        <c:when test="${not empty priceRaw}"><c:set var="priceVal" value="${priceRaw}"/></c:when>
        <c:when test="${not empty product.price}"><fmt:formatNumber var="priceVal" value="${product.price}" pattern="#"/></c:when>
        <c:otherwise><c:set var="priceVal" value=""/></c:otherwise>
    </c:choose>
    <form method="post" action="${pageContext.request.contextPath}/admin/product" data-validate>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="productId" value="${product.productId}">
        <div class="form-row">
            <label for="sku">Mã SKU *</label>
            <input id="sku" name="sku" type="text" value="<c:out value='${product.sku}'/>" required maxlength="50"
                   data-label="Mã SKU" data-pattern="[A-Za-z0-9_-]+" data-pattern-message="SKU chỉ gồm chữ, số, gạch ngang, gạch dưới">
            <span class="field-error" data-for="sku"><c:out value="${errors.sku}"/></span>
        </div>
        <div class="form-row">
            <label for="productName">Tên sản phẩm *</label>
            <input id="productName" name="productName" type="text" value="<c:out value='${product.productName}'/>"
                   required maxlength="250" data-label="Tên sản phẩm">
            <span class="field-error" data-for="productName"><c:out value="${errors.productName}"/></span>
        </div>
        <div class="form-row">
            <label for="categoryId">Danh mục *</label>
            <select id="categoryId" name="categoryId" required data-label="Danh mục">
                <option value="">-- Chọn danh mục --</option>
                <c:forEach var="c" items="${categories}">
                    <option value="${c.categoryId}" ${product.category.categoryId == c.categoryId ? 'selected' : ''}><c:out value="${c.categoryName}"/></option>
                </c:forEach>
            </select>
            <span class="field-error" data-for="categoryId"><c:out value="${errors.categoryId}"/></span>
        </div>
        <div class="form-row">
            <label for="brandId">Thương hiệu *</label>
            <select id="brandId" name="brandId" required data-label="Thương hiệu">
                <option value="">-- Chọn thương hiệu --</option>
                <c:forEach var="b" items="${brands}">
                    <option value="${b.brandId}" ${product.brand.brandId == b.brandId ? 'selected' : ''}><c:out value="${b.brandName}"/></option>
                </c:forEach>
            </select>
            <span class="field-error" data-for="brandId"><c:out value="${errors.brandId}"/></span>
        </div>
        <div class="form-row">
            <label for="price">Giá bán (VNĐ) *</label>
            <input id="price" name="price" type="text" inputmode="numeric" value="<c:out value='${priceVal}'/>"
                   required data-type="money" data-label="Giá bán">
            <c:if test="${not isNew}"><small>Đổi giá sẽ được ghi vào lịch sử giá.</small></c:if>
            <span class="field-error" data-for="price"><c:out value="${errors.price}"/></span>
        </div>
        <div class="form-row">
            <label for="warrantyMonths">Bảo hành (tháng) *</label>
            <input id="warrantyMonths" name="warrantyMonths" type="text" inputmode="numeric" value="${product.warrantyMonths}"
                   required data-type="int" data-min="0" data-max="120" data-label="Thời gian bảo hành">
            <span class="field-error" data-for="warrantyMonths"><c:out value="${errors.warrantyMonths}"/></span>
        </div>
        <div class="form-row">
            <label for="thumbnailUrl">Đường dẫn ảnh</label>
            <input id="thumbnailUrl" name="thumbnailUrl" type="text" value="<c:out value='${product.thumbnailUrl}'/>"
                   maxlength="300" data-label="Đường dẫn ảnh">
            <span class="field-error" data-for="thumbnailUrl"><c:out value="${errors.thumbnailUrl}"/></span>
        </div>
        <div class="form-row">
            <label for="status">Trạng thái *</label>
            <select id="status" name="status" required data-label="Trạng thái">
                <option value="Active" ${product.status == 'Active' ? 'selected' : ''}>Đang bán</option>
                <option value="Hidden" ${product.status == 'Hidden' ? 'selected' : ''}>Ẩn</option>
                <option value="Discontinued" ${product.status == 'Discontinued' ? 'selected' : ''}>Ngừng kinh doanh</option>
            </select>
            <span class="field-error" data-for="status"><c:out value="${errors.status}"/></span>
        </div>
        <div class="form-row">
            <label for="description">Mô tả</label>
            <textarea id="description" name="description" rows="5" data-label="Mô tả"><c:out value="${product.description}"/></textarea>
        </div>
        <button type="submit">Lưu</button>
        <a href="${pageContext.request.contextPath}/admin/product">Hủy</a>
    </form>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>
