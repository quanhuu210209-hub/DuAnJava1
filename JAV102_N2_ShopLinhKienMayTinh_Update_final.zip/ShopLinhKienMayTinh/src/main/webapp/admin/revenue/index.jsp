<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Doanh thu — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Doanh thu</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty error}"><div class="alert alert-danger"><c:out value="${error}"/></div></c:if>

    <form method="get" action="${pageContext.request.contextPath}/admin/revenue" class="filter-form">
        <label>Từ ngày <input type="date" name="from" value="${from}"></label>
        <label>Đến ngày <input type="date" name="to" value="${to}"></label>
        <select name="branchId">
            <option value="">-- Tất cả chi nhánh --</option>
            <c:forEach var="b" items="${branches}">
                <option value="${b.branchId}" ${branchId == b.branchId ? 'selected' : ''}><c:out value="${b.branchName}"/></option>
            </c:forEach>
        </select>
        <button type="submit">Xem</button>
    </form>

    <div class="table-card"><table>
        <thead><tr><th>Tổng doanh thu</th><th>Số đơn</th><th>Giá trị trung bình / đơn</th></tr></thead>
        <tbody><tr>
            <td><t:money value="${summary[0]}"/></td>
            <td>${summary[1]}</td>
            <td><t:money value="${summary[1] > 0 ? summary[0] / summary[1] : 0}"/></td>
        </tr></tbody>
    </table></div>

    <h3>Doanh thu theo ngày</h3>
    <div class="table-card"><table>
        <thead><tr><th>Ngày</th><th>Số đơn</th><th>Doanh thu</th></tr></thead>
        <tbody>
        <c:forEach var="r" items="${days}">
            <tr><td>${r[0]}</td><td>${r[1]}</td><td><t:money value="${r[2]}"/></td></tr>
        </c:forEach>
        <c:if test="${empty days}"><tr><td colspan="3">Không có dữ liệu trong khoảng này.</td></tr></c:if>
        </tbody>
    </table></div>

    <h3>Sản phẩm bán chạy (top 10)</h3>
    <div class="table-card"><table>
        <thead><tr><th>Sản phẩm</th><th>Số lượng bán</th><th>Doanh thu</th></tr></thead>
        <tbody>
        <c:forEach var="r" items="${bestSellers}">
            <tr><td><c:out value="${r[0]}"/></td><td>${r[1]}</td><td><t:money value="${r[2]}"/></td></tr>
        </c:forEach>
        <c:if test="${empty bestSellers}"><tr><td colspan="3">Không có dữ liệu trong khoảng này.</td></tr></c:if>
        </tbody>
    </table></div>

    <h3>Doanh thu theo nhân viên (đơn tại quầy)</h3>
    <div class="table-card"><table>
        <thead><tr><th>Nhân viên</th><th>Số đơn</th><th>Doanh thu</th></tr></thead>
        <tbody>
        <c:forEach var="r" items="${staffs}">
            <tr><td><c:out value="${r[0]}"/></td><td>${r[1]}</td><td><t:money value="${r[2]}"/></td></tr>
        </c:forEach>
        <c:if test="${empty staffs}"><tr><td colspan="3">Không có dữ liệu trong khoảng này.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
