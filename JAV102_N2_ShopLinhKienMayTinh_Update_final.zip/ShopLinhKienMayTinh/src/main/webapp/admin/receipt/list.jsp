<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Nhập hàng — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Nhập hàng</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header">
      <form method="get" action="${pageContext.request.contextPath}/admin/receipt" class="inline">
        <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Tìm mã phiếu hoặc nhà cung cấp...">
        <select name="branchId">
          <option value="">Tất cả chi nhánh</option>
          <c:forEach var="b" items="${branches}">
            <option value="${b.branchId}" ${branchId == b.branchId ? 'selected' : ''}><c:out value="${b.branchName}"/></option>
          </c:forEach>
        </select>
        <button type="submit" class="btn-xs ghost">Lọc</button>
      </form>
      <a href="${pageContext.request.contextPath}/admin/receipt?action=new" class="btn-solid">+ Tạo phiếu nhập</a>
    </div>
    <div class="table-card"><table>
        <thead><tr><th>Mã phiếu</th><th>Ngày nhập</th><th>Chi nhánh</th><th>Nhà cung cấp</th><th>Người tạo</th><th>Tổng tiền</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="r" items="${receipts}">
            <tr>
                <td><c:out value="${r.receiptCode}"/></td>
                <td><t:dt value="${r.receiptDate}"/></td>
                <td><c:out value="${r.branch.branchName}"/></td>
                <td><c:out value="${r.supplier.supplierName}"/></td>
                <td><c:out value="${r.createdBy.fullName}"/></td>
                <td><t:money value="${r.totalAmount}"/></td>
                <td><a href="${pageContext.request.contextPath}/admin/receipt?action=view&id=${r.receiptId}" class="btn-xs ghost">Xem</a></td>
            </tr>
        </c:forEach>
        <c:if test="${empty receipts}"><tr><td colspan="7">Chưa có phiếu nhập.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
