<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tạo phiếu nhập — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Tạo phiếu nhập</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty errors.lines}">
      <div class="alert alert-danger"><c:out value="${errors.lines}"/></div>
    </c:if>
    <form method="post" action="${pageContext.request.contextPath}/admin/receipt">
        <input type="hidden" name="action" value="save">
        <div class="form-row">
            <label for="branchId">Chi nhánh nhập *</label>
            <select id="branchId" name="branchId" required>
                <option value="">-- Chọn chi nhánh --</option>
                <c:forEach var="b" items="${branches}">
                    <option value="${b.branchId}" ${receipt.branch.branchId == b.branchId ? 'selected' : ''}><c:out value="${b.branchName}"/></option>
                </c:forEach>
            </select>
            <span class="field-error"><c:out value="${errors.branchId}"/></span>
        </div>
        <div class="form-row">
            <label for="supplierId">Nhà cung cấp *</label>
            <select id="supplierId" name="supplierId" required>
                <option value="">-- Chọn nhà cung cấp --</option>
                <c:forEach var="s" items="${suppliers}">
                    <c:if test="${s.active}">
                        <option value="${s.supplierId}" ${receipt.supplier.supplierId == s.supplierId ? 'selected' : ''}><c:out value="${s.supplierName}"/></option>
                    </c:if>
                </c:forEach>
            </select>
            <span class="field-error"><c:out value="${errors.supplierId}"/></span>
        </div>
        <div class="form-row">
            <label for="note">Ghi chú</label>
            <input id="note" name="note" type="text" maxlength="500" value="<c:out value='${receipt.note}'/>">
            <span class="field-error"><c:out value="${errors.note}"/></span>
        </div>

        <div class="table-card"><table>
            <thead><tr><th>Sản phẩm</th><th>Số lượng</th><th>Đơn giá nhập</th><th>Thành tiền</th><th></th></tr></thead>
            <tbody id="lineBody">
            <c:forEach var="d" items="${lines}">
                <tr>
                    <td>
                        <select name="productId" required>
                            <option value="">-- Chọn sản phẩm --</option>
                            <c:forEach var="p" items="${products}">
                                <c:if test="${p.status != 'Discontinued'}">
                                    <option value="${p.productId}" ${d.product.productId == p.productId ? 'selected' : ''}><c:out value="${p.sku} - ${p.productName}"/></option>
                                </c:if>
                            </c:forEach>
                        </select>
                    </td>
                    <td><input type="number" name="quantity" min="1" max="100000" value="${d.quantity > 0 ? d.quantity : 1}" required></td>
                    <td><input type="number" name="importPrice" min="0" step="1" value="${d.importPrice}" required></td>
                    <td><span class="line-total">0</span></td>
                    <td><button type="button" class="btn-xs danger remove-line">Xóa</button></td>
                </tr>
            </c:forEach>
            </tbody>
            <tfoot><tr>
                <td colspan="3"><button type="button" id="addLine" class="btn-xs ghost">+ Thêm dòng</button></td>
                <td colspan="2"><strong>Tổng: <span id="grandTotal">0 ₫</span></strong></td>
            </tr></tfoot>
        </table></div>

        <button type="submit">Lưu &amp; nhập kho</button>
        <a href="${pageContext.request.contextPath}/admin/receipt">Hủy</a>
    </form>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/admin/receipt-form.js"></script>
</body>
</html>
