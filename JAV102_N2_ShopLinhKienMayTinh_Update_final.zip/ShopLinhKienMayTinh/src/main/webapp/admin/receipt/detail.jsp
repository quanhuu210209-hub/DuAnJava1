<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Phiếu nhập — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Phiếu nhập <c:out value="${receipt.receiptCode}"/></h1>
    </div>
  </div>

  <div class="content">
    <div class="table-card"><table>
        <tbody>
            <tr><th>Ngày nhập</th><td><t:dt value="${receipt.receiptDate}"/></td></tr>
            <tr><th>Chi nhánh</th><td><c:out value="${receipt.branch.branchName}"/></td></tr>
            <tr><th>Nhà cung cấp</th><td><c:out value="${receipt.supplier.supplierName}"/></td></tr>
            <tr><th>Người tạo</th><td><c:out value="${receipt.createdBy.fullName}"/></td></tr>
            <tr><th>Ghi chú</th><td><c:out value="${receipt.note}"/></td></tr>
        </tbody>
    </table></div>

    <div class="table-card"><table>
        <thead><tr><th>SKU</th><th>Sản phẩm</th><th>Số lượng</th><th>Đơn giá nhập</th><th>Thành tiền</th></tr></thead>
        <tbody>
        <c:forEach var="d" items="${lines}">
            <tr>
                <td><c:out value="${d.product.sku}"/></td>
                <td><c:out value="${d.product.productName}"/></td>
                <td>${d.quantity}</td>
                <td><t:money value="${d.importPrice}"/></td>
                <td><t:money value="${d.lineTotal}"/></td>
            </tr>
        </c:forEach>
        </tbody>
        <tfoot><tr><td colspan="4"><strong>Tổng tiền</strong></td><td><strong><t:money value="${receipt.totalAmount}"/></strong></td></tr></tfoot>
    </table></div>

    <a href="${pageContext.request.contextPath}/admin/receipt">← Quay lại</a>
  </div>
</div>
</body>
</html>
