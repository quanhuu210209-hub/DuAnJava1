<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Lịch sử giá — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Lịch sử giá</h1>
    </div>
  </div>

  <div class="content">
    <form method="get" action="${pageContext.request.contextPath}/admin/price-history" class="filter-form">
        <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Tìm theo tên hoặc SKU sản phẩm">
        <button type="submit">Lọc</button>
    </form>
    <div class="table-card"><table>
        <thead><tr><th>Thời điểm</th><th>SKU</th><th>Sản phẩm</th><th>Giá cũ</th><th>Giá mới</th><th>Người đổi</th><th>Lý do</th></tr></thead>
        <tbody>
        <c:forEach var="h" items="${histories}">
            <tr>
                <td><t:dt value="${h.changedAt}"/></td>
                <td><c:out value="${h.product.sku}"/></td>
                <td><c:out value="${h.product.productName}"/></td>
                <td><t:money value="${h.oldPrice}"/></td>
                <td><t:money value="${h.newPrice}"/></td>
                <td><c:out value="${h.changedBy.fullName}"/></td>
                <td><c:out value="${h.reason}"/></td>
            </tr>
        </c:forEach>
        <c:if test="${empty histories}"><tr><td colspan="7">Chưa có thay đổi giá.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
