<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ảnh sản phẩm — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Ảnh: <c:out value="${product.productName}"/></h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header"><span></span><a href="${pageContext.request.contextPath}/admin/product" class="btn-xs ghost">← Về danh sách sản phẩm</a></div>

    <form method="post" action="${pageContext.request.contextPath}/admin/product-image" class="filter-form">
        <input type="hidden" name="productId" value="${product.productId}">
        <input type="text" name="imageUrl" placeholder="Dán đường dẫn ảnh" required maxlength="300">
        <input type="number" name="sortOrder" value="0" placeholder="Thứ tự">
        <button type="submit">Thêm ảnh</button>
    </form>

    <div class="table-card"><table>
        <thead><tr><th>Thứ tự</th><th>Đường dẫn ảnh</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="i" items="${images}">
            <tr>
                <td>${i.sortOrder}</td>
                <td><c:out value="${i.imageUrl}"/></td>
                <td>
                    <form method="post" action="${pageContext.request.contextPath}/admin/product-image" class="inline"
                          onsubmit="return confirm('Xóa ảnh này?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="productId" value="${product.productId}">
                        <input type="hidden" name="id" value="${i.imageId}">
                        <button type="submit" class="btn-xs danger">Xóa</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty images}"><tr><td colspan="3">Chưa có ảnh phụ.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
