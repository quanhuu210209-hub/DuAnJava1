<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<c:set var="isNew" value="${brand.brandId == 0}"/>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Thương hiệu — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>${isNew ? 'Thêm thương hiệu' : 'Sửa thương hiệu'}</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="post" action="${pageContext.request.contextPath}/admin/brand" data-validate>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="brandId" value="${brand.brandId}">
        <div class="form-row">
            <label for="brandName">Tên thương hiệu *</label>
            <input id="brandName" name="brandName" type="text" value="<c:out value='${brand.brandName}'/>"
                   required maxlength="100" data-label="Tên thương hiệu">
            <span class="field-error" data-for="brandName"><c:out value="${errors.brandName}"/></span>
        </div>
        <div class="form-row">
            <label for="logoUrl">Đường dẫn logo</label>
            <input id="logoUrl" name="logoUrl" type="text" value="<c:out value='${brand.logoUrl}'/>"
                   maxlength="300" data-label="Đường dẫn logo">
            <span class="field-error" data-for="logoUrl"><c:out value="${errors.logoUrl}"/></span>
        </div>
        <div class="form-row">
            <label><input type="checkbox" name="active" ${brand.active ? 'checked' : ''}> Đang sử dụng</label>
        </div>
        <button type="submit">Lưu</button>
        <a href="${pageContext.request.contextPath}/admin/brand">Hủy</a>
    </form>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>
