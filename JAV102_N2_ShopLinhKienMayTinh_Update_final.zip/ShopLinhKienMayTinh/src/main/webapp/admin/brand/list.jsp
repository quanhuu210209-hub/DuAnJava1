<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Thương hiệu — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Thương hiệu</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header"><span></span><a href="${pageContext.request.contextPath}/admin/brand?action=new" class="btn-solid">+ Thêm thương hiệu</a></div>
    <div class="table-card"><table>
        <thead><tr><th>ID</th><th>Tên thương hiệu</th><th>Logo</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="b" items="${brands}">
            <tr>
                <td>${b.brandId}</td>
                <td><c:out value="${b.brandName}"/></td>
                <td><c:out value="${b.logoUrl}"/></td>
                <td>${b.active ? 'Đang dùng' : 'Ẩn'}</td>
                <td>
                    <a href="${pageContext.request.contextPath}/admin/brand?action=edit&id=${b.brandId}" class="btn-xs ghost">Sửa</a>
                    <form method="post" action="${pageContext.request.contextPath}/admin/brand" class="inline"
                          onsubmit="return confirm('Xóa thương hiệu này?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="${b.brandId}">
                        <button type="submit" class="btn-xs danger">Xóa</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty brands}"><tr><td colspan="5">Chưa có thương hiệu.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
