<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<c:set var="isNew" value="${supplier.supplierId == 0}"/>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Nhà cung cấp — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>${isNew ? 'Thêm nhà cung cấp' : 'Sửa nhà cung cấp'}</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="post" action="${pageContext.request.contextPath}/admin/supplier" data-validate>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="supplierId" value="${supplier.supplierId}">
        <div class="form-row">
            <label for="supplierName">Tên nhà cung cấp *</label>
            <input id="supplierName" name="supplierName" type="text" value="<c:out value='${supplier.supplierName}'/>"
                   required maxlength="150" data-label="Tên nhà cung cấp">
            <span class="field-error" data-for="supplierName"><c:out value="${errors.supplierName}"/></span>
        </div>
        <div class="form-row">
            <label for="address">Địa chỉ</label>
            <input id="address" name="address" type="text" value="<c:out value='${supplier.address}'/>"
                   maxlength="300" data-label="Địa chỉ">
            <span class="field-error" data-for="address"><c:out value="${errors.address}"/></span>
        </div>
        <div class="form-row">
            <label for="phone">Số điện thoại</label>
            <input id="phone" name="phone" type="text" value="<c:out value='${supplier.phone}'/>"
                   maxlength="20" data-label="Số điện thoại">
            <span class="field-error" data-for="phone"><c:out value="${errors.phone}"/></span>
        </div>
        <div class="form-row">
            <label for="email">Email</label>
            <input id="email" name="email" type="text" value="<c:out value='${supplier.email}'/>"
                   maxlength="150" data-label="Email">
            <span class="field-error" data-for="email"><c:out value="${errors.email}"/></span>
        </div>
        <div class="form-row">
            <label for="branchId">Chi nhánh</label>
            <select id="branchId" name="branchId">
                <option value="">Dùng chung</option>
                <c:forEach var="b" items="${branches}">
                    <option value="${b.branchId}" ${supplier.branch.branchId == b.branchId ? 'selected' : ''}><c:out value="${b.branchName}"/></option>
                </c:forEach>
            </select>
        </div>
        <div class="form-row">
            <label><input type="checkbox" name="active" ${supplier.active ? 'checked' : ''}> Đang hợp tác</label>
        </div>
        <button type="submit">Lưu</button>
        <a href="${pageContext.request.contextPath}/admin/supplier">Hủy</a>
    </form>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>
