<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Nhà cung cấp — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Nhà cung cấp</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header">
      <form method="get" action="${pageContext.request.contextPath}/admin/supplier" class="inline">
        <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Tìm tên hoặc SĐT...">
        <button type="submit" class="btn-xs ghost">Tìm</button>
      </form>
      <a href="${pageContext.request.contextPath}/admin/supplier?action=new" class="btn-solid">+ Thêm nhà cung cấp</a>
    </div>
    <div class="table-card"><table>
        <thead><tr><th>ID</th><th>Tên nhà cung cấp</th><th>SĐT</th><th>Email</th><th>Chi nhánh</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="s" items="${suppliers}">
            <tr>
                <td>${s.supplierId}</td>
                <td><c:out value="${s.supplierName}"/></td>
                <td><c:out value="${s.phone}"/></td>
                <td><c:out value="${s.email}"/></td>
                <td><c:out value="${empty s.branch ? 'Dùng chung' : s.branch.branchName}"/></td>
                <td>${s.active ? 'Đang hợp tác' : 'Ẩn'}</td>
                <td>
                    <a href="${pageContext.request.contextPath}/admin/supplier?action=edit&id=${s.supplierId}" class="btn-xs ghost">Sửa</a>
                    <form method="post" action="${pageContext.request.contextPath}/admin/supplier" class="inline"
                          onsubmit="return confirm('Xóa nhà cung cấp này?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="${s.supplierId}">
                        <button type="submit" class="btn-xs danger">Xóa</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty suppliers}"><tr><td colspan="7">Chưa có nhà cung cấp.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
