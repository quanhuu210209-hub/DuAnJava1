<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chính sách — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Chính sách bảo hành / đổi trả</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header"><span></span><a href="${pageContext.request.contextPath}/admin/policy?action=new" class="btn-solid">+ Thêm chính sách</a></div>
    <div class="table-card"><table>
        <thead><tr><th>ID</th><th>Loại</th><th>Tiêu đề</th><th>Trạng thái</th><th>Cập nhật</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="p" items="${policies}">
            <tr>
                <td>${p.policyId}</td>
                <td>${p.policyType == 'Warranty' ? 'Bảo hành' : 'Đổi trả'}</td>
                <td><c:out value="${p.title}"/></td>
                <td>${p.active ? 'Đang áp dụng' : 'Ẩn'}</td>
                <td><t:dt value="${p.updatedAt}"/></td>
                <td>
                    <a href="${pageContext.request.contextPath}/admin/policy?action=edit&id=${p.policyId}" class="btn-xs ghost">Sửa</a>
                    <form method="post" action="${pageContext.request.contextPath}/admin/policy" class="inline"
                          onsubmit="return confirm('Xóa chính sách này?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="${p.policyId}">
                        <button type="submit" class="btn-xs danger">Xóa</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty policies}"><tr><td colspan="6">Chưa có chính sách.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
