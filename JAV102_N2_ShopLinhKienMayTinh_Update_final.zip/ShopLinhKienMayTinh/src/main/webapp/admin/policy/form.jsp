<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<c:set var="isNew" value="${policy.policyId == 0}"/>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chính sách — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>${isNew ? 'Thêm chính sách' : 'Sửa chính sách'}</h1>
    </div>
  </div>

  <div class="content">
    <form method="post" action="${pageContext.request.contextPath}/admin/policy" data-validate>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="policyId" value="${policy.policyId}">
        <div class="form-row">
            <label for="policyType">Loại chính sách *</label>
            <select id="policyType" name="policyType" required data-label="Loại chính sách">
                <option value="Warranty" ${policy.policyType == 'Warranty' ? 'selected' : ''}>Bảo hành</option>
                <option value="Return" ${policy.policyType == 'Return' ? 'selected' : ''}>Đổi trả</option>
            </select>
            <span class="field-error" data-for="policyType"><c:out value="${errors.policyType}"/></span>
        </div>
        <div class="form-row">
            <label for="title">Tiêu đề *</label>
            <input id="title" name="title" type="text" value="<c:out value='${policy.title}'/>"
                   required maxlength="200" data-label="Tiêu đề">
            <span class="field-error" data-for="title"><c:out value="${errors.title}"/></span>
        </div>
        <div class="form-row">
            <label for="content">Nội dung *</label>
            <textarea id="content" name="content" rows="8" required maxlength="4000" data-label="Nội dung"><c:out value="${policy.content}"/></textarea>
            <span class="field-error" data-for="content"><c:out value="${errors.content}"/></span>
        </div>
        <div class="form-row">
            <label><input type="checkbox" name="active" ${policy.active ? 'checked' : ''}> Đang áp dụng</label>
        </div>
        <button type="submit">Lưu</button>
        <a href="${pageContext.request.contextPath}/admin/policy">Hủy</a>
    </form>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>
