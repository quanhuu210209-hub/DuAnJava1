<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Thông số sản phẩm — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Thông số: <c:out value="${product.productName}"/></h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header"><span></span><a href="${pageContext.request.contextPath}/admin/product" class="btn-xs ghost">← Về danh sách sản phẩm</a></div>

    <form method="post" action="${pageContext.request.contextPath}/admin/product-spec" class="filter-form">
        <input type="hidden" name="productId" value="${product.productId}">
        <input type="text" name="specName" placeholder="Tên thông số (vd: Socket)" required maxlength="100">
        <input type="text" name="specValue" placeholder="Giá trị (vd: AM5)" required maxlength="200">
        <button type="submit">Thêm / cập nhật</button>
    </form>

    <div class="table-card"><table>
        <thead><tr><th>Tên thông số</th><th>Giá trị</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="x" items="${specs}">
            <tr>
                <td><c:out value="${x.specName}"/></td>
                <td><c:out value="${x.specValue}"/></td>
                <td>
                    <form method="post" action="${pageContext.request.contextPath}/admin/product-spec" class="inline"
                          onsubmit="return confirm('Xóa thông số này?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="productId" value="${product.productId}">
                        <input type="hidden" name="id" value="${x.specId}">
                        <button type="submit" class="btn-xs danger">Xóa</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty specs}"><tr><td colspan="3">Chưa có thông số.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
