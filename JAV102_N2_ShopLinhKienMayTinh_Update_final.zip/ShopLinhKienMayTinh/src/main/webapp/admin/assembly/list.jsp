<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Phân công lắp đặt — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Phân công lắp đặt</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header"><span></span><a href="${pageContext.request.contextPath}/admin/assembly?action=new" class="btn-solid">+ Giao việc lắp đặt</a></div>
    <form method="get" action="${pageContext.request.contextPath}/admin/assembly" class="filter-form">
        <select name="status">
            <option value="">-- Tất cả trạng thái --</option>
            <option value="Waiting" ${status == 'Waiting' ? 'selected' : ''}>Chờ</option>
            <option value="InProgress" ${status == 'InProgress' ? 'selected' : ''}>Đang lắp</option>
            <option value="Done" ${status == 'Done' ? 'selected' : ''}>Hoàn thành</option>
        </select>
        <button type="submit">Lọc</button>
    </form>
    <div class="table-card"><table>
        <thead><tr><th>ID</th><th>Mã đơn</th><th>Chi nhánh</th><th>Người thực hiện</th><th>Yêu cầu</th><th>Trạng thái</th><th>Giao lúc</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="j" items="${jobs}">
            <tr>
                <td>${j.jobId}</td>
                <td><c:out value="${j.salesOrder.orderCode}"/></td>
                <td><c:out value="${j.branch.branchName}"/></td>
                <td><c:out value="${j.assignedTo.fullName}"/></td>
                <td><c:out value="${j.requirement}"/></td>
                <td>${j.status == 'Waiting' ? 'Chờ' : (j.status == 'InProgress' ? 'Đang lắp' : 'Hoàn thành')}</td>
                <td><t:dt value="${j.assignedAt}"/></td>
                <td>
                    <c:if test="${j.status != 'Done'}">
                        <a href="${pageContext.request.contextPath}/admin/assembly?action=edit&id=${j.jobId}" class="btn-xs ghost">Sửa</a>
                    </c:if>
                    <c:if test="${j.status == 'Waiting'}">
                        <form method="post" action="${pageContext.request.contextPath}/admin/assembly" class="inline"
                              onsubmit="return confirm('Xóa việc lắp đặt này?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="${j.jobId}">
                            <button type="submit" class="btn-xs danger">Xóa</button>
                        </form>
                    </c:if>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty jobs}"><tr><td colspan="8">Chưa có việc lắp đặt.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
