<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<c:set var="isNew" value="${job.jobId == 0}"/>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Phân công lắp đặt — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>${isNew ? 'Giao việc lắp đặt' : 'Sửa phân công lắp đặt'}</h1>
    </div>
  </div>

  <div class="content">
    <form method="post" action="${pageContext.request.contextPath}/admin/assembly" data-validate>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="jobId" value="${job.jobId}">
        <div class="form-row">
            <label for="orderId">Đơn hàng *</label>
            <c:choose>
                <c:when test="${isNew}">
                    <select id="orderId" name="orderId" required data-label="Đơn hàng">
                        <option value="">-- Chọn đơn hàng --</option>
                        <c:forEach var="o" items="${orders}">
                            <option value="${o.orderId}" ${job.salesOrder.orderId == o.orderId ? 'selected' : ''}><c:out value="${o.orderCode}"/> — <c:out value="${o.branch.branchName}"/></option>
                        </c:forEach>
                    </select>
                    <span class="field-error" data-for="orderId"><c:out value="${errors.orderId}"/></span>
                </c:when>
                <c:otherwise><strong><c:out value="${job.salesOrder.orderCode}"/> — <c:out value="${job.branch.branchName}"/></strong></c:otherwise>
            </c:choose>
        </div>
        <div class="form-row">
            <label for="assignedTo">Người thực hiện *</label>
            <select id="assignedTo" name="assignedTo" required data-label="Người thực hiện">
                <option value="">-- Chọn nhân viên --</option>
                <c:forEach var="u" items="${staffs}">
                    <option value="${u.userId}" ${job.assignedTo.userId == u.userId ? 'selected' : ''}><c:out value="${u.fullName}"/> — <c:out value="${u.branch.branchName}"/></option>
                </c:forEach>
            </select>
            <span class="field-error" data-for="assignedTo"><c:out value="${errors.assignedTo}"/></span>
        </div>
        <div class="form-row">
            <label for="requirement">Yêu cầu lắp đặt</label>
            <textarea id="requirement" name="requirement" rows="4" maxlength="500" data-label="Yêu cầu"><c:out value="${job.requirement}"/></textarea>
            <span class="field-error" data-for="requirement"><c:out value="${errors.requirement}"/></span>
        </div>
        <button type="submit">Lưu</button>
        <a href="${pageContext.request.contextPath}/admin/assembly">Hủy</a>
    </form>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>
