                        (function () {
                            const container = document.getElementById('threejs-container-ANIMATION_13');
                            if (!container) return;
                            const width = container.clientWidth || window.innerWidth;
                            const height = container.clientHeight || window.innerHeight;

                            const scene = new THREE.Scene();
                            const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
                            camera.position.set(0, 0, 18);

                            const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: "high-performance" });
                            renderer.setSize(width, height);
                            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
                            container.appendChild(renderer.domElement);

                            const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
                            scene.add(ambientLight);

                            const keyLight = new THREE.DirectionalLight(0x9fd0ff, 1.8);
                            keyLight.position.set(8, 12, 12);
                            scene.add(keyLight);

                            const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.5);
                            rimLight.position.set(-10, -5, 8);
                            scene.add(rimLight);

                            const cyanLight = new THREE.PointLight(0x00f0ff, 1.5, 20);
                            cyanLight.position.set(-4, 2, 4);
                            scene.add(cyanLight);

                            const magentaLight = new THREE.PointLight(0xa855f7, 1.5, 20);
                            magentaLight.position.set(4, -2, 4);
                            scene.add(magentaLight);

                            const gpuGroup = new THREE.Group();
                            scene.add(gpuGroup);

                            const shroudMat = new THREE.MeshPhongMaterial({ color: 0x14171e, specular: 0x2e384d, shininess: 45 });
                            const metalAccMat = new THREE.MeshPhongMaterial({ color: 0x2b313d, specular: 0x8294b0, shininess: 70 });
                            const backplateMat = new THREE.MeshPhongMaterial({ color: 0x0f1117, specular: 0x3b4454, shininess: 50 });
                            const fanBladeMat = new THREE.MeshPhongMaterial({ color: 0x0a0c10, specular: 0x2a303c, shininess: 60 });

                            const rgbRingMat1 = new THREE.MeshBasicMaterial({ color: 0x00f2fe, blending: THREE.AdditiveBlending });
                            const rgbRingMat2 = new THREE.MeshBasicMaterial({ color: 0x9d4edd, blending: THREE.AdditiveBlending });
                            const rgbRingMat3 = new THREE.MeshBasicMaterial({ color: 0x22c55e, blending: THREE.AdditiveBlending });

                            const shroudGeo = new THREE.BoxGeometry(11.2, 4.8, 1.6);
                            const shroudMesh = new THREE.Mesh(shroudGeo, shroudMat);
                            gpuGroup.add(shroudMesh);

                            const trimTop = new THREE.Mesh(new THREE.BoxGeometry(11.4, 0.25, 1.7), metalAccMat);
                            trimTop.position.set(0, 2.35, 0);
                            gpuGroup.add(trimTop);

                            const trimBot = new THREE.Mesh(new THREE.BoxGeometry(11.4, 0.25, 1.7), metalAccMat);
                            trimBot.position.set(0, -2.35, 0);
                            gpuGroup.add(trimBot);

                            const backplateGeo = new THREE.BoxGeometry(11.2, 4.8, 0.15);
                            const backplateMesh = new THREE.Mesh(backplateGeo, backplateMat);
                            backplateMesh.position.set(0, 0, -0.85);
                            gpuGroup.add(backplateMesh);

                            const grillGeo = new THREE.BoxGeometry(3.0, 3.2, 0.18);
                            const grillMat = new THREE.MeshPhongMaterial({ color: 0x1f242e });
                            const grill = new THREE.Mesh(grillGeo, grillMat);
                            grill.position.set(3.4, 0, -0.86);
                            gpuGroup.add(grill);

                            const pcieMat = new THREE.MeshPhongMaterial({ color: 0xd97706, specular: 0xfffbeb, shininess: 80 });
                            const pcie = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.5, 0.1), pcieMat);
                            pcie.position.set(-2.0, -2.65, -0.2);
                            gpuGroup.add(pcie);

                            const bracketMat = new THREE.MeshPhongMaterial({ color: 0x71717a, specular: 0xffffff, shininess: 85 });
                            const bracket = new THREE.Mesh(new THREE.BoxGeometry(0.2, 5.8, 1.4), bracketMat);
                            bracket.position.set(-5.7, -0.3, 0);
                            gpuGroup.add(bracket);

                            const fanList = [];
                            const fanPositionsX = [-3.4, 0, 3.4];
                            const rgbMaterials = [rgbRingMat1, rgbRingMat2, rgbRingMat3];

                            fanPositionsX.forEach((posX, index) => {
                                const ringGeo = new THREE.TorusGeometry(1.5, 0.08, 16, 64);
                                const rgbRing = new THREE.Mesh(ringGeo, rgbMaterials[index]);
                                rgbRing.position.set(posX, 0, 0.82);
                                gpuGroup.add(rgbRing);

                                const fanRotor = new THREE.Group();
                                fanRotor.position.set(posX, 0, 0.8);

                                const hubGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.25, 24);
                                hubGeo.rotateX(Math.PI / 2);
                                const hub = new THREE.Mesh(hubGeo, metalAccMat);
                                fanRotor.add(hub);

                                const hubLogoGeo = new THREE.CircleGeometry(0.35, 24);
                                const hubLogoMat = new THREE.MeshBasicMaterial({ color: 0x9fd0ff });
                                const hubLogo = new THREE.Mesh(hubLogoGeo, hubLogoMat);
                                hubLogo.position.set(0, 0, 0.14);
                                fanRotor.add(hubLogo);

                                for (let b = 0; b < 9; b++) {
                                    const angle = (b / 9) * Math.PI * 2;
                                    const bladeGeo = new THREE.BoxGeometry(0.22, 0.95, 0.05);
                                    const blade = new THREE.Mesh(bladeGeo, fanBladeMat);
                                    blade.position.set(Math.cos(angle) * 0.9, Math.sin(angle) * 0.9, 0);
                                    blade.rotation.z = angle + 0.35;
                                    blade.rotation.y = 0.3;
                                    fanRotor.add(blade);
                                }

                                gpuGroup.add(fanRotor);
                                fanList.push(fanRotor);
                            });

                            const sideBarGeo = new THREE.BoxGeometry(4.6, 0.35, 0.08);
                            const sideBarMat = new THREE.MeshBasicMaterial({ color: 0x9fd0ff, blending: THREE.AdditiveBlending });
                            const sideBar = new THREE.Mesh(sideBarGeo, sideBarMat);
                            sideBar.position.set(0, 2.38, 0.5);
                            gpuGroup.add(sideBar);

                            const pCount = 140;
                            const pGeo = new THREE.BufferGeometry();
                            const pPos = new Float32Array(pCount * 3);

                            for (let i = 0; i < pCount; i++) {
                                pPos[i * 3] = (Math.random() - 0.5) * 20;
                                pPos[i * 3 + 1] = (Math.random() - 0.5) * 12;
                                pPos[i * 3 + 2] = (Math.random() - 0.5) * 10;
                            }
                            pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));

                            const pMat = new THREE.PointsMaterial({
                                color: 0x9fd0ff,
                                size: 0.18,
                                transparent: true,
                                opacity: 0.5,
                                blending: THREE.AdditiveBlending
                            });
                            const particles = new THREE.Points(pGeo, pMat);
                            gpuGroup.add(particles);

                            gpuGroup.rotation.x = 0.35;
                            gpuGroup.rotation.y = -0.65;

                            let targetMouseX = 0;
                            let targetMouseY = 0;
                            let currentMouseX = 0;
                            let currentMouseY = 0;

                            function onPointerMove(e) {
                                const rect = container.getBoundingClientRect();
                                const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
                                const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
                                targetMouseX = x;
                                targetMouseY = y;
                            }
                            window.addEventListener('pointermove', onPointerMove, { passive: true });

                            const clock = new THREE.Clock();

                            function animate() {
                                requestAnimationFrame(animate);
                                const delta = clock.getDelta();
                                const elapsed = clock.getElapsedTime();

                                gpuGroup.rotation.y += delta * 0.45;
                                fanList.forEach((fan) => {
                                    fan.rotation.z -= delta * 7.5;
                                });

                                const hue1 = (elapsed * 0.15) % 1;
                                const hue2 = (elapsed * 0.15 + 0.33) % 1;
                                const hue3 = (elapsed * 0.15 + 0.66) % 1;
                                rgbRingMat1.color.setHSL(hue1, 0.9, 0.6);
                                rgbRingMat2.color.setHSL(hue2, 0.9, 0.6);
                                rgbRingMat3.color.setHSL(hue3, 0.9, 0.6);

                                currentMouseX += (targetMouseX - currentMouseX) * 0.05;
                                currentMouseY += (targetMouseY - currentMouseY) * 0.05;

                                gpuGroup.position.y = Math.sin(elapsed * 1.2) * 0.25;
                                gpuGroup.rotation.x = 0.35 + Math.sin(elapsed * 0.7) * 0.06 - currentMouseY * 0.25;
                                gpuGroup.rotation.z = Math.cos(elapsed * 0.5) * 0.04 + currentMouseX * 0.15;

                                renderer.render(scene, camera);
                            }
                            animate();

                            function onResize() {
                                const w = container.clientWidth || window.innerWidth;
                                const h = container.clientHeight || window.innerHeight;
                                camera.aspect = w / h;
                                camera.updateProjectionMatrix();
                                renderer.setSize(w, h);
                            }
                            window.addEventListener('resize', onResize);
                        })();
