    // Chỉ hiện ô chi nhánh khi vai trò là Quản lý / Nhân viên
    (function () {
        var role = document.getElementById('roleId');
        var row = document.getElementById('branchRow');
        var branch = document.getElementById('branchId');
        function sync() {
            var opt = role.options[role.selectedIndex];
            var code = opt ? opt.getAttribute('data-code') : '';
            var need = (code === 'MANAGER' || code === 'STAFF');
            row.hidden = !need;
            if (need) branch.setAttribute('required', ''); else branch.removeAttribute('required');
        }
        role.addEventListener('change', sync);
        sync();
    })();
