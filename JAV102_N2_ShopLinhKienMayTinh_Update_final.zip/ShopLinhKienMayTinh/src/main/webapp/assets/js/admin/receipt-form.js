(function () {
    var body = document.getElementById('lineBody');
    var totalEl = document.getElementById('grandTotal');

    function recalc() {
        var sum = 0;
        [].forEach.call(body.rows, function (tr) {
            var q = parseInt(tr.querySelector('[name=quantity]').value, 10) || 0;
            var p = parseInt(tr.querySelector('[name=importPrice]').value, 10) || 0;
            tr.querySelector('.line-total').textContent = (q * p).toLocaleString('vi-VN');
            sum += q * p;
        });
        totalEl.textContent = sum.toLocaleString('vi-VN') + ' ₫';
    }

    document.getElementById('addLine').addEventListener('click', function () {
        var tr = body.rows[0].cloneNode(true);
        tr.querySelector('[name=productId]').value = '';
        tr.querySelector('[name=quantity]').value = '1';
        tr.querySelector('[name=importPrice]').value = '';
        body.appendChild(tr);
        recalc();
    });

    body.addEventListener('click', function (e) {
        if (!e.target.classList.contains('remove-line')) return;
        if (body.rows.length > 1) e.target.closest('tr').remove();
        recalc();
    });

    body.addEventListener('input', recalc);
    recalc();
})();
