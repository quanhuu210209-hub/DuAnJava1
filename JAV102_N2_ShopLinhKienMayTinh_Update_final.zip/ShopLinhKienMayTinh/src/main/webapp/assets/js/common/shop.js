/* Dùng chung cho trang chủ và trang Build: thông tin phiên, định dạng tiền, thông báo, API giỏ hàng (lưu DB) */
const APP = { ctx: document.body.dataset.ctx || '', role: document.body.dataset.role || '' };

function formatVND(amount) {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount).replace('₫', '') + '₫';
}

function showToast(message, type = "success") {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    const icon = type === 'success' ? 'check_circle' : (type === 'error' ? 'error' : 'info');
    const borderColor = type === 'success' ? 'border-primary/50' : (type === 'error' ? 'border-red-500/50' : 'border-sky-400/50');
    const iconColor = type === 'success' ? 'text-primary' : (type === 'error' ? 'text-red-400' : 'text-sky-400');

    toast.className = `pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-2xl bg-surface-container/95 backdrop-blur-2xl border ${borderColor} shadow-[0_10px_30px_rgba(0,0,0,0.5)] text-xs text-white transition-all transform translate-y-2 opacity-0 animate-in fade-in duration-300`;
    toast.innerHTML = `
<span class="material-symbols-outlined text-[20px] ${iconColor}">${icon}</span>
<span class="flex-1 font-body-md">${message}</span>
`;
    container.appendChild(toast);
    requestAnimationFrame(() => {
        toast.classList.remove('translate-y-2', 'opacity-0');
    });
    setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-y-2');
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

/** Chỉ khách hàng mới có giỏ: chưa đăng nhập thì chuyển tới trang đăng nhập. */
function requireCustomer() {
    if (APP.role === 'CUSTOMER') return true;
    if (!APP.role) {
        showToast('Vui lòng đăng nhập để dùng giỏ hàng.', 'info');
        setTimeout(() => { location.href = APP.ctx + '/login'; }, 800);
    } else {
        showToast('Chỉ tài khoản khách hàng mới có giỏ hàng.', 'error');
    }
    return false;
}

/** Gọi /user/cart. Không truyền action = xem giỏ. Trả về danh sách dòng giỏ, hoặc null nếu lỗi. */
async function cartApi(action, productId, qty) {
    try {
        const res = await fetch(APP.ctx + '/user/cart', {
            method: action ? 'POST' : 'GET',
            credentials: 'same-origin',
            body: action ? new URLSearchParams({ action, productId: productId ?? '', qty: qty ?? 1 }) : undefined
        });
        if (res.redirected) { location.href = APP.ctx + '/login'; return null; }   // hết phiên đăng nhập
        const data = await res.json();
        if (!res.ok) { showToast(data.error || 'Có lỗi với giỏ hàng.', 'error'); return null; }
        return data.items.map(i => ({
            quantity: i.quantity,
            product: { id: String(i.id), name: i.name, sku: i.sku, price: Number(i.price), image: i.image }
        }));
    } catch (e) {
        showToast('Không kết nối được máy chủ.', 'error');
        return null;
    }
}
