/**
 * Validate phía client (Y4). Dùng cho mọi <form data-validate>.
 * Thuộc tính hỗ trợ trên input/select/textarea:
 *   required, maxlength, minlength,
 *   data-label="Tên hiển thị"           (dùng trong thông báo)
 *   data-type="email|phone|money|int"   (kèm data-min / data-max cho int)
 *   data-pattern="regex" data-pattern-message="..."
 * Thuộc tính trên <form>:
 *   data-one-of="email,phone"  (phải nhập ít nhất 1 trong các trường)
 * Thông báo lỗi hiển thị trong <span class="field-error" data-for="tên-trường">.
 * Mọi quy tắc đều được kiểm tra lại ở server (Util/Validator.java).
 */
(function () {
    var EMAIL = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
    var PHONE = /^(0|\+84)\d{9}$/;

    function labelOf(el) { return el.getAttribute('data-label') || el.name; }

    function checkField(el) {
        var v = (el.value || '').trim();
        var label = labelOf(el);
        if (el.hasAttribute('required') && v === '') return label + ' không được để trống';
        if (v === '') return '';

        var max = el.getAttribute('maxlength');
        if (max && v.length > parseInt(max, 10)) return label + ' tối đa ' + max + ' ký tự';
        var min = el.getAttribute('minlength');
        if (min && v.length < parseInt(min, 10)) return label + ' tối thiểu ' + min + ' ký tự';

        var type = el.getAttribute('data-type');
        if (type === 'email' && !EMAIL.test(v)) return 'Email không đúng định dạng';
        if (type === 'phone' && !PHONE.test(v)) return 'Số điện thoại phải gồm 10 chữ số, bắt đầu bằng 0 (hoặc +84)';
        if (type === 'money' && !/^\d{1,15}$/.test(v)) return label + ' phải là số nguyên không âm';
        if (type === 'int') {
            if (!/^-?\d+$/.test(v)) return label + ' phải là số nguyên';
            var n = parseInt(v, 10), lo = el.getAttribute('data-min'), hi = el.getAttribute('data-max');
            if (lo !== null && n < parseInt(lo, 10)) return label + ' phải từ ' + lo + ' đến ' + hi;
            if (hi !== null && n > parseInt(hi, 10)) return label + ' phải từ ' + lo + ' đến ' + hi;
        }
        var pat = el.getAttribute('data-pattern');
        if (pat && !new RegExp('^(?:' + pat + ')$').test(v)) {
            return el.getAttribute('data-pattern-message') || label + ' không hợp lệ';
        }
        return '';
    }

    function show(el, msg) {
        var form = el.form;
        var span = form.querySelector('.field-error[data-for="' + el.name + '"]');
        if (!span) {
            span = document.createElement('span');
            span.className = 'field-error';
            span.setAttribute('data-for', el.name);
            el.parentNode.appendChild(span);
        }
        span.textContent = msg;
        el.classList.toggle('invalid', !!msg);
    }

    function isSkipped(el) {
        return el.disabled || el.type === 'hidden' || el.closest('[hidden]') !== null;
    }

    function validateForm(form) {
        var ok = true, firstBad = null;
        form.querySelectorAll('input, select, textarea').forEach(function (el) {
            if (!el.name || isSkipped(el) || el.type === 'checkbox' || el.type === 'submit') return;
            var msg = checkField(el);
            show(el, msg);
            if (msg) { ok = false; if (!firstBad) firstBad = el; }
        });

        var oneOf = form.getAttribute('data-one-of');
        if (oneOf) {
            var names = oneOf.split(',');
            var any = names.some(function (n) {
                var f = form.elements[n.trim()];
                return f && f.value.trim() !== '';
            });
            if (!any) {
                var first = form.elements[names[0].trim()];
                show(first, 'Cần nhập ít nhất ' + names.join(' hoặc ') + ' để đăng nhập');
                ok = false;
                if (!firstBad) firstBad = first;
            }
        }
        if (firstBad) firstBad.focus();
        return ok;
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('form[data-validate]').forEach(function (form) {
            form.setAttribute('novalidate', '');      // dùng thông báo của mình thay cho bong bóng trình duyệt
            form.addEventListener('submit', function (e) {
                if (!validateForm(form)) e.preventDefault();
            });
            form.querySelectorAll('input, select, textarea').forEach(function (el) {
                if (!el.name || el.type === 'checkbox' || el.type === 'hidden') return;
                el.addEventListener('blur', function () { if (!isSkipped(el)) show(el, checkField(el)); });
            });
        });
    });
})();
