<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"
    import="java.util.List,java.util.ArrayList,Model.user.WarrantyRequest,Util.Html" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<c:set var="ctx" value="${pageContext.request.contextPath}" />
<c:set var="me" value="${sessionScope.loginUser}" />
<%
    @SuppressWarnings("unchecked")
    List<WarrantyRequest> list =
        (List<WarrantyRequest>) request.getAttribute("requests");

    if (list == null) {
        list = new ArrayList<>();
    }

    String ctxPath = request.getContextPath();
    String msg = request.getParameter("msg");
%>

<!DOCTYPE html>
<html class="dark" lang="vi">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Yêu cầu bảo hành - CoreTech</title>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Geist:wght@300..800&family=JetBrains+Mono:wght@400..600&display=swap" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="${ctx}/assets/js/home/tailwind-config.js"></script>
    <link rel="stylesheet" href="${ctx}/assets/css/home.css" />
    <style>
        body {
            font-family: 'Geist', system-ui, -apple-system, sans-serif;
            background-color: #070b14;
            color: #e6edf7;
        }

        .font-mono-tech {
            font-family: 'JetBrains Mono', monospace;
        }
    </style>
</head>

<body data-ctx="${ctx}" class="min-h-screen relative overflow-x-hidden selection:bg-sky-500/30 selection:text-sky-200">

    <!-- Ambient Glows -->
    <div class="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div class="absolute -top-32 left-1/2 -translate-x-1/2 w-[820px] h-[420px] rounded-full bg-sky-500/10 blur-[140px]"></div>
        <div class="absolute bottom-0 right-0 w-[520px] h-[520px] rounded-full bg-indigo-600/10 blur-[150px]"></div>
    </div>

    <!-- Top Bar -->
    <header class="sticky top-0 z-30 border-b border-slate-800/80 bg-slate-950/75 backdrop-blur-xl">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
            <a href="${ctx}/home" class="flex items-center gap-2.5 group">
                <span class="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-400 to-blue-600 flex items-center justify-center shadow-[0_0_20px_rgba(56,189,248,0.35)]">
                    <span class="material-symbols-outlined text-slate-950 text-[20px] font-bold">memory</span>
                </span>
                <span class="text-lg font-bold tracking-tight text-white group-hover:text-sky-300 transition-colors">
                    CoreTech
                </span>
                <span class="hidden sm:inline-block text-[11px] font-mono-tech uppercase tracking-widest text-sky-400/80 bg-sky-500/10 border border-sky-500/20 px-2 py-0.5 rounded-full">
                    Warranty Center
                </span>
            </a>

            <div class="flex items-center gap-2 sm:gap-3">
                <c:if test="${not empty me}">
                    <div class="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-slate-800 text-xs text-slate-300">
                        <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                        <span class="font-medium text-white"><c:out value="${me.fullName}" /></span>
                        <span class="font-mono-tech text-[10px] uppercase px-1.5 py-0.5 rounded bg-sky-500/15 text-sky-300">
                            <c:out value="${me.roleCode}" />
                        </span>
                    </div>
                </c:if>
                <a href="${ctx}/home"
                   class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-xs font-medium text-slate-200 transition-all">
                    <span class="material-symbols-outlined text-[16px] text-sky-400">home</span>
                    <span>Về trang chủ</span>
                </a>
                <c:if test="${not empty me}">
                    <a href="${ctx}/logout"
                       class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-xs font-medium text-rose-300 transition-all">
                        <span class="material-symbols-outlined text-[16px]">logout</span>
                        <span class="hidden sm:inline">Đăng xuất</span>
                    </a>
                </c:if>
            </div>
        </div>
    </header>

    <!-- Main Layout -->
    <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

            <!-- Left Sidebar -->
            <aside class="lg:col-span-4 xl:col-span-3 space-y-4">
                <div class="rounded-2xl bg-slate-900/75 backdrop-blur-xl border border-slate-800/90 p-5 shadow-xl">
                    <div class="flex items-center gap-3 pb-4 border-b border-slate-800/80">
                        <div class="w-11 h-11 rounded-2xl bg-gradient-to-br from-sky-400/25 to-blue-600/25 border border-sky-400/30 flex items-center justify-center text-sky-300 font-bold text-base">
                            <c:choose>
                                <c:when test="${not empty me and not empty me.fullName}">
                                    ${fn:substring(me.fullName, 0, 1)}
                                </c:when>
                                <c:otherwise>K</c:otherwise>
                            </c:choose>
                        </div>
                        <div class="min-w-0">
                            <p class="text-[11px] font-mono-tech uppercase tracking-wider text-slate-400">Tài khoản</p>
                            <h2 class="text-sm font-semibold text-white truncate">
                                <c:choose>
                                    <c:when test="${not empty me}"><c:out value="${me.fullName}" /></c:when>
                                    <c:otherwise>Khách hàng</c:otherwise>
                                </c:choose>
                            </h2>
                            <span class="inline-block mt-0.5 text-[10px] font-mono-tech uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-sky-300 border border-slate-700/70">
                                <c:choose>
                                    <c:when test="${not empty me}"><c:out value="${me.roleCode}" /></c:when>
                                    <c:otherwise>CUSTOMER</c:otherwise>
                                </c:choose>
                            </span>
                        </div>
                    </div>

                    <nav class="mt-4 space-y-1.5 text-sm">
                        <a href="${ctx}/user/order"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all">
                            <span class="material-symbols-outlined text-[19px] text-sky-400">receipt_long</span>
                            <span>Đơn hàng của tôi</span>
                        </a>
                        <a href="${ctx}/user/address"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all">
                            <span class="material-symbols-outlined text-[19px] text-indigo-400">location_on</span>
                            <span>Địa chỉ nhận hàng</span>
                        </a>
                        <a href="${ctx}/user/warranty"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl bg-sky-500/15 text-sky-300 border border-sky-500/30 font-medium">
                            <span class="material-symbols-outlined text-[19px]">verified_user</span>
                            <span>Yêu cầu bảo hành</span>
                        </a>
                        <a href="${ctx}/user/order/chatbot.jsp"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all">
                            <span class="material-symbols-outlined text-[19px] text-emerald-400">smart_toy</span>
                            <span>Chatbot tư vấn</span>
                        </a>
                    </nav>
                </div>

                <!-- Chính sách bảo hành tóm tắt -->
                <div class="rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 space-y-2.5 text-xs text-slate-300">
                    <div class="flex items-center gap-2 font-mono-tech uppercase tracking-wider text-sky-300">
                        <span class="material-symbols-outlined text-[16px]">info</span>
                        <span>Lưu ý gửi bảo hành</span>
                    </div>
                    <p class="text-slate-400 leading-relaxed">
                        Nhập chính xác <span class="text-slate-200 font-medium">Mã đơn hàng</span> và <span class="text-slate-200 font-medium">Mã sản phẩm</span> để kỹ thuật viên kiểm tra thời hạn bảo hành nhanh nhất.
                    </p>
                </div>
            </aside>

            <!-- Main Content -->
            <main class="lg:col-span-8 xl:col-span-9 space-y-6">

                <!-- Header -->
                <div class="flex flex-wrap items-center justify-between gap-3">
                    <div>
                        <p class="text-[11px] font-mono-tech uppercase tracking-widest text-sky-400">RMA &amp; Technical Support</p>
                        <h1 class="text-2xl font-bold text-white tracking-tight mt-0.5">Yêu cầu bảo hành</h1>
                        <p class="text-xs text-slate-400 mt-1">Gửi yêu cầu bảo hành khi linh kiện hoặc thiết bị gặp sự cố kỹ thuật.</p>
                    </div>
                    <span class="px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-800 text-xs font-mono-tech text-slate-300">
                        <%= list.size() %> phiếu bảo hành
                    </span>
                </div>

                <!-- Thông báo kết quả -->
                <% if ("ok".equals(msg)) { %>
                    <div class="flex items-center gap-3 p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/35 text-emerald-300 text-sm">
                        <span class="material-symbols-outlined text-[20px]">check_circle</span>
                        <span>Đã gửi yêu cầu bảo hành thành công! Đội ngũ kỹ thuật sẽ phản hồi sớm nhất.</span>
                    </div>
                <% } else if ("error".equals(msg)) { %>
                    <div class="flex items-center gap-3 p-4 rounded-2xl bg-rose-500/15 border border-rose-500/35 text-rose-300 text-sm">
                        <span class="material-symbols-outlined text-[20px]">error</span>
                        <span>Gửi yêu cầu thất bại. Vui lòng kiểm tra lại mã đơn hàng / mã sản phẩm và thử lại.</span>
                    </div>
                <% } %>

                <!-- Form gửi yêu cầu -->
                <form method="post"
                      action="<%= ctxPath %>/user/warranty"
                      class="rounded-3xl bg-slate-900/75 backdrop-blur-2xl border border-slate-800/90 p-5 sm:p-6 shadow-xl space-y-4">

                    <div class="flex items-center gap-2.5 pb-3 border-b border-slate-800/80">
                        <span class="w-9 h-9 rounded-xl bg-sky-500/15 border border-sky-400/30 flex items-center justify-center text-sky-300">
                            <span class="material-symbols-outlined text-[20px]">build_circle</span>
                        </span>
                        <div>
                            <h3 class="text-base font-bold text-white">Gửi yêu cầu bảo hành mới</h3>
                            <p class="text-xs text-slate-400">Điền thông tin linh kiện cần tiếp nhận xử lý</p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-mono-tech uppercase tracking-wider text-slate-400 mb-1.5">
                                Mã đơn hàng
                            </label>
                            <input type="number"
                                   name="orderId"
                                   placeholder="Nhập mã đơn hàng (VD: 1024)"
                                   min="1"
                                   required
                                   class="w-full rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-sky-400 focus:ring-2 focus:ring-sky-400/20 px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none transition-all">
                        </div>

                        <div>
                            <label class="block text-xs font-mono-tech uppercase tracking-wider text-slate-400 mb-1.5">
                                Mã sản phẩm
                            </label>
                            <input type="number"
                                   name="productId"
                                   placeholder="Nhập mã sản phẩm (VD: 15)"
                                   min="1"
                                   required
                                   class="w-full rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-sky-400 focus:ring-2 focus:ring-sky-400/20 px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none transition-all">
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs font-mono-tech uppercase tracking-wider text-slate-400 mb-1.5">
                            Mô tả lỗi sản phẩm
                        </label>
                        <textarea name="description"
                                  rows="4"
                                  placeholder="Mô tả chi tiết tình trạng lỗi, hiện tượng khi hoạt động..."
                                  required
                                  class="w-full rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-sky-400 focus:ring-2 focus:ring-sky-400/20 px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none transition-all resize-y"></textarea>
                    </div>

                    <div class="flex justify-end pt-1">
                        <button type="submit"
                                class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-400 to-blue-600 hover:from-sky-300 hover:to-blue-500 text-slate-950 font-semibold text-sm shadow-[0_0_20px_rgba(56,189,248,0.3)] active:scale-[0.98] transition-all cursor-pointer">
                            <span class="material-symbols-outlined text-[18px]">send</span>
                            <span>Gửi yêu cầu bảo hành</span>
                        </button>
                    </div>

                </form>

                <!-- Lịch sử bảo hành -->
                <div class="space-y-3">
                    <h3 class="text-base font-bold text-white flex items-center gap-2">
                        <span class="material-symbols-outlined text-sky-400 text-[20px]">history</span>
                        <span>Lịch sử yêu cầu bảo hành</span>
                    </h3>

                    <% for (WarrantyRequest w : list) {
                        String rawStatus = w.getStatus() != null ? w.getStatus().trim() : "";
                        String upperStatus = rawStatus.toUpperCase();
                        String badgeClass = "bg-slate-800 text-slate-200 border-slate-700";
                        if (upperStatus.contains("DONE") || upperStatus.contains("COMPLETE") || upperStatus.contains("HOÀN")) {
                            badgeClass = "bg-emerald-500/15 text-emerald-300 border-emerald-500/30";
                        } else if (upperStatus.contains("REJECT") || upperStatus.contains("CANCEL") || upperStatus.contains("TỪ CHỐI")) {
                            badgeClass = "bg-rose-500/15 text-rose-300 border-rose-500/30";
                        } else if (upperStatus.contains("PROCESS") || upperStatus.contains("APPROV") || upperStatus.contains("ĐANG")) {
                            badgeClass = "bg-sky-500/15 text-sky-300 border-sky-500/30";
                        } else {
                            badgeClass = "bg-amber-500/15 text-amber-300 border-amber-500/30";
                        }
                    %>

                        <div class="rounded-2xl bg-slate-900/75 backdrop-blur-xl border border-slate-800/90 p-5 space-y-3 hover:border-slate-700 transition-all">

                            <div class="flex flex-wrap items-center justify-between gap-2">
                                <div class="flex items-center gap-2.5">
                                    <span class="font-mono-tech text-sm font-bold text-white">
                                        Yêu cầu #<%= w.getRequestId() %>
                                    </span>
                                    <span class="px-2.5 py-0.5 rounded-full border text-xs font-medium <%= badgeClass %>">
                                        <%= Html.esc(rawStatus.isEmpty() ? "Đang chờ xử lý" : rawStatus) %>
                                    </span>
                                </div>

                                <div class="flex items-center gap-1.5 text-xs text-slate-400 font-mono-tech">
                                    <span class="material-symbols-outlined text-[15px] text-slate-500">schedule</span>
                                    <span>
                                        <%= w.getCreatedAt() != null ? w.getCreatedAt() : "Chưa xác định" %>
                                    </span>
                                </div>
                            </div>

                            <div class="flex flex-wrap items-center gap-3 text-xs">
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-300 font-mono-tech">
                                    <span class="text-slate-500">Đơn hàng:</span>
                                    <strong class="text-sky-300">#<%= w.getOrderId() %></strong>
                                </span>
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-300 font-mono-tech">
                                    <span class="text-slate-500">Sản phẩm:</span>
                                    <strong class="text-indigo-300">#<%= w.getProductId() %></strong>
                                </span>
                            </div>

                            <div class="rounded-xl bg-slate-950/70 border border-slate-800/80 p-3.5 text-sm text-slate-200 leading-relaxed">
                                <p class="text-[11px] font-mono-tech uppercase tracking-wider text-slate-400 mb-1">Mô tả lỗi</p>
                                <div><%= Html.esc(w.getDescription() != null ? w.getDescription() : "") %></div>
                            </div>

                        </div>

                    <% } %>

                    <% if (list.isEmpty()) { %>

                        <div class="rounded-2xl bg-slate-900/50 border border-dashed border-slate-800 p-8 text-center">
                            <span class="material-symbols-outlined text-slate-500 text-3xl mb-2">verified_user</span>
                            <h3 class="text-base font-semibold text-white">Chưa có yêu cầu bảo hành</h3>
                            <p class="text-xs text-slate-400 mt-1">Bạn chưa gửi yêu cầu bảo hành nào.</p>
                        </div>

                    <% } %>
                </div>

            </main>

        </div>
    </div>

</body>

</html>