<%@ page contentType="text/html;charset=UTF-8" language="java"
    import="java.util.List,java.util.ArrayList,Model.user.WarrantyRequest,Util.Html" %>

<%
    @SuppressWarnings("unchecked")
    List<WarrantyRequest> list =
        (List<WarrantyRequest>) request.getAttribute("requests");

    if (list == null) {
        list = new ArrayList<>();
    }

    String ctx = request.getContextPath();
    String msg = request.getParameter("msg");
%>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Yêu cầu bảo hành</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1100px;
            margin: 30px auto;
            padding: 0 16px;
            background: #f8f9fa;
        }

        .layout {
            display: flex;
            gap: 20px;
            align-items: flex-start;
        }

        .content {
            flex: 1;
            min-width: 0;
        }

        h2, h3 {
            color: #222;
        }

        .card {
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 16px;
            margin: 12px 0;
        }

        input, textarea {
            padding: 10px;
            margin: 6px 0 12px;
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        textarea {
            resize: vertical;
        }

        button {
            padding: 10px 18px;
            cursor: pointer;
            border: none;
            border-radius: 5px;
            background: #2563eb;
            color: white;
        }

        button:hover {
            opacity: 0.85;
        }

        .muted {
            color: #777;
            font-size: 13px;
        }

        .success {
            color: #155724;
            background: #d4edda;
            padding: 12px;
            border-radius: 5px;
            margin: 12px 0;
        }

        .error {
            color: #721c24;
            background: #f8d7da;
            padding: 12px;
            border-radius: 5px;
            margin: 12px 0;
        }

        .warranty-title {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 15px;
            background: #e9ecef;
            color: #333;
            font-size: 13px;
        }

        .empty {
            background: white;
            border: 1px dashed #ccc;
            border-radius: 8px;
            padding: 25px;
            text-align: center;
            color: #777;
        }

        @media (max-width: 700px) {
            .layout {
                flex-direction: column;
            }

            .content {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<div class="layout">

    <jsp:include page="/user/sidebar.jsp" />

    <div class="content">

        <h2>Yêu cầu bảo hành</h2>

        <p class="muted">
            Gửi yêu cầu bảo hành khi sản phẩm gặp sự cố.
        </p>

        <!-- Thông báo kết quả -->
        <% if ("ok".equals(msg)) { %>

            <div class="success">
                Đã gửi yêu cầu bảo hành thành công!
            </div>

        <% } else if ("error".equals(msg)) { %>

            <div class="error">
                Gửi yêu cầu thất bại. Vui lòng thử lại.
            </div>

        <% } %>

        <!-- Form gửi yêu cầu -->
        <form method="post"
              action="<%= ctx %>/user/warranty"
              class="card">

            <h3>Gửi yêu cầu bảo hành mới</h3>

            <label><b>Mã đơn hàng</b></label>

            <input type="number"
                   name="orderId"
                   placeholder="Nhập mã đơn hàng"
                   min="1"
                   required>

            <label><b>Mã sản phẩm</b></label>

            <input type="number"
                   name="productId"
                   placeholder="Nhập mã sản phẩm"
                   min="1"
                   required>

            <label><b>Mô tả lỗi sản phẩm</b></label>

            <textarea name="description"
                      rows="4"
                      placeholder="Mô tả chi tiết tình trạng sản phẩm..."
                      required></textarea>

            <button type="submit">
                Gửi yêu cầu bảo hành
            </button>

        </form>

        <!-- Lịch sử bảo hành -->
        <h3>Lịch sử yêu cầu bảo hành</h3>

        <% for (WarrantyRequest w : list) { %>

            <div class="card">

                <div class="warranty-title">

                    <b>
                        Yêu cầu #<%= w.getRequestId() %>
                    </b>

                    <span class="status">
                        <%= Html.esc(w.getStatus() != null ? w.getStatus() : "") %>
                    </span>

                </div>

                <p>
                    <b>Mã đơn hàng:</b>
                    <%= w.getOrderId() %>
                </p>

                <p>
                    <b>Mã sản phẩm:</b>
                    <%= w.getProductId() %>
                </p>

                <p>
                    <b>Mô tả lỗi:</b>
                </p>

                <div>
                    <%= Html.esc(w.getDescription() != null ? w.getDescription() : "") %>
                </div>

                <div class="muted" style="margin-top: 12px;">
                    Ngày gửi:
                    <%= w.getCreatedAt() != null
                        ? w.getCreatedAt() : "Chưa xác định" %>
                </div>

            </div>

        <% } %>

        <% if (list.isEmpty()) { %>

            <div class="empty">
                <h3>Chưa có yêu cầu bảo hành</h3>
                <p>Bạn chưa gửi yêu cầu bảo hành nào.</p>
            </div>

        <% } %>

    </div>

</div>

</body>
</html>