<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"
    import="java.util.List,java.util.ArrayList,Model.user.CustomerAddress,Util.Html" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<c:set var="ctx" value="${pageContext.request.contextPath}" />
<c:set var="me" value="${sessionScope.loginUser}" />
<%
    @SuppressWarnings("unchecked")
    List<CustomerAddress> list =
        (List<CustomerAddress>) request.getAttribute("addresses");

    String ctxPath = request.getContextPath();

    if (list == null) {
        list = new ArrayList<>();
    }
%>

<!DOCTYPE html>
<html class="dark" lang="vi">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Địa chỉ nhận hàng - CoreTech</title>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Geist:wght@300..800&family=JetBrains+Mono:wght@400..600&display=swap" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="${ctx}/assets/js/home/tailwind-config.js"></script>
    <link rel="stylesheet" href="${ctx}/assets/css/home.css" />
    <style>
        body {
            font-family: 'Geist', system-ui, -apple-system, sans-serif;
            background-color: #070b14;
            color: #e6edf7;
        }

        .font-mono-tech {
            font-family: 'JetBrains Mono', monospace;
        }
    </style>
</head>

<body data-ctx="${ctx}" class="min-h-screen relative overflow-x-hidden selection:bg-sky-500/30 selection:text-sky-200">

    <!-- Ambient Glows -->
    <div class="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div class="absolute -top-32 left-1/2 -translate-x-1/2 w-[820px] h-[420px] rounded-full bg-sky-500/10 blur-[140px]"></div>
        <div class="absolute bottom-0 right-0 w-[520px] h-[520px] rounded-full bg-indigo-600/10 blur-[150px]"></div>
    </div>

    <!-- Top Bar -->
    <header class="sticky top-0 z-30 border-b border-slate-800/80 bg-slate-950/75 backdrop-blur-xl">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
            <a href="${ctx}/home" class="flex items-center gap-2.5 group">
                <span class="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-400 to-blue-600 flex items-center justify-center shadow-[0_0_20px_rgba(56,189,248,0.35)]">
                    <span class="material-symbols-outlined text-slate-950 text-[20px] font-bold">memory</span>
                </span>
                <span class="text-lg font-bold tracking-tight text-white group-hover:text-sky-300 transition-colors">
                    CoreTech
                </span>
                <span class="hidden sm:inline-block text-[11px] font-mono-tech uppercase tracking-widest text-sky-400/80 bg-sky-500/10 border border-sky-500/20 px-2 py-0.5 rounded-full">
                    Address Book
                </span>
            </a>

            <div class="flex items-center gap-2 sm:gap-3">
                <c:if test="${not empty me}">
                    <div class="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-slate-800 text-xs text-slate-300">
                        <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                        <span class="font-medium text-white"><c:out value="${me.fullName}" /></span>
                        <span class="font-mono-tech text-[10px] uppercase px-1.5 py-0.5 rounded bg-sky-500/15 text-sky-300">
                            <c:out value="${me.roleCode}" />
                        </span>
                    </div>
                </c:if>
                <a href="${ctx}/home"
                   class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-xs font-medium text-slate-200 transition-all">
                    <span class="material-symbols-outlined text-[16px] text-sky-400">home</span>
                    <span>Về trang chủ</span>
                </a>
                <c:if test="${not empty me}">
                    <a href="${ctx}/logout"
                       class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-xs font-medium text-rose-300 transition-all">
                        <span class="material-symbols-outlined text-[16px]">logout</span>
                        <span class="hidden sm:inline">Đăng xuất</span>
                    </a>
                </c:if>
            </div>
        </div>
    </header>

    <!-- Main Layout -->
    <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

            <!-- Left Sidebar -->
            <aside class="lg:col-span-4 xl:col-span-3 space-y-4">
                <div class="rounded-2xl bg-slate-900/75 backdrop-blur-xl border border-slate-800/90 p-5 shadow-xl">
                    <div class="flex items-center gap-3 pb-4 border-b border-slate-800/80">
                        <div class="w-11 h-11 rounded-2xl bg-gradient-to-br from-sky-400/25 to-blue-600/25 border border-sky-400/30 flex items-center justify-center text-sky-300 font-bold text-base">
                            <c:choose>
                                <c:when test="${not empty me and not empty me.fullName}">
                                    ${fn:substring(me.fullName, 0, 1)}
                                </c:when>
                                <c:otherwise>K</c:otherwise>
                            </c:choose>
                        </div>
                        <div class="min-w-0">
                            <p class="text-[11px] font-mono-tech uppercase tracking-wider text-slate-400">Tài khoản</p>
                            <h2 class="text-sm font-semibold text-white truncate">
                                <c:choose>
                                    <c:when test="${not empty me}"><c:out value="${me.fullName}" /></c:when>
                                    <c:otherwise>Khách hàng</c:otherwise>
                                </c:choose>
                            </h2>
                            <span class="inline-block mt-0.5 text-[10px] font-mono-tech uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-sky-300 border border-slate-700/70">
                                <c:choose>
                                    <c:when test="${not empty me}"><c:out value="${me.roleCode}" /></c:when>
                                    <c:otherwise>CUSTOMER</c:otherwise>
                                </c:choose>
                            </span>
                        </div>
                    </div>

                    <nav class="mt-4 space-y-1.5 text-sm">
                        <a href="${ctx}/user/order"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all">
                            <span class="material-symbols-outlined text-[19px] text-sky-400">receipt_long</span>
                            <span>Đơn hàng của tôi</span>
                        </a>
                        <a href="${ctx}/user/address"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl bg-sky-500/15 text-sky-300 border border-sky-500/30 font-medium">
                            <span class="material-symbols-outlined text-[19px]">location_on</span>
                            <span>Địa chỉ nhận hàng</span>
                        </a>
                        <a href="${ctx}/user/order/chatbot.jsp"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all">
                            <span class="material-symbols-outlined text-[19px] text-emerald-400">smart_toy</span>
                            <span>Chatbot tư vấn</span>
                        </a>
                    </nav>
                </div>
            </aside>

            <!-- Main Content -->
            <main class="lg:col-span-8 xl:col-span-9 space-y-6">

                <!-- Page Title -->
                <div class="flex flex-wrap items-center justify-between gap-3">
                    <div>
                        <p class="text-[11px] font-mono-tech uppercase tracking-widest text-sky-400">Delivery Settings</p>
                        <h1 class="text-2xl font-bold text-white tracking-tight mt-0.5">Địa chỉ nhận hàng</h1>
                    </div>
                    <span class="px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-800 text-xs font-mono-tech text-slate-300">
                        <%= list.size() %> địa chỉ đã lưu
                    </span>
                </div>

                <!-- Form thêm địa chỉ -->
                <form method="post"
                      action="<%= ctxPath %>/user/address"
                      class="rounded-3xl bg-slate-900/75 backdrop-blur-2xl border border-slate-800/90 p-5 sm:p-6 shadow-xl space-y-4">

                    <input type="hidden" name="action" value="add">

                    <div class="flex items-center gap-2.5 pb-3 border-b border-slate-800/80">
                        <span class="w-9 h-9 rounded-xl bg-sky-500/15 border border-sky-400/30 flex items-center justify-center text-sky-300">
                            <span class="material-symbols-outlined text-[20px]">add_location_alt</span>
                        </span>
                        <div>
                            <h3 class="text-base font-bold text-white">Thêm địa chỉ mới</h3>
                            <p class="text-xs text-slate-400">Thông tin người nhận và địa chỉ giao linh kiện</p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-mono-tech uppercase tracking-wider text-slate-400 mb-1.5">
                                Tên người nhận
                            </label>
                            <input type="text"
                                   name="receiverName"
                                   placeholder="Ví dụ: Nguyễn Văn A"
                                   required
                                   class="w-full rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-sky-400 focus:ring-2 focus:ring-sky-400/20 px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none transition-all">
                        </div>

                        <div>
                            <label class="block text-xs font-mono-tech uppercase tracking-wider text-slate-400 mb-1.5">
                                Số điện thoại
                            </label>
                            <input type="tel"
                                   name="phone"
                                   placeholder="Ví dụ: 0901234567"
                                   required
                                   class="w-full rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-sky-400 focus:ring-2 focus:ring-sky-400/20 px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none transition-all">
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs font-mono-tech uppercase tracking-wider text-slate-400 mb-1.5">
                            Địa chỉ chi tiết
                        </label>
                        <input type="text"
                               name="addressLine"
                               placeholder="Số nhà, đường, phường/xã, quận/huyện, tỉnh/thành phố..."
                               required
                               class="w-full rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-sky-400 focus:ring-2 focus:ring-sky-400/20 px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none transition-all">
                    </div>

                    <div class="flex flex-wrap items-center justify-between gap-4 pt-1">
                        <label class="inline-flex items-center gap-2.5 text-sm text-slate-300 cursor-pointer select-none">
                            <input type="checkbox"
                                   name="isDefault"
                                   value="true"
                                   class="w-4 h-4 rounded accent-sky-400 bg-slate-900 border-slate-700">
                            <span>Đặt làm địa chỉ mặc định</span>
                        </label>

                        <button type="submit"
                                class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-400 to-blue-600 hover:from-sky-300 hover:to-blue-50 text-slate-950 font-semibold text-sm shadow-[0_0_20px_rgba(56,189,248,0.3)] active:scale-[0.98] transition-all cursor-pointer">
                            <span class="material-symbols-outlined text-[18px]">add</span>
                            <span>Thêm địa chỉ</span>
                        </button>
                    </div>

                </form>

                <!-- Danh sách địa chỉ -->
                <div class="space-y-3">
                    <h3 class="text-base font-bold text-white flex items-center gap-2">
                        <span class="material-symbols-outlined text-sky-400 text-[20px]">pin_drop</span>
                        <span>Danh sách địa chỉ của tôi</span>
                    </h3>

                    <% for (CustomerAddress a : list) { %>

                        <div class="rounded-2xl bg-slate-900/75 backdrop-blur-xl border <%= a.isDefaultAddress() ? "border-emerald-500/40 shadow-[0_0_25px_rgba(16,185,129,0.08)]" : "border-slate-800/90" %> p-5 transition-all">

                            <div class="flex flex-wrap items-center justify-between gap-2">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <span class="text-base font-semibold text-white">
                                        <%= Html.esc(a.getReceiverName() != null ? a.getReceiverName() : "") %>
                                    </span>
                                    <span class="text-slate-600">•</span>
                                    <span class="font-mono-tech text-xs text-sky-300 bg-sky-500/10 border border-sky-500/20 px-2.5 py-0.5 rounded-full">
                                        <%= Html.esc(a.getPhone() != null ? a.getPhone() : "") %>
                                    </span>
                                </div>

                                <% if (a.isDefaultAddress()) { %>
                                    <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-medium">
                                        <span class="material-symbols-outlined text-[15px]">check_circle</span>
                                        Mặc định
                                    </span>
                                <% } %>
                            </div>

                            <div class="mt-2.5 flex items-start gap-2 text-sm text-slate-300">
                                <span class="material-symbols-outlined text-slate-400 text-[18px] mt-0.5 shrink-0">home_pin</span>
                                <span><%= Html.esc(a.getAddressLine() != null ? a.getAddressLine() : "") %></span>
                            </div>

                            <div class="flex flex-wrap items-center gap-2.5 mt-4 pt-3.5 border-t border-slate-800/80">

                                <form method="post"
                                      action="<%= ctxPath %>/user/address"
                                      class="inline">

                                    <input type="hidden"
                                           name="id"
                                           value="<%= a.getAddressId() %>">

                                    <% if (!a.isDefaultAddress()) { %>

                                        <button type="submit"
                                                name="action"
                                                value="default"
                                                class="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-xs font-medium transition-all cursor-pointer">
                                            <span class="material-symbols-outlined text-[16px]">verified</span>
                                            <span>Đặt mặc định</span>
                                        </button>

                                    <% } %>

                                </form>

                                <form method="post"
                                      action="<%= ctxPath %>/user/address"
                                      onsubmit="return confirm('Bạn có chắc chắn muốn xóa địa chỉ này?');"
                                      class="inline">

                                    <input type="hidden"
                                           name="id"
                                           value="<%= a.getAddressId() %>">

                                    <button type="submit"
                                            name="action"
                                            value="delete"
                                            class="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs font-medium transition-all cursor-pointer">
                                        <span class="material-symbols-outlined text-[16px]">delete</span>
                                        <span>Xóa</span>
                                    </button>

                                </form>

                            </div>

                        </div>

                    <% } %>

                    <% if (list.isEmpty()) { %>

                        <div class="rounded-2xl bg-slate-900/50 border border-dashed border-slate-800 p-8 text-center">
                            <span class="material-symbols-outlined text-slate-500 text-3xl mb-2">location_off</span>
                            <p class="text-sm text-slate-400">
                                Chưa có địa chỉ nhận hàng nào.
                            </p>
                        </div>

                    <% } %>
                </div>

            </main>

        </div>
    </div>

</body>

</html>