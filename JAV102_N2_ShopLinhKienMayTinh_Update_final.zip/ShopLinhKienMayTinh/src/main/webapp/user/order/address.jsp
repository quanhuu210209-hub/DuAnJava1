<%@ page contentType="text/html;charset=UTF-8" language="java"
    import="java.util.List,java.util.ArrayList,Model.user.CustomerAddress,Util.Html" %>

<%
    @SuppressWarnings("unchecked")
    List<CustomerAddress> list =
        (List<CustomerAddress>) request.getAttribute("addresses");

    String ctx = request.getContextPath();

    if (list == null) {
        list = new ArrayList<>();
    }
%>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Địa chỉ nhận hàng</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1100px;
            margin: 30px auto;
            padding: 0 16px;
            background: #f8f9fa;
        }

        .layout {
            display: flex;
            gap: 20px;
            align-items: flex-start;
        }

        .content {
            flex: 1;
            min-width: 0;
        }

        input, textarea, select {
            padding: 10px;
            margin: 6px 0;
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        input[type="checkbox"] {
            width: auto;
        }

        button {
            padding: 9px 15px;
            cursor: pointer;
            border: none;
            border-radius: 5px;
            background: #2563eb;
            color: white;
        }

        button:hover {
            opacity: 0.85;
        }

        .delete-btn {
            background: #dc3545;
        }

        .default-btn {
            background: #198754;
        }

        .card {
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 16px;
            margin: 12px 0;
        }

        .muted {
            color: #777;
            font-size: 13px;
        }

        .default-label {
            color: green;
            font-weight: bold;
        }

        .address-actions {
            display: flex;
            gap: 8px;
            margin-top: 12px;
        }
    </style>
</head>

<body>

<div class="layout">

    <jsp:include page="/user/sidebar.jsp" />

    <div class="content">

        <h2>Địa chỉ nhận hàng</h2>

        <!-- Form thêm địa chỉ -->
        <form method="post"
              action="<%= ctx %>/user/address"
              class="card">

            <input type="hidden" name="action" value="add">

            <h3>Thêm địa chỉ mới</h3>

            <input type="text"
                   name="receiverName"
                   placeholder="Tên người nhận"
                   required>

            <input type="tel"
                   name="phone"
                   placeholder="Số điện thoại"
                   required>

            <input type="text"
                   name="addressLine"
                   placeholder="Địa chỉ chi tiết"
                   required>

            <label>
                <input type="checkbox"
                       name="isDefault"
                       value="true">
                Đặt làm địa chỉ mặc định
            </label>

            <br><br>

            <button type="submit">Thêm địa chỉ</button>

        </form>

        <!-- Danh sách địa chỉ -->
        <h3>Danh sách địa chỉ của tôi</h3>

        <% for (CustomerAddress a : list) { %>

            <div class="card">

                <b>
                    <%= Html.esc(a.getReceiverName() != null ? a.getReceiverName() : "") %>
                </b>

                -
                <%= Html.esc(a.getPhone() != null ? a.getPhone() : "") %>

                <% if (a.isDefaultAddress()) { %>
                    <span class="default-label">
                        (Mặc định)
                    </span>
                <% } %>

                <div style="margin-top: 8px;">
                    <%= Html.esc(a.getAddressLine() != null ? a.getAddressLine() : "") %>
                </div>

                <div class="address-actions">

                    <form method="post"
                          action="<%= ctx %>/user/address">

                        <input type="hidden"
                               name="id"
                               value="<%= a.getAddressId() %>">

                        <% if (!a.isDefaultAddress()) { %>

                            <button type="submit"
                                    name="action"
                                    value="default"
                                    class="default-btn">
                                Đặt mặc định
                            </button>

                        <% } %>

                    </form>

                    <form method="post"
                          action="<%= ctx %>/user/address"
                          onsubmit="return confirm('Bạn có chắc chắn muốn xóa địa chỉ này?');">

                        <input type="hidden"
                               name="id"
                               value="<%= a.getAddressId() %>">

                        <button type="submit"
                                name="action"
                                value="delete"
                                class="delete-btn">
                            Xóa
                        </button>

                    </form>

                </div>

            </div>

        <% } %>

        <% if (list.isEmpty()) { %>

            <p class="muted">
                Chưa có địa chỉ nhận hàng nào.
            </p>

        <% } %>

    </div>

</div>

</body>
</html>