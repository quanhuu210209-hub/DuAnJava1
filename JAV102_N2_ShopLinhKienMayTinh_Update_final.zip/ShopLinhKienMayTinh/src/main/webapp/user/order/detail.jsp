<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chi tiết đơn hàng — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/user.css">
</head>
<body>

<%@ include file="/user/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Đơn hàng <c:out value="${order.orderCode}"/></h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <p><a href="${pageContext.request.contextPath}/user/order">&larr; Đơn của tôi</a></p>
    <div class="table-card"><table>
        <tr><th>Trạng thái</th><td><t:orderStatus value="${order.status}"/></td></tr>
        <tr>
          <th>Thanh toán</th>
          <td>
            <c:choose>
              <c:when test="${order.paymentStatus eq 'Paid'}">Đã thanh toán</c:when>
              <c:otherwise>Chưa thanh toán</c:otherwise>
            </c:choose>
          </td>
        </tr>
        <tr><th>Người nhận</th><td><c:out value="${order.receiverName}"/> - <c:out value="${order.receiverPhone}"/></td></tr>
        <tr><th>Địa chỉ giao</th><td><c:out value="${order.shippingAddress}"/></td></tr>
        <tr><th>Ngày đặt</th><td><t:dt value="${order.createdAt}"/></td></tr>
        <c:if test="${order.status eq 'Cancelled' and not empty order.cancelReason}">
          <tr><th>Lý do hủy</th><td><c:out value="${order.cancelReason}"/></td></tr>
        </c:if>
    </table></div>

    <c:if test="${order.paymentStatus ne 'Paid' and order.status ne 'Cancelled'}">
      <div class="table-card">
        <h3>Thanh toán đơn hàng</h3>
        <form method="post" action="${pageContext.request.contextPath}/user/order">
          <input type="hidden" name="action" value="pay">
          <input type="hidden" name="orderId" value="${order.orderId}">
          <p>
            <label for="paymentMethodId">Phương thức thanh toán:</label>
            <select id="paymentMethodId" name="paymentMethodId" required>
              <c:forEach var="pm" items="${paymentMethods}">
                <option value="${pm.paymentMethodId}">
                  <c:out value="${pm.methodName}"/> (<c:out value="${pm.methodCode}"/>)
                </option>
              </c:forEach>
            </select>
          </p>
          <p>Số tiền thanh toán: <strong><t:money value="${order.totalAmount}"/></strong></p>
          <button type="submit" class="btn btn-primary">Xác nhận thanh toán</button>
        </form>
      </div>
    </c:if>

    <c:if test="${order.status eq 'Pending' or order.status eq 'Paid'}">
      <div class="table-card">
        <h3>Hủy đơn hàng</h3>
        <form method="post" action="${pageContext.request.contextPath}/user/order"
              onsubmit="return confirm('Bạn chắc chắn muốn hủy đơn hàng này?');">
          <input type="hidden" name="action" value="cancel">
          <input type="hidden" name="orderId" value="${order.orderId}">
          <p>
            <label for="cancelReason">Lý do hủy:</label>
            <input type="text" id="cancelReason" name="cancelReason" placeholder="Nhập lý do hủy (không bắt buộc)">
          </p>
          <button type="submit" class="btn btn-danger">Hủy đơn hàng</button>
        </form>
      </div>
    </c:if>

    <div class="table-card"><table>
        <thead><tr><th>Sản phẩm</th><th>Số lượng</th><th>Đơn giá</th><th>Thành tiền</th></tr></thead>
        <tbody>
        <c:forEach var="d" items="${order.details}">
            <tr>
                <td><c:out value="${d.product.productName}"/></td>
                <td>${d.quantity}</td>
                <td><t:money value="${d.unitPrice}"/></td>
                <td><t:money value="${d.lineTotal}"/></td>
            </tr>
        </c:forEach>
        </tbody>
        <tfoot><tr><th colspan="3">Tổng cộng</th><td><t:money value="${order.totalAmount}"/></td></tr></tfoot>
    </table></div>
  </div>
</div>
</body>
</html>