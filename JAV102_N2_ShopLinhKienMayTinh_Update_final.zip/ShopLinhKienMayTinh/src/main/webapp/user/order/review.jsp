
<%@ page contentType="text/html;charset=UTF-8" language="java"
    import="java.util.List,Model.user.ProductRating,Model.user.Review,Util.Html" %>

<%
    Object productIdObj = request.getAttribute("productId");

    int productId = productIdObj != null
            ? (Integer) productIdObj : 0;

    ProductRating pr =
            (ProductRating) request.getAttribute("rating");

    List<Review> reviews =
            (List<Review>) request.getAttribute("reviews");

    if (reviews == null) {
        reviews = new java.util.ArrayList<>();
    }

    String ctx = request.getContextPath();

    String msg = request.getParameter("msg");
%>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Đánh giá sản phẩm</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1100px;
            margin: 30px auto;
            padding: 0 16px;
            background: #f8f9fa;
        }

        .layout {
            display: flex;
            gap: 20px;
            align-items: flex-start;
        }

        .content {
            flex: 1;
            min-width: 0;
        }

        h2 {
            color: #222;
        }

        .card {
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 16px;
            margin: 12px 0;
        }

        input, textarea, select {
            padding: 10px;
            margin: 6px 0 12px;
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        textarea {
            resize: vertical;
        }

        button {
            padding: 10px 18px;
            cursor: pointer;
            border: none;
            border-radius: 5px;
            background: #2563eb;
            color: white;
        }

        button:hover {
            opacity: 0.85;
        }

        .muted {
            color: #777;
            font-size: 13px;
        }

        .rating-summary {
            background: #fff8e1;
            border: 1px solid #f0d98c;
            border-radius: 8px;
            padding: 16px;
            margin: 15px 0;
        }

        .rating-number {
            color: #e5a000;
            font-size: 24px;
            font-weight: bold;
        }

        .stars {
            color: #f5a623;
            font-size: 20px;
        }

        .success {
            color: #198754;
            background: #d1e7dd;
            padding: 12px;
            border-radius: 5px;
            margin: 12px 0;
        }

        .error {
            color: #dc3545;
            background: #f8d7da;
            padding: 12px;
            border-radius: 5px;
            margin: 12px 0;
        }

        .empty {
            text-align: center;
            color: #777;
            padding: 25px;
            background: white;
            border-radius: 8px;
        }

        .review-comment {
            line-height: 1.6;
            margin-top: 10px;
            white-space: pre-wrap;
            overflow-wrap: anywhere;
        }

        @media (max-width: 700px) {
            .layout {
                flex-direction: column;
            }

            .content {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<div class="layout">

    <jsp:include page="/user/sidebar.jsp" />

    <div class="content">

        <h2>Đánh giá sản phẩm #<%= productId %></h2>

        <!-- Thống kê đánh giá -->
        <div class="rating-summary">

            <% if (pr != null) { %>

                <div class="rating-number">
                    <%= String.format("%.1f", pr.avgRating) %> / 5 ★
                </div>

                <p>
                    Tổng cộng
                    <b><%= pr.totalReviews %></b>
                    đánh giá
                </p>

            <% } else { %>

                <p>Chưa có thông tin đánh giá sản phẩm.</p>

            <% } %>

        </div>

        <!-- Thông báo -->
        <% if ("pending".equals(msg)) { %>

            <div class="success">
                Đã gửi đánh giá! Đánh giá sẽ hiển thị sau khi được duyệt.
            </div>

        <% } else if ("error".equals(msg)) { %>

            <div class="error">
                Gửi đánh giá thất bại. Vui lòng thử lại.
            </div>

        <% } %>

        <!-- Form gửi đánh giá -->
        <form method="post"
              action="<%= ctx %>/user/review"
              class="card">

            <h3>Viết đánh giá của bạn</h3>

            <input type="hidden"
                   name="productId"
                   value="<%= productId %>">

            <label><b>Số sao đánh giá</b></label>

            <select name="rating" required>

                <option value="5">5 ★ - Rất tốt</option>
                <option value="4">4 ★ - Tốt</option>
                <option value="3">3 ★ - Bình thường</option>
                <option value="2">2 ★ - Không tốt</option>
                <option value="1">1 ★ - Rất tệ</option>

            </select>

            <label><b>Nhận xét sản phẩm</b></label>

            <textarea name="comment"
                      rows="4"
                      placeholder="Chia sẻ trải nghiệm của bạn về sản phẩm..."
                      required></textarea>

            <button type="submit">
                Gửi đánh giá
            </button>

        </form>

        <!-- Danh sách đánh giá -->
        <h3>Đánh giá từ khách hàng</h3>

        
<% for (Review r : reviews) { %>

    <div class="card">

        <div class="stars">
            <%= "★".repeat(Math.max(0, Math.min(5, r.getRating()))) %>
        </div>

        <div class="muted">
            Thời gian:
            <%= r.getCreatedAt() != null
                ? r.getCreatedAt() : "Chưa xác định" %>
        </div>

        <div class="review-comment">
            <%= Html.esc(r.getComment()) %>
        </div>

    </div>

<% } %>


        <% if (reviews.isEmpty()) { %>

            <div class="empty">
                <h3>Chưa có đánh giá nào</h3>
                <p>Hãy là người đầu tiên đánh giá sản phẩm này.</p>
            </div>

        <% } %>

    </div>

</div>

</body>
</html>
