<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"
    import="java.util.List,java.util.ArrayList,Model.user.CustomerNotification,Util.Html" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<c:set var="ctx" value="${pageContext.request.contextPath}" />
<c:set var="me" value="${sessionScope.loginUser}" />
<%
    @SuppressWarnings("unchecked")
    List<CustomerNotification> list =
        (List<CustomerNotification>) request.getAttribute("notifications");

    if (list == null) {
        list = new ArrayList<>();
    }

    String ctxPath = request.getContextPath();
    int unreadCount = 0;
    for (CustomerNotification item : list) {
        if (item != null && !item.isRead()) {
            unreadCount++;
        }
    }
%>

<!DOCTYPE html>
<html class="dark" lang="vi">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Thông báo của tôi - CoreTech</title>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Geist:wght@300..800&family=JetBrains+Mono:wght@400..600&display=swap" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="${ctx}/assets/js/home/tailwind-config.js"></script>
    <link rel="stylesheet" href="${ctx}/assets/css/home.css" />
    <style>
        body {
            font-family: 'Geist', system-ui, -apple-system, sans-serif;
            background-color: #070b14;
            color: #e6edf7;
        }

        .font-mono-tech {
            font-family: 'JetBrains Mono', monospace;
        }
    </style>
</head>

<body data-ctx="${ctx}" class="min-h-screen relative overflow-x-hidden selection:bg-sky-500/30 selection:text-sky-200">

    <!-- Ambient Glows -->
    <div class="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div class="absolute -top-32 left-1/2 -translate-x-1/2 w-[820px] h-[420px] rounded-full bg-sky-500/10 blur-[140px]"></div>
        <div class="absolute bottom-0 right-0 w-[520px] h-[520px] rounded-full bg-indigo-600/10 blur-[150px]"></div>
    </div>

    <!-- Top Bar -->
    <header class="sticky top-0 z-30 border-b border-slate-800/80 bg-slate-950/75 backdrop-blur-xl">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
            <a href="${ctx}/home" class="flex items-center gap-2.5 group">
                <span class="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-400 to-blue-600 flex items-center justify-center shadow-[0_0_20px_rgba(56,189,248,0.35)]">
                    <span class="material-symbols-outlined text-slate-950 text-[20px] font-bold">memory</span>
                </span>
                <span class="text-lg font-bold tracking-tight text-white group-hover:text-sky-300 transition-colors">
                    CoreTech
                </span>
                <span class="hidden sm:inline-block text-[11px] font-mono-tech uppercase tracking-widest text-sky-400/80 bg-sky-500/10 border border-sky-500/20 px-2 py-0.5 rounded-full">
                    Notifications
                </span>
            </a>

            <div class="flex items-center gap-2 sm:gap-3">
                <c:if test="${not empty me}">
                    <div class="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-slate-800 text-xs text-slate-300">
                        <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                        <span class="font-medium text-white"><c:out value="${me.fullName}" /></span>
                        <span class="font-mono-tech text-[10px] uppercase px-1.5 py-0.5 rounded bg-sky-500/15 text-sky-300">
                            <c:out value="${me.roleCode}" />
                        </span>
                    </div>
                </c:if>
                <a href="${ctx}/home"
                   class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-xs font-medium text-slate-200 transition-all">
                    <span class="material-symbols-outlined text-[16px] text-sky-400">home</span>
                    <span>Về trang chủ</span>
                </a>
                <c:if test="${not empty me}">
                    <a href="${ctx}/logout"
                       class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-xs font-medium text-rose-300 transition-all">
                        <span class="material-symbols-outlined text-[16px]">logout</span>
                        <span class="hidden sm:inline">Đăng xuất</span>
                    </a>
                </c:if>
            </div>
        </div>
    </header>

    <!-- Main Layout -->
    <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

            <!-- Left Sidebar -->
            <aside class="lg:col-span-4 xl:col-span-3 space-y-4">
                <div class="rounded-2xl bg-slate-900/75 backdrop-blur-xl border border-slate-800/90 p-5 shadow-xl">
                    <div class="flex items-center gap-3 pb-4 border-b border-slate-800/80">
                        <div class="w-11 h-11 rounded-2xl bg-gradient-to-br from-sky-400/25 to-blue-600/25 border border-sky-400/30 flex items-center justify-center text-sky-300 font-bold text-base">
                            <c:choose>
                                <c:when test="${not empty me and not empty me.fullName}">
                                    ${fn:substring(me.fullName, 0, 1)}
                                </c:when>
                                <c:otherwise>K</c:otherwise>
                            </c:choose>
                        </div>
                        <div class="min-w-0">
                            <p class="text-[11px] font-mono-tech uppercase tracking-wider text-slate-400">Tài khoản</p>
                            <h2 class="text-sm font-semibold text-white truncate">
                                <c:choose>
                                    <c:when test="${not empty me}"><c:out value="${me.fullName}" /></c:when>
                                    <c:otherwise>Khách hàng</c:otherwise>
                                </c:choose>
                            </h2>
                            <span class="inline-block mt-0.5 text-[10px] font-mono-tech uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-sky-300 border border-slate-700/70">
                                <c:choose>
                                    <c:when test="${not empty me}"><c:out value="${me.roleCode}" /></c:when>
                                    <c:otherwise>CUSTOMER</c:otherwise>
                                </c:choose>
                            </span>
                        </div>
                    </div>

                    <nav class="mt-4 space-y-1.5 text-sm">
                        <a href="${ctx}/user/order"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all">
                            <span class="material-symbols-outlined text-[19px] text-sky-400">receipt_long</span>
                            <span>Đơn hàng của tôi</span>
                        </a>
                        <a href="${ctx}/user/address"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all">
                            <span class="material-symbols-outlined text-[19px] text-indigo-400">location_on</span>
                            <span>Địa chỉ nhận hàng</span>
                        </a>
                        <a href="${ctx}/user/warranty"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all">
                            <span class="material-symbols-outlined text-[19px] text-amber-400">verified_user</span>
                            <span>Yêu cầu bảo hành</span>
                        </a>
                        <a href="${ctx}/user/notifications"
                           class="flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-sky-500/15 text-sky-300 border border-sky-500/30 font-medium">
                            <span class="flex items-center gap-2.5">
                                <span class="material-symbols-outlined text-[19px]">notifications</span>
                                <span>Thông báo của tôi</span>
                            </span>
                            <% if (unreadCount > 0) { %>
                                <span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-mono-tech">
                                    <%= unreadCount %>
                                </span>
                            <% } %>
                        </a>
                        <a href="${ctx}/user/order/chatbot.jsp"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all">
                            <span class="material-symbols-outlined text-[19px] text-emerald-400">smart_toy</span>
                            <span>Chatbot tư vấn</span>
                        </a>
                    </nav>
                </div>
            </aside>

            <!-- Main Content -->
            <main class="lg:col-span-8 xl:col-span-9 space-y-5">

                <!-- Page Header -->
                <div class="flex flex-wrap items-center justify-between gap-3">
                    <div>
                        <p class="text-[11px] font-mono-tech uppercase tracking-widest text-sky-400">System &amp; Store Alerts</p>
                        <h1 class="text-2xl font-bold text-white tracking-tight mt-0.5">Thông báo của bạn</h1>
                        <p class="text-xs text-slate-400 mt-1">Các thông báo mới nhất từ hệ thống và cửa hàng.</p>
                    </div>
                    <div class="flex items-center gap-2">
                        <span class="px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/25 text-xs font-mono-tech text-amber-300">
                            <%= unreadCount %> chưa đọc
                        </span>
                        <span class="px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-800 text-xs font-mono-tech text-slate-300">
                            <%= list.size() %> tổng cộng
                        </span>
                    </div>
                </div>

                <!-- Danh sách thông báo -->
                <div class="space-y-3">
                    <% for (CustomerNotification n : list) {
                        boolean isUnread = !n.isRead();
                    %>
                        <div class="rounded-2xl backdrop-blur-xl p-5 transition-all <%= isUnread
                            ? "bg-slate-900/85 border border-amber-400/40 border-l-4 border-l-amber-400 shadow-[0_0_25px_rgba(251,191,36,0.08)]"
                            : "bg-slate-900/60 border border-slate-800/80 opacity-90" %>">

                            <div class="flex flex-wrap items-start justify-between gap-3 mb-2">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <span class="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 <%= isUnread
                                        ? "bg-amber-500/15 text-amber-300 border border-amber-400/30"
                                        : "bg-slate-800 text-slate-400 border border-slate-700/70" %>">
                                        <span class="material-symbols-outlined text-[18px]">
                                            <%= isUnread ? "mark_email_unread" : "drafts" %>
                                        </span>
                                    </span>
                                    <h3 class="text-base font-semibold text-white">
                                        <%= Html.esc(n.getTitle() != null ? n.getTitle() : "") %>
                                    </h3>
                                </div>

                                <% if (isUnread) { %>
                                    <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-medium">
                                        <span class="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
                                        Chưa đọc
                                    </span>
                                <% } else { %>
                                    <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-medium">
                                        <span class="material-symbols-outlined text-[14px]">done_all</span>
                                        Đã đọc
                                    </span>
                                <% } %>
                            </div>

                            <div class="rounded-xl bg-slate-950/65 border border-slate-800/70 p-3.5 text-sm text-slate-200 leading-relaxed whitespace-pre-wrap break-words">
                                <%= Html.esc(n.getContent() != null ? n.getContent() : "") %>
                            </div>

                            <div class="flex flex-wrap items-center justify-between gap-3 mt-3.5 pt-3 border-t border-slate-800/70">
                                <div class="flex items-center gap-1.5 text-xs text-slate-400 font-mono-tech">
                                    <span class="material-symbols-outlined text-[15px] text-slate-500">schedule</span>
                                    <span>
                                        Thời gian: <%= n.getCreatedAt() != null ? n.getCreatedAt() : "Chưa xác định" %>
                                    </span>
                                </div>

                                <% if (isUnread) { %>
                                    <form method="post" action="<%= ctxPath %>/user/notifications" class="inline">
                                        <input type="hidden" name="id" value="<%= n.getNotificationId() %>">
                                        <button type="submit"
                                                class="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-sky-400 to-blue-600 hover:from-sky-300 hover:to-blue-500 text-slate-950 font-semibold text-xs shadow-[0_0_16px_rgba(56,189,248,0.25)] active:scale-[0.98] transition-all cursor-pointer">
                                            <span class="material-symbols-outlined text-[16px]">mark_email_read</span>
                                            <span>Đánh dấu đã đọc</span>
                                        </button>
                                    </form>
                                <% } %>
                            </div>
                        </div>
                    <% } %>

                    <% if (list.isEmpty()) { %>
                        <div class="rounded-2xl bg-slate-900/50 border border-dashed border-slate-800 p-10 text-center">
                            <span class="material-symbols-outlined text-slate-500 text-4xl mb-2">notifications_off</span>
                            <h3 class="text-base font-semibold text-white">Chưa có thông báo</h3>
                            <p class="text-xs text-slate-400 mt-1">Bạn chưa nhận được thông báo nào từ cửa hàng.</p>
                        </div>
                    <% } %>
                </div>

            </main>

        </div>
    </div>

</body>

</html>