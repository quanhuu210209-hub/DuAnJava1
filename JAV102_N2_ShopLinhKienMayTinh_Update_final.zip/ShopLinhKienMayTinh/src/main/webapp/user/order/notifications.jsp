<%@ page contentType="text/html;charset=UTF-8" language="java"
    import="java.util.List,Model.user.CustomerNotification,Util.Html" %>

<%
    List<CustomerNotification> list =
        (List<CustomerNotification>) request.getAttribute("notifications");

    if (list == null) {
        list = new java.util.ArrayList<>();
    }

    String ctx = request.getContextPath();
%>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Thông báo của tôi</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1100px;
            margin: 30px auto;
            padding: 0 16px;
            background: #f8f9fa;
        }

        .layout {
            display: flex;
            gap: 20px;
            align-items: flex-start;
        }

        .content {
            flex: 1;
            min-width: 0;
        }

        h2 {
            margin-bottom: 20px;
            color: #222;
        }

        .card {
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 16px;
            margin: 12px 0;
        }

        .unread {
            background: #fff8e1;
            border-left: 4px solid #f0ad4e;
        }

        .notification-title {
            font-size: 17px;
            color: #222;
            margin-bottom: 8px;
        }

        .notification-content {
            color: #444;
            line-height: 1.6;
            margin-bottom: 10px;
            white-space: pre-wrap;
            overflow-wrap: anywhere;
        }

        .muted {
            color: #777;
            font-size: 13px;
        }

        .status {
            display: inline-block;
            font-size: 12px;
            padding: 4px 8px;
            border-radius: 20px;
            margin-left: 6px;
        }

        .status-unread {
            color: #856404;
            background: #ffeeba;
        }

        .status-read {
            color: #155724;
            background: #d4edda;
        }

        button {
            padding: 9px 15px;
            cursor: pointer;
            border: none;
            border-radius: 5px;
            background: #2563eb;
            color: white;
            margin-top: 8px;
        }

        button:hover {
            opacity: 0.85;
        }

        .empty {
            background: white;
            border: 1px dashed #ccc;
            border-radius: 8px;
            padding: 30px;
            text-align: center;
            color: #777;
        }

        @media (max-width: 700px) {
            .layout {
                flex-direction: column;
            }

            .content {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<div class="layout">

    <jsp:include page="/user/sidebar.jsp" />

    <div class="content">

        <h2>Thông báo của bạn</h2>

        <p class="muted">
            Các thông báo mới nhất từ hệ thống và cửa hàng.
        </p>

        <% for (CustomerNotification n : list) { %>
            <div class="card <%= n.isRead() ? "" : "unread" %>">
                <div class="notification-title">
                    <b><%= Html.esc(n.getTitle()) %></b>
                    <% if (!n.isRead()) { %>
                        <span class="status status-unread">
                            Chưa đọc
                        </span>
                    <% } else { %>
                        <span class="status status-read">
                            Đã đọc
                        </span>
                    <% } %>
                </div>

                <div class="notification-content">
                    <%= Html.esc(n.getContent()) %>
                </div>

                <div class="muted">
                    Thời gian:
                    <%= n.getCreatedAt() != null ? n.getCreatedAt() : "Chưa xác định" %>
                </div>

                <% if (!n.isRead()) { %>
                    <form method="post" action="<%= ctx %>/user/notifications">
                        <input type="hidden" name="id" value="<%= n.getNotificationId() %>">
                        <button type="submit">Đánh dấu đã đọc</button>
                    </form>
                <% } %>
            </div>
        <% } %>

        <% if (list.isEmpty()) { %>
            <div class="empty">
                <h3>Chưa có thông báo</h3>
                <p>Bạn chưa nhận được thông báo nào từ cửa hàng.</p>
            </div>
        <% } %>

    </div>

</div>

</body>
</html>