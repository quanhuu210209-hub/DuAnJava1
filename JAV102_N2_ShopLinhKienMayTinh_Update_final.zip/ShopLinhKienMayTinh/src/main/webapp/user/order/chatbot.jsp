<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<c:set var="ctx" value="${pageContext.request.contextPath}" />
<c:set var="me" value="${sessionScope.loginUser}" />
<!DOCTYPE html>
<html class="dark" lang="vi">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Chatbot Tư Vấn Linh Kiện - CoreTech</title>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Geist:wght@300..800&family=JetBrains+Mono:wght@400..600&display=swap" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="${ctx}/assets/js/home/tailwind-config.js"></script>
    <link rel="stylesheet" href="${ctx}/assets/css/home.css" />
    <style>
        body {
            font-family: 'Geist', system-ui, -apple-system, sans-serif;
            background-color: #070b14;
            color: #e6edf7;
        }

        .font-mono-tech {
            font-family: 'JetBrains Mono', monospace;
        }

        /* Custom scrollbar cho khung chat */
        #chat-messages::-webkit-scrollbar {
            width: 6px;
        }
        #chat-messages::-webkit-scrollbar-track {
            background: rgba(15, 23, 42, 0.4);
            border-radius: 9999px;
        }
        #chat-messages::-webkit-scrollbar-thumb {
            background: rgba(148, 163, 184, 0.35);
            border-radius: 9999px;
        }
        #chat-messages::-webkit-scrollbar-thumb:hover {
            background: rgba(125, 211, 252, 0.55);
        }
    </style>
</head>

<body data-ctx="${ctx}" class="min-h-screen relative overflow-x-hidden selection:bg-sky-500/30 selection:text-sky-200">

    <!-- Ambient Glows -->
    <div class="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div class="absolute -top-32 left-1/2 -translate-x-1/2 w-[820px] h-[420px] rounded-full bg-sky-500/10 blur-[140px]"></div>
        <div class="absolute bottom-0 right-0 w-[520px] h-[520px] rounded-full bg-indigo-600/10 blur-[150px]"></div>
    </div>

    <!-- Top Bar -->
    <header class="sticky top-0 z-30 border-b border-slate-800/80 bg-slate-950/75 backdrop-blur-xl">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
            <a href="${ctx}/home" class="flex items-center gap-2.5 group">
                <span class="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-400 to-blue-600 flex items-center justify-center shadow-[0_0_20px_rgba(56,189,248,0.35)]">
                    <span class="material-symbols-outlined text-slate-950 text-[20px] font-bold">memory</span>
                </span>
                <span class="text-lg font-bold tracking-tight text-white group-hover:text-sky-300 transition-colors">
                    CoreTech
                </span>
                <span class="hidden sm:inline-block text-[11px] font-mono-tech uppercase tracking-widest text-sky-400/80 bg-sky-500/10 border border-sky-500/20 px-2 py-0.5 rounded-full">
                    AI Advisor
                </span>
            </a>

            <div class="flex items-center gap-2 sm:gap-3">
                <c:if test="${not empty me}">
                    <div class="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-slate-800 text-xs text-slate-300">
                        <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                        <span class="font-medium text-white"><c:out value="${me.fullName}" /></span>
                        <span class="font-mono-tech text-[10px] uppercase px-1.5 py-0.5 rounded bg-sky-500/15 text-sky-300">
                            <c:out value="${me.roleCode}" />
                        </span>
                    </div>
                </c:if>
                <a href="${ctx}/home"
                   class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-xs font-medium text-slate-200 transition-all">
                    <span class="material-symbols-outlined text-[16px] text-sky-400">home</span>
                    <span>Về trang chủ</span>
                </a>
                <c:if test="${not empty me}">
                    <a href="${ctx}/logout"
                       class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-xs font-medium text-rose-300 transition-all">
                        <span class="material-symbols-outlined text-[16px]">logout</span>
                        <span class="hidden sm:inline">Đăng xuất</span>
                    </a>
                </c:if>
            </div>
        </div>
    </header>

    <!-- Main Layout -->
    <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

            <!-- Sidebar / Account Panel -->
            <aside class="lg:col-span-4 xl:col-span-3 space-y-4">
                <div class="rounded-2xl bg-slate-900/75 backdrop-blur-xl border border-slate-800/90 p-5 shadow-xl">
                    <div class="flex items-center gap-3 pb-4 border-b border-slate-800/80">
                        <div class="w-11 h-11 rounded-2xl bg-gradient-to-br from-sky-400/25 to-blue-600/25 border border-sky-400/30 flex items-center justify-center text-sky-300 font-bold text-base">
                            <c:choose>
                                <c:when test="${not empty me and not empty me.fullName}">
                                    ${fn:substring(me.fullName, 0, 1)}
                                </c:when>
                                <c:otherwise>K</c:otherwise>
                            </c:choose>
                        </div>
                        <div class="min-w-0">
                            <p class="text-[11px] font-mono-tech uppercase tracking-wider text-slate-400">Tài khoản</p>
                            <h2 class="text-sm font-semibold text-white truncate">
                                <c:choose>
                                    <c:when test="${not empty me}"><c:out value="${me.fullName}" /></c:when>
                                    <c:otherwise>Khách hàng mẫu</c:otherwise>
                                </c:choose>
                            </h2>
                            <span class="inline-block mt-0.5 text-[10px] font-mono-tech uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-sky-300 border border-slate-700/70">
                                <c:choose>
                                    <c:when test="${not empty me}"><c:out value="${me.roleCode}" /></c:when>
                                    <c:otherwise>CUSTOMER</c:otherwise>
                                </c:choose>
                            </span>
                        </div>
                    </div>

                    <nav class="mt-4 space-y-1.5 text-sm">
                        <a href="${ctx}/user/order"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all">
                            <span class="material-symbols-outlined text-[19px] text-sky-400">receipt_long</span>
                            <span>Đơn hàng của tôi</span>
                        </a>
                        <a href="${ctx}/user/order/chatbot.jsp"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl bg-sky-500/15 text-sky-300 border border-sky-500/30 font-medium">
                            <span class="material-symbols-outlined text-[19px]">smart_toy</span>
                            <span>Chatbot tư vấn</span>
                        </a>
                        <a href="${ctx}/home"
                           class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all">
                            <span class="material-symbols-outlined text-[19px] text-emerald-400">storefront</span>
                            <span>Khám phá linh kiện</span>
                        </a>
                    </nav>
                </div>

                <!-- Gợi ý câu hỏi nhanh -->
                <div class="rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5">
                    <div class="flex items-center gap-2 text-xs font-mono-tech uppercase tracking-wider text-sky-300 mb-3">
                        <span class="material-symbols-outlined text-[16px]">bolt</span>
                        <span>Gợi ý câu hỏi nhanh</span>
                    </div>
                    <div class="space-y-2 text-xs">
                        <button type="button" data-prompt="Tư vấn build PC gaming tầm 20 triệu chơi mượt AAA"
                                class="quick-prompt w-full text-left px-3 py-2.5 rounded-xl bg-slate-950/70 hover:bg-slate-800/90 border border-slate-800 hover:border-sky-500/40 text-slate-300 hover:text-white transition-all">
                            Tư vấn build PC gaming tầm 20 triệu chơi mượt AAA
                        </button>
                        <button type="button" data-prompt="Nên chọn SSD NVMe Gen 4 nào mát và bền?"
                                class="quick-prompt w-full text-left px-3 py-2.5 rounded-xl bg-slate-950/70 hover:bg-slate-800/90 border border-slate-800 hover:border-sky-500/40 text-slate-300 hover:text-white transition-all">
                            Nên chọn SSD NVMe Gen 4 nào mát và bền?
                        </button>
                        <button type="button" data-prompt="Kiểm tra tương thích giữa CPU, Mainboard và RAM DDR5"
                                class="quick-prompt w-full text-left px-3 py-2.5 rounded-xl bg-slate-950/70 hover:bg-slate-800/90 border border-slate-800 hover:border-sky-500/40 text-slate-300 hover:text-white transition-all">
                            Kiểm tra tương thích giữa CPU, Mainboard và RAM DDR5
                        </button>
                    </div>
                </div>
            </aside>

            <!-- Chat Box Section -->
            <main class="lg:col-span-8 xl:col-span-9">
                <div class="rounded-3xl bg-slate-900/75 backdrop-blur-2xl border border-slate-800/90 shadow-[0_20px_60px_rgba(0,0,0,0.45)] overflow-hidden flex flex-col min-h-[580px] h-[calc(100vh-8.5rem)] max-h-[780px]">

                    <!-- Chat Header -->
                    <div class="px-5 sm:px-6 py-4 border-b border-slate-800/90 bg-slate-950/50 flex items-center justify-between gap-3">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-2xl bg-sky-500/15 border border-sky-400/30 flex items-center justify-center text-sky-300">
                                <span class="material-symbols-outlined text-[22px]">smart_toy</span>
                            </div>
                            <div>
                                <h1 class="text-base sm:text-lg font-bold text-white leading-tight">Chatbot tư vấn</h1>
                                <div class="flex items-center gap-1.5 text-xs text-emerald-400 mt-0.5">
                                    <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                                    <span>Sẵn sàng hỗ trợ cấu hình &amp; linh kiện</span>
                                </div>
                            </div>
                        </div>
                        <button id="clear-chat-btn" type="button"
                                class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/70 text-xs text-slate-300 hover:text-white transition-all"
                                title="Xóa đoạn hội thoại">
                            <span class="material-symbols-outlined text-[16px]">delete_sweep</span>
                            <span class="hidden sm:inline">Làm mới</span>
                        </button>
                    </div>

                    <!-- Messages Area -->
                    <div id="chat-messages" class="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4">
                        <!-- Tin nhắn chào mừng mặc định của Bot -->
                        <div class="flex items-start gap-3">
                            <div class="w-8 h-8 rounded-xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-300 shrink-0 mt-0.5">
                                <span class="material-symbols-outlined text-[18px]">smart_toy</span>
                            </div>
                            <div class="max-w-[82%] rounded-2xl rounded-tl-sm bg-slate-800/85 border border-slate-700/70 px-4 py-3 text-sm text-slate-100 shadow-sm">
                                <div class="flex items-center gap-2 mb-1">
                                    <span class="font-semibold text-sky-300 text-xs font-mono-tech uppercase">Bot</span>
                                    <span class="text-[11px] text-slate-400">CoreTech Assistant</span>
                                </div>
                                <p class="leading-relaxed">Xin chào! Bạn cần tư vấn linh kiện nào?</p>
                            </div>
                        </div>
                    </div>

                    <!-- Input Form -->
                    <form id="chat-form" class="p-4 sm:p-5 border-t border-slate-800/90 bg-slate-950/65">
                        <div class="flex items-center gap-2.5 sm:gap-3">
                            <div class="flex-1 flex items-center rounded-2xl bg-slate-900 border border-slate-700/80 focus-within:border-sky-400 focus-within:ring-2 focus-within:ring-sky-400/20 px-4 py-2.5 transition-all">
                                <span class="material-symbols-outlined text-slate-400 text-[20px] mr-2.5">chat_bubble_outline</span>
                                <input id="chat-input"
                                       type="text"
                                       autocomplete="off"
                                       placeholder="Nhập câu hỏi..."
                                       class="w-full bg-transparent text-sm text-white placeholder:text-slate-500 focus:outline-none" />
                            </div>
                            <button id="send-btn"
                                    type="submit"
                                    class="inline-flex items-center gap-1.5 px-5 py-3 rounded-2xl bg-gradient-to-r from-sky-400 to-blue-600 hover:from-sky-300 hover:to-blue-500 text-slate-950 font-semibold text-sm shadow-[0_0_24px_rgba(56,189,248,0.3)] active:scale-[0.98] transition-all shrink-0 cursor-pointer">
                                <span>Gửi</span>
                                <span class="material-symbols-outlined text-[18px]">send</span>
                            </button>
                        </div>
                    </form>

                </div>
            </main>

        </div>
    </div>

    <script>
        (function () {
            const ctx = document.body.dataset.ctx || '';
            const chatForm = document.getElementById('chat-form');
            const chatInput = document.getElementById('chat-input');
            const chatMessages = document.getElementById('chat-messages');
            const clearBtn = document.getElementById('clear-chat-btn');
            const quickPrompts = document.querySelectorAll('.quick-prompt');

            function scrollToBottom() {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }

            function appendMessage(sender, text, isUser) {
                const wrapper = document.createElement('div');
                wrapper.className = isUser
                    ? 'flex items-start justify-end gap-3'
                    : 'flex items-start gap-3';

                const avatar = document.createElement('div');
                avatar.className = isUser
                    ? 'w-8 h-8 rounded-xl bg-blue-600/25 border border-blue-400/30 flex items-center justify-center text-blue-200 shrink-0 mt-0.5 order-2'
                    : 'w-8 h-8 rounded-xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-300 shrink-0 mt-0.5';

                const icon = document.createElement('span');
                icon.className = 'material-symbols-outlined text-[18px]';
                icon.textContent = isUser ? 'person' : 'smart_toy';
                avatar.appendChild(icon);

                const bubble = document.createElement('div');
                bubble.className = isUser
                    ? 'max-w-[82%] rounded-2xl rounded-tr-sm bg-gradient-to-br from-sky-500/25 to-blue-600/25 border border-sky-400/35 px-4 py-3 text-sm text-white shadow-sm'
                    : 'max-w-[82%] rounded-2xl rounded-tl-sm bg-slate-800/85 border border-slate-700/70 px-4 py-3 text-sm text-slate-100 shadow-sm';

                const labelRow = document.createElement('div');
                labelRow.className = isUser
                    ? 'flex items-center justify-end gap-2 mb-1'
                    : 'flex items-center gap-2 mb-1';

                const senderEl = document.createElement('span');
                senderEl.className = isUser
                    ? 'font-semibold text-sky-200 text-xs font-mono-tech uppercase'
                    : 'font-semibold text-sky-300 text-xs font-mono-tech uppercase';
                senderEl.textContent = sender;

                const timeEl = document.createElement('span');
                timeEl.className = 'text-[11px] text-slate-400';
                const now = new Date();
                timeEl.textContent = now.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });

                labelRow.appendChild(senderEl);
                labelRow.appendChild(timeEl);

                const bodyEl = document.createElement('p');
                bodyEl.className = 'leading-relaxed whitespace-pre-wrap break-words';
                bodyEl.textContent = text;

                bubble.appendChild(labelRow);
                bubble.appendChild(bodyEl);

                wrapper.appendChild(avatar);
                wrapper.appendChild(bubble);
                chatMessages.appendChild(wrapper);
                scrollToBottom();
            }

            async function sendQuestion(question) {
                const trimmed = question.trim();
                if (!trimmed) return;

                appendMessage('Bạn', trimmed, true);
                chatInput.value = '';
                chatInput.focus();

                // Nếu bạn có endpoint servlet riêng (ví dụ /user/chatbot), có thể gọi fetch tại đây
                try {
                    const res = await fetch(ctx + '/user/chatbot', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                        body: 'message=' + encodeURIComponent(trimmed)
                    });
                    if (res.ok) {
                        const data = await res.json().catch(() => null);
                        if (data && data.reply) {
                            appendMessage('Bot', data.reply, false);
                            return;
                        }
                        const textReply = await res.text();
                        if (textReply && !textReply.trim().startsWith('<!DOCTYPE')) {
                            appendMessage('Bot', textReply.trim(), false);
                            return;
                        }
                    }
                } catch (err) {
                    // Fallback gợi ý cục bộ nếu chưa nối servlet chatbot
                }

                appendMessage(
                    'Bot',
                    'Mình đã nhận câu hỏi: "' + trimmed + '". Bạn hãy cho mình biết ngân sách và nhu cầu chính (gaming, đồ họa, văn phòng) để mình gợi ý cấu hình phù hợp nhé!',
                    false
                );
            }

            chatForm.addEventListener('submit', function (e) {
                e.preventDefault();
                sendQuestion(chatInput.value);
            });

            quickPrompts.forEach(function (btn) {
                btn.addEventListener('click', function () {
                    sendQuestion(btn.dataset.prompt || '');
                });
            });

            clearBtn.addEventListener('click', function () {
                chatMessages.innerHTML = '';
                appendMessage('Bot', 'Xin chào! Bạn cần tư vấn linh kiện nào?', false);
            });
        })();
    </script>
</body>

</html>