<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Chatbot tư vấn</title><style>body{font-family:Arial,sans-serif;max-width:1100px;margin:30px auto;padding:0 16px}input,textarea,select{padding:6px;margin:4px 0;width:100%;box-sizing:border-box}button{padding:8px 14px;cursor:pointer}.card{border:1px solid #ddd;border-radius:8px;padding:12px;margin:10px 0}.muted{color:#777;font-size:13px}.unread{background:#fff8e1}</style>
<style>#box{height:360px;overflow:auto;border:1px solid #ddd;border-radius:8px;padding:10px}.u{text-align:right;color:#0b5}.b{color:#333}p{margin:6px 0}</style></head><body><div style="display:flex;gap:20px;align-items:flex-start"><jsp:include page="/user/sidebar.jsp"/><div style="flex:1;min-width:0">
<h2>Chatbot tư vấn</h2>
<div id="box"><p class="b"><b>Bot:</b> Xin chào! Bạn cần tư vấn linh kiện nào?</p></div>
<form id="f" style="display:flex;gap:6px;margin-top:8px"><input id="m" placeholder="Nhập câu hỏi..." autocomplete="off"><button style="width:90px">Gửi</button></form>
<script>
const box=document.getElementById('box'), m=document.getElementById('m');
function add(cls,who,t){const p=document.createElement('p');p.className=cls;p.innerHTML='<b>'+who+':</b> ';p.appendChild(document.createTextNode(t));box.appendChild(p);box.scrollTop=box.scrollHeight;}
document.getElementById('f').onsubmit=async e=>{
  e.preventDefault(); const t=m.value.trim(); if(!t) return; add('u','Bạn',t); m.value='';
  const r=await fetch('<%= request.getContextPath() %>/user/chatbot',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:'message='+encodeURIComponent(t)});
  const d=await r.json(); add('b','Bot',d.answer);
};
</script></div></div></body></html>
