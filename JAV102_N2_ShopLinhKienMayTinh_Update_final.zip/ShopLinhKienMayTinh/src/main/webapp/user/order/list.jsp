<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Đơn của tôi — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/user.css">
</head>
<body>

<%@ include file="/user/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Đơn hàng của tôi</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="table-card"><table>
        <thead><tr><th>Mã đơn</th><th>Tổng tiền</th><th>Trạng thái</th><th>Ngày đặt</th><th></th></tr></thead>
        <tbody>
        <c:forEach var="o" items="${orders}">
            <tr>
                <td><c:out value="${o.orderCode}"/></td>
                <td><t:money value="${o.totalAmount}"/></td>
                <td><t:orderStatus value="${o.status}"/></td>
                <td><t:dt value="${o.createdAt}"/></td>
                <td><a href="${pageContext.request.contextPath}/user/order?id=${o.orderId}" class="btn-xs ghost">Xem</a></td>
            </tr>
        </c:forEach>
        <c:if test="${empty orders}"><tr><td colspan="5">Bạn chưa có đơn hàng nào.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
