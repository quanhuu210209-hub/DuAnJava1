<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Đăng nhập — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/public.css">
</head>
<body class="public">
<div class="auth-card">
  <h1>Đăng nhập</h1>
  <p class="sub">CoreTech - Shop linh kiện máy tính</p>

  <c:if test="${not empty flashMessage}">
    <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
  </c:if>
  <c:if test="${not empty loginError}">
    <div class="alert alert-danger"><c:out value="${loginError}"/></div>
  </c:if>

  <form method="post" action="${pageContext.request.contextPath}/login" data-validate>
    <div class="form-row">
      <label for="username">Email hoặc số điện thoại</label>
      <input id="username" name="username" type="text" value="<c:out value='${username}'/>"
             required maxlength="150" data-label="Email/Số điện thoại" autocomplete="username">
      <span class="field-error" data-for="username"><c:out value="${errors.username}"/></span>
    </div>
    <div class="form-row">
      <label for="password">Mật khẩu</label>
      <input id="password" name="password" type="password" required data-label="Mật khẩu" autocomplete="current-password">
      <span class="field-error" data-for="password"><c:out value="${errors.password}"/></span>
    </div>
    <button type="submit">Đăng nhập</button>
  </form>
  <p class="links"><a href="${pageContext.request.contextPath}/home">← Về trang chủ</a></p>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>
