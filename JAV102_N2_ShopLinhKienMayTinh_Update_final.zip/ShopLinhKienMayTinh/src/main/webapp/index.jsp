<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<c:set var="ctx" value="${pageContext.request.contextPath}" />
<c:set var="me" value="${sessionScope.loginUser}" />
<c:set var="canBuy" value="${empty me or me.roleCode == 'CUSTOMER'}" />
<!DOCTYPE html>
<html class="dark" lang="vi">

<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="web_standard" name="shell-type" />
    <title>CoreTech - Shop Linh Kiện Máy Tính Cao Cấp</title>
    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"
        rel="stylesheet" />
    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap"
        rel="stylesheet" />
    <link
        href="https://fonts.googleapis.com/css2?family=Geist:wght@100..900&amp;family=JetBrains+Mono:wght@100..900&amp;display=swap"
        rel="stylesheet" />
    <link rel="stylesheet" href="${ctx}/assets/css/home.css" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="${ctx}/assets/js/home/tailwind-config.js"></script>
</head>

<body data-ctx="${ctx}" data-role="${me.roleCode}"
    class="bg-surface-container-lowest font-body-md text-body-md text-on-surface min-h-screen relative selection:bg-primary-container selection:text-on-primary-container">
    <!-- Ambient Atmospheric Glows -->
    <div class="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div
            class="absolute -top-[20%] left-1/2 -translate-x-1/2 w-[900px] h-[500px] rounded-full bg-secondary-container/15 blur-[140px]">
        </div>
        <div
            class="absolute top-1/3 -left-[10%] w-[600px] h-[600px] rounded-full bg-tertiary-container/10 blur-[160px]">
        </div>
        <div
            class="absolute bottom-0 right-[5%] w-[500px] h-[500px] rounded-full bg-primary-container/10 blur-[130px]">
        </div>
    </div>

    <!-- FLASH MESSAGE NOTIFICATION -->
    <c:if test="${not empty flashMessage}">
        <div
            class="fixed top-24 left-1/2 -translate-x-1/2 z-[60] max-w-lg w-full px-4 animate-in fade-in slide-in-from-top-4 duration-300">
            <div
                class="p-4 rounded-2xl bg-surface-container-lowest/95 backdrop-blur-2xl border ${flashType == 'danger' ? 'border-red-500/60 text-red-300 shadow-[0_0_25px_rgba(239,68,68,0.3)]' : (flashType == 'warning' ? 'border-amber-500/60 text-amber-300 shadow-[0_0_25px_rgba(245,158,11,0.3)]' : 'border-primary/60 text-primary shadow-[0_0_25px_rgba(159,208,255,0.3)]')} flex items-center justify-between gap-3 shadow-2xl">
                <div class="flex items-center gap-2.5">
                    <span class="material-symbols-outlined text-[20px]">${flashType == 'danger' ?
                        'error' : (flashType == 'warning' ? 'warning' : 'check_circle')}</span>
                    <span class="text-xs font-medium">
                        <c:out value="${flashMessage}" />
                    </span>
                </div>
                <button onclick="this.parentElement.parentElement.remove()"
                    class="text-on-surface-variant hover:text-white transition-colors">
                    <span class="material-symbols-outlined text-[18px]">close</span>
                </button>
            </div>
        </div>
    </c:if>

    <!-- HEADER NAVIGATION -->
    <header class="fixed top-4 left-0 right-0 z-50 flex justify-center px-3 sm:px-6">
        <div
            class="h-20 flex items-center justify-between gap-3 md:gap-6 px-4 md:px-6 rounded-3xl bg-surface-container-lowest/70 backdrop-blur-2xl border border-surface-container-high/50 shadow-[0_8px_32px_rgba(0,0,0,0.5)] max-w-7xl w-full">
            <!-- Brand Logo -->
            <a class="flex items-center gap-2 font-headline-sm text-headline-sm text-on-surface tracking-tight shrink-0"
                href="${ctx}/home">
                <span
                    class="w-8 h-8 rounded-xl bg-gradient-to-tr from-primary to-primary-container flex items-center justify-center shadow-[0_0_15px_rgba(159,208,255,0.4)]">
                    <span
                        class="material-symbols-outlined text-surface-container-lowest text-[20px] font-bold">memory</span>
                </span>
                <span class="font-bold italic text-primary">CoreTech</span>
                <span
                    class="hidden sm:inline opacity-50 text-on-surface font-light text-xs tracking-widest uppercase">//
                    Hardware</span>
            </a>

            <!-- Navigation Links (Admin / Staff / Customer) -->
            <nav
                class="hidden xl:flex items-center gap-1 whitespace-nowrap font-label-technical text-xs tracking-wider uppercase">
                <a href="${ctx}/home"
                    class="px-3 py-1.5 rounded-full text-primary hover:bg-surface-container-high/60 transition-all font-semibold">Trang
                    chủ</a>
                <c:if test="${me.roleCode == 'CUSTOMER'}">
                    <a href="${ctx}/user/order"
                        class="px-3 py-1.5 rounded-full text-on-surface-variant hover:text-primary hover:bg-surface-container-high/60 transition-all">Đơn của tôi</a>
                    <a href="${ctx}/user/order/chatbot.jsp"
                        class="px-3 py-1.5 rounded-full text-on-surface-variant hover:text-primary hover:bg-surface-container-high/60 transition-all">Chatbot</a>
                </c:if>
            </nav>

            <!-- Header Search & Category Filter Bar (GET Form -> /home) -->
            <form method="get" action="${ctx}/home"
                class="flex-1 min-w-0 max-w-md mx-2 hidden lg:flex items-center rounded-full bg-surface-container-low/90 border border-surface-container-high/60 p-1 focus-within:border-primary focus-within:shadow-[0_0_20px_rgba(159,208,255,0.25)] transition-all">
                <!-- Category Select Dropdown -->
                <div class="relative shrink-0 border-r border-surface-container-high/60 pr-1 mr-1">
                    <select name="categoryId"
                        class="max-w-[130px] bg-transparent text-xs font-label-technical uppercase tracking-wider text-primary px-3 py-1.5 focus:outline-none cursor-pointer appearance-none pr-6">
                        <option value="" class="bg-surface-container text-on-surface">Tất Cả Loại
                        </option>
                        <c:forEach var="c" items="${categories}">
                            <option value="${c.categoryId}"
                                class="bg-surface-container text-on-surface"
                                ${categoryId==c.categoryId ? 'selected' : '' }>
                                <c:out value="${c.categoryName}" />
                            </option>
                        </c:forEach>
                    </select>
                    <span
                        class="material-symbols-outlined text-primary text-[14px] absolute right-1.5 top-1/2 -translate-y-1/2 pointer-events-none">expand_more</span>
                </div>
                <!-- Search Input -->
                <div class="flex-1 min-w-0 flex items-center px-2">
                    <span
                        class="material-symbols-outlined text-on-surface-variant text-[18px] mr-2">search</span>
                    <input name="keyword" type="text" value="<c:out value='${keyword}'/>"
                        placeholder="Tìm kiếm màn hình, chip, ram, card..."
                        class="w-full min-w-0 bg-transparent text-body-md text-on-surface placeholder:text-on-surface-variant/60 focus:outline-none font-light py-1 text-xs" />
                </div>
                <button type="submit"
                    class="shrink-0 px-3 py-1.5 rounded-full bg-primary-container/80 hover:bg-primary text-on-primary-container font-label-technical text-[11px] uppercase tracking-wider transition-all">
                    Tìm
                </button>
            </form>

            <!-- Action Buttons: Build PC, Cart, Auth -->
            <div class="flex items-center gap-2 sm:gap-3 shrink-0">
                <!-- Build PC Button -->
                <button id="open-builder-btn" type="button"
                    class="inline-flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-full bg-gradient-to-r from-primary-container/30 to-primary/20 border border-primary/40 text-primary font-label-technical text-[11px] sm:text-xs uppercase tracking-wider hover:bg-primary-container hover:text-on-primary-container transition-all shadow-[0_0_15px_rgba(159,208,255,0.2)]">
                    <span class="material-symbols-outlined text-[16px]">tune</span>
                    <span class="hidden 2xl:inline font-semibold">Build Cấu Hình</span>
                </button>

                <!-- Cart Button with Counter Badge -->
                <c:if test="${canBuy}">
                    <button id="open-cart-btn" type="button"
                        class="relative w-10 h-10 rounded-full bg-surface-container-high/70 hover:bg-surface-container-high border border-surface-container-high flex items-center justify-center text-on-surface hover:text-primary transition-all">
                        <span class="material-symbols-outlined text-[20px]">shopping_cart</span>
                        <span id="cart-badge"
                            class="absolute -top-1 -right-1 min-w-[20px] h-[20px] px-1 rounded-full bg-primary text-on-primary text-[10px] font-bold flex items-center justify-center shadow-[0_0_10px_rgba(159,208,255,0.8)]">0</span>
                    </button>
                </c:if>

                <!-- Auth / User Info -->
                <c:choose>
                    <c:when test="${not empty me}">
                        <div class="flex items-center gap-2">
                            <div class="relative group">
                                <button type="button"
                                    class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/30 text-xs font-label-technical text-primary hover:bg-primary/15 transition-all">
                                    <span
                                        class="w-6 h-6 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-[10px]">
                                        ${fn:substring(me.fullName, 0, 1)}
                                    </span>
                                    <span class="hidden xl:inline max-w-[130px] truncate font-semibold">
                                        <c:out value="${me.fullName}" />
                                    </span>
                                    <span class="material-symbols-outlined text-[14px]">expand_more</span>
                                </button>
                                <div class="absolute right-0 top-full pt-2 hidden group-hover:block group-focus-within:block z-50">
                                    <div class="flex flex-col min-w-[210px] bg-surface-container-lowest/95 backdrop-blur-2xl border border-surface-container-high/60 rounded-2xl p-2 shadow-2xl space-y-0.5">
                                        <c:if test="${me.roleCode == 'ADMIN'}">
                                            <a href="${ctx}/admin/product" class="flex items-center gap-2 px-3 py-2 rounded-xl text-on-surface hover:text-primary hover:bg-surface-container-high text-xs whitespace-nowrap transition-colors">
                                                <span class="material-symbols-outlined text-[16px] text-primary">inventory_2</span>
                                                <span>Sản phẩm</span>
                                            </a>
                                            <a href="${ctx}/admin/category" class="flex items-center gap-2 px-3 py-2 rounded-xl text-on-surface hover:text-primary hover:bg-surface-container-high text-xs whitespace-nowrap transition-colors">
                                                <span class="material-symbols-outlined text-[16px] text-primary">category</span>
                                                <span>Danh mục</span>
                                            </a>
                                            <a href="${ctx}/admin/brand" class="flex items-center gap-2 px-3 py-2 rounded-xl text-on-surface hover:text-primary hover:bg-surface-container-high text-xs whitespace-nowrap transition-colors">
                                                <span class="material-symbols-outlined text-[16px] text-primary">verified</span>
                                                <span>Thương hiệu</span>
                                            </a>
                                            <a href="${ctx}/admin/user" class="flex items-center gap-2 px-3 py-2 rounded-xl text-on-surface hover:text-primary hover:bg-surface-container-high text-xs whitespace-nowrap transition-colors">
                                                <span class="material-symbols-outlined text-[16px] text-primary">group</span>
                                                <span>Người dùng</span>
                                            </a>
                                            <a href="${ctx}/staff/order" class="flex items-center gap-2 px-3 py-2 rounded-xl text-on-surface hover:text-primary hover:bg-surface-container-high text-xs whitespace-nowrap transition-colors">
                                                <span class="material-symbols-outlined text-[16px] text-primary">receipt_long</span>
                                                <span>Đơn hàng</span>
                                            </a>
                                        </c:if>
                                        <c:if test="${me.roleCode == 'MANAGER' or me.roleCode == 'STAFF'}">
                                            <a href="${ctx}/staff/order" class="flex items-center gap-2 px-3 py-2 rounded-xl text-on-surface hover:text-primary hover:bg-surface-container-high text-xs whitespace-nowrap transition-colors">
                                                <span class="material-symbols-outlined text-[16px] text-primary">receipt_long</span>
                                                <span>Đơn hàng</span>
                                            </a>
                                        </c:if>
                                        <c:if test="${me.roleCode == 'CUSTOMER'}">
                                            <a href="${ctx}/user/order" class="flex items-center gap-2 px-3 py-2 rounded-xl text-on-surface hover:text-primary hover:bg-surface-container-high text-xs whitespace-nowrap transition-colors">
                                                <span class="material-symbols-outlined text-[16px] text-primary">receipt_long</span>
                                                <span>Đơn của tôi</span>
                                            </a>
                                            <a href="${ctx}/user/address" class="flex items-center gap-2 px-3 py-2 rounded-xl text-on-surface hover:text-primary hover:bg-surface-container-high text-xs whitespace-nowrap transition-colors">
                                                <span class="material-symbols-outlined text-[16px] text-indigo-400">location_on</span>
                                                <span>Địa chỉ nhận hàng</span>
                                            </a>
                                            <a href="${ctx}/user/warranty" class="flex items-center gap-2 px-3 py-2 rounded-xl text-on-surface hover:text-primary hover:bg-surface-container-high text-xs whitespace-nowrap transition-colors">
                                                <span class="material-symbols-outlined text-[16px] text-amber-400">verified_user</span>
                                                <span>Yêu cầu bảo hành</span>
                                            </a>
                                            <a href="${ctx}/user/notifications" class="flex items-center gap-2 px-3 py-2 rounded-xl text-on-surface hover:text-primary hover:bg-surface-container-high text-xs whitespace-nowrap transition-colors">
                                                <span class="material-symbols-outlined text-[16px] text-sky-400">notifications</span>
                                                <span>Thông báo của tôi</span>
                                            </a>
                                            <a href="${ctx}/user/order/chatbot.jsp" class="flex items-center gap-2 px-3 py-2 rounded-xl text-on-surface hover:text-primary hover:bg-surface-container-high text-xs whitespace-nowrap transition-colors">
                                                <span class="material-symbols-outlined text-[16px] text-emerald-400">smart_toy</span>
                                                <span>Chatbot tư vấn</span>
                                            </a>
                                        </c:if>
                                        <a href="${ctx}/logout" class="mt-1 flex items-center gap-2 px-3 py-2 rounded-xl border-t border-surface-container-high/60 text-red-300 hover:bg-red-500/10 text-xs whitespace-nowrap transition-colors">
                                            <span class="material-symbols-outlined text-[16px]">logout</span>
                                            <span>Đăng xuất</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </c:when>
                    <c:otherwise>
                        <div id="auth-header-container" class="flex items-center gap-1.5">
                            <button id="open-login-btn" type="button"
                                class="inline-flex items-center gap-1 px-3 sm:px-3.5 py-2 rounded-full bg-surface-container-high/60 hover:bg-surface-bright border border-surface-container-high text-on-surface font-label-technical text-xs uppercase tracking-wider transition-all">
                                <span
                                    class="material-symbols-outlined text-[16px]">account_circle</span>
                                <span class="hidden md:inline">Đăng Nhập</span>
                            </button>
                            <button id="open-register-btn" type="button"
                                class="inline-flex items-center gap-1 px-3 sm:px-3.5 py-2 rounded-full bg-surface-container-high/60 hover:bg-surface-bright border border-surface-container-high text-on-surface font-label-technical text-xs uppercase tracking-wider transition-all">
                                <span
                                    class="material-symbols-outlined text-[16px]">account_circle</span>
                                <span class="hidden md:inline">Đăng ký</span>
                            </button>
                        </div>
                    </c:otherwise>
                </c:choose>

                <!-- Mobile Search Toggle -->
                <button id="toggle-mobile-search" type="button"
                    class="lg:hidden w-10 h-10 rounded-full bg-surface-container-high/70 flex items-center justify-center text-on-surface hover:text-primary">
                    <span class="material-symbols-outlined text-[20px]">search</span>
                </button>
            </div>
        </div>

        <!-- Mobile Search Dropdown Bar (Collapsible) -->
        <form method="get" action="${ctx}/home" id="mobile-search-bar"
            class="hidden lg:hidden absolute top-24 left-3 right-3 p-3 rounded-2xl bg-surface-container-lowest/95 backdrop-blur-2xl border border-surface-container-high shadow-2xl flex-col gap-2">
            <div class="flex items-center gap-2">
                <select name="categoryId"
                    class="bg-surface-container text-xs font-label-technical uppercase text-primary px-3 py-2 rounded-xl border border-surface-container-high">
                    <option value="">Tất Cả</option>
                    <c:forEach var="c" items="${categories}">
                        <option value="${c.categoryId}" ${categoryId==c.categoryId ? 'selected' : ''
                            }>
                            <c:out value="${c.categoryName}" />
                        </option>
                    </c:forEach>
                </select>
                <div
                    class="flex-1 flex items-center bg-surface-container-low px-3 py-1.5 rounded-xl border border-surface-container-high">
                    <input name="keyword" type="text" value="<c:out value='${keyword}'/>"
                        placeholder="Tìm sản phẩm..."
                        class="w-full bg-transparent text-xs text-on-surface focus:outline-none" />
                </div>
                <button type="submit"
                    class="px-4 py-2 rounded-xl bg-primary text-on-primary text-xs uppercase font-semibold">
                    Tìm
                </button>
            </div>
        </form>
    </header>

    <main class="relative z-10 w-full pt-16">
        <div
            class="flex flex-col w-full text-on-surface overflow-x-hidden selection:bg-primary-container selection:text-on-primary-container">
            <!-- Ambient Sub-grid Matrix Overlay -->
            <div class="pointer-events-none fixed inset-0 z-0 opacity-[0.025]"
                style="background-image: linear-gradient(to right, #9fd0ff 1px, transparent 1px), linear-gradient(to bottom, #9fd0ff 1px, transparent 1px); background-size: 64px 64px;">
            </div>

            <!-- HERO SECTION -->
            <section
                class="relative min-h-[92vh] flex flex-col justify-center items-center text-center px-gutter pt-20 pb-16 overflow-hidden">
                <!-- Interactive 3D Rotating Graphics Card / GPU Model Layer -->
                <div class="absolute inset-0 w-full h-full bg-transparent opacity-45 pointer-events-auto"
                    style="display:block;">
                    <script
                        src="https://ajax.googleapis.com/ajax/libs/threejs/r125/three.min.js"></script>
                    <div id="threejs-container-ANIMATION_13" style="width:100%;height:100%"></div>
<script src="${ctx}/assets/js/home/three-bg.js"></script>
                </div>

                <!-- Halo Ambient Glows -->
                <div
                    class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[780px] h-[400px] bg-surface-container-lowest/50 rounded-full blur-[100px] pointer-events-none">
                </div>
                <div
                    class="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[680px] h-[320px] bg-primary-container/15 rounded-full blur-[140px] pointer-events-none">
                </div>

                <div
                    class="relative z-20 max-w-5xl mx-auto flex flex-col items-center pointer-events-none">
                    <!-- Status Badge -->
                    <div
                        class="inline-flex items-center gap-space-sm px-space-md py-1.5 rounded-full bg-surface-container/70 border border-surface-container-high/50 backdrop-blur-2xl shadow-sm mb-space-lg pointer-events-auto">
                        <span class="w-1.5 h-1.5 rounded-full bg-primary animate-ping"></span>
                        <span
                            class="font-label-technical text-label-technical tracking-[0.2em] text-primary uppercase">NEXT-GEN
                            COMPUTING ARCHITECTURE // QUANTUM V9</span>
                    </div>

                    <!-- Headline -->
                    <h1
                        class="flex flex-col items-center select-none mb-space-md pointer-events-auto">
                        <span
                            class="font-display-hero text-[64px] sm:text-[90px] md:text-[132px] md:leading-[1.0] font-bold tracking-[-0.045em] bg-gradient-to-b from-white via-primary to-primary-fixed-dim bg-clip-text text-transparent drop-shadow-[0_4px_35px_rgba(0,0,0,0.85)] filter drop-shadow-[0_0_40px_rgba(159,208,255,0.45)]">
                            TechCore
                        </span>
                    </h1>

                    <!-- Subtitle -->
                    <p
                        class="font-body-lg text-body-lg md:text-[20px] md:leading-[30px] font-light text-on-surface-variant max-w-2xl mx-auto text-center tracking-normal mb-space-xl backdrop-blur-md bg-surface-container-lowest/50 border border-surface-container-high/30 px-space-lg py-space-xs rounded-2xl pointer-events-auto shadow-lg">
                        Phân phối linh kiện máy tính cao cấp chính hãng. Trải nghiệm kiến trúc vi xử
                        lý thế hệ mới với hiệu năng tối thượng và độ trễ siêu thấp.
                    </p>

                    <!-- Action Triggers -->
                    <div
                        class="flex flex-wrap items-center justify-center gap-space-md pointer-events-auto">
                        <a href="#catalog-section"
                            class="group relative inline-flex items-center justify-center gap-space-xs px-space-xl py-space-md rounded-full bg-primary-container text-on-primary-container font-headline-sm text-headline-sm font-medium tracking-tight shadow-[0_0_30px_rgba(159,208,255,0.35)] hover:shadow-[0_0_45px_rgba(159,208,255,0.6)] hover:scale-[1.02] active:scale-[0.98] transition-all duration-300">
                            <span>Khám Phá Linh Kiện</span>
                            <span
                                class="material-symbols-outlined text-base group-hover:translate-x-1 transition-transform">arrow_forward</span>
                        </a>
                        <button id="hero-builder-btn" type="button"
                            class="inline-flex items-center justify-center gap-space-sm px-space-lg py-space-md rounded-full bg-surface-container/70 border border-surface-container-high/50 backdrop-blur-2xl text-on-surface font-headline-sm text-headline-sm font-normal tracking-tight hover:bg-surface-bright/80 hover:shadow-[0_0_20px_rgba(159,208,255,0.15)] hover:scale-[1.02] active:scale-[0.98] transition-all duration-300">
                            <span class="material-symbols-outlined text-[20px] text-primary"
                                style="font-variation-settings: 'FILL' 1;">tune</span>
                            <span>Tự Cấu Hình PC</span>
                            <span
                                class="font-label-technical text-[10px] text-on-surface-variant ml-1">ONLINE
                                TOOL</span>
                        </button>
                    </div>

                    <!-- Quick Telemetry Micro-Bar -->
                    <div
                        class="grid grid-cols-2 md:grid-cols-4 gap-space-md w-full max-w-4xl mt-space-xl pt-space-lg pointer-events-auto backdrop-blur-md bg-surface-container-lowest/50 rounded-2xl p-space-sm border border-surface-container-high/40 shadow-lg">
                        <div class="flex flex-col items-center">
                            <span
                                class="font-label-technical text-label-technical text-on-surface-variant tracking-widest uppercase">TIẾN
                                TRÌNH</span>
                            <span
                                class="font-headline-sm text-headline-sm text-on-surface font-light">3nm
                                FinFET Extreme</span>
                        </div>
                        <div class="flex flex-col items-center">
                            <span
                                class="font-label-technical text-label-technical text-on-surface-variant tracking-widest uppercase">BỘ
                                NHỚ ĐỆM</span>
                            <span
                                class="font-headline-sm text-headline-sm text-primary font-light">128MB
                                3D V-Cache</span>
                        </div>
                        <div class="flex flex-col items-center">
                            <span
                                class="font-label-technical text-label-technical text-on-surface-variant tracking-widest uppercase">GIAO
                                TIẾP</span>
                            <span
                                class="font-headline-sm text-headline-sm text-on-surface font-light">PCIe
                                Gen 5.0 x16</span>
                        </div>
                        <div class="flex flex-col items-center">
                            <span
                                class="font-label-technical text-label-technical text-on-surface-variant tracking-widest uppercase">SỐ
                                NHÂN XỬ LÝ</span>
                            <span
                                class="font-headline-sm text-headline-sm text-on-surface font-light">32
                                Cores / 64 Threads</span>
                        </div>
                    </div>
                </div>
            </section>

            <!-- BENTO FEATURE ROW -->
            <section class="w-full max-w-6xl mx-auto px-gutter my-16">
                <div class="grid grid-cols-12 gap-8 items-stretch">
                    <!-- Bento Card 1 -->
                    <div
                        class="col-span-12 lg:col-span-5 min-h-[460px] p-space-xl rounded-lg bg-surface-container/60 backdrop-blur-2xl shadow-xl flex flex-col justify-between relative overflow-hidden group hover:shadow-[0_0_35px_rgba(159,208,255,0.2)] hover:scale-[1.01] transition-all duration-500">
                        <div
                            class="absolute -right-20 -top-20 w-64 h-64 bg-primary-container/10 rounded-full blur-3xl pointer-events-none group-hover:bg-primary-container/20 transition-all duration-700">
                        </div>
                        <div>
                            <div class="flex items-center justify-between mb-space-lg">
                                <span
                                    class="font-label-technical text-label-technical text-primary tracking-[0.2em] uppercase">HARDWARE
                                    ARCHITECTURE // 01</span>
                                <span
                                    class="px-2 py-0.5 rounded-full bg-surface-container-high text-primary font-label-technical text-[10px]">QUANTUM
                                    DIE</span>
                            </div>
                            <h2
                                class="font-headline-lg text-headline-lg font-medium text-on-surface tracking-tight mb-space-sm">
                                Kiến Trúc Đa Nhân 3nm</h2>
                            <p
                                class="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                                Vi kiến trúc thế hệ mới tích hợp 32 nhân 64 luồng xung nhịp Turbo
                                5.8 GHz. Cấu trúc chiplet 3nm tối tân kết hợp tấm nền tiếp xúc IHS
                                mạ nickel tản nhiệt tối ưu dưới áp lực tải nặng.
                            </p>
                        </div>
                        <div class="py-space-lg relative flex items-center justify-center">
                            <div
                                class="relative w-full h-28 flex items-center justify-center overflow-hidden rounded-xl bg-surface-container-low/80 p-space-md">
                                <svg class="w-full h-full text-primary" fill="none"
                                    viewbox="0 0 360 80">
                                    <path class="opacity-90"
                                        d="M0 40 Q30 40 45 40 T90 40 T135 15 T160 65 T180 5 T200 70 T225 35 T270 40 T360 40"
                                        stroke="currentColor" stroke-linecap="round"
                                        stroke-width="2"></path>
                                    <path class="opacity-20 blur-sm"
                                        d="M0 40 Q30 40 45 40 T90 40 T135 15 T160 65 T180 5 T200 70 T225 35 T270 40 T360 40"
                                        stroke="#9fd0ff" stroke-linecap="round" stroke-width="6">
                                    </path>
                                    <circle class="animate-ping" cx="180" cy="5" fill="#ffffff"
                                        r="4"></circle>
                                    <circle cx="180" cy="5" fill="#9fd0ff" r="3"></circle>
                                </svg>
                                <div
                                    class="absolute bottom-2 left-4 flex items-center gap-1.5 font-label-technical text-[10px] text-primary">
                                    <span
                                        class="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
                                    REALTIME BUS PIPELINE 128 GB/s BANDWIDTH
                                </div>
                            </div>
                        </div>
                        <div class="pt-space-md flex items-end justify-between">
                            <div class="flex flex-col">
                                <span
                                    class="font-label-technical text-label-technical text-on-surface-variant tracking-wider uppercase">ĐỘ
                                    TRỄ DỮ LIỆU ĐỆM</span>
                                <span
                                    class="font-body-sm text-body-sm text-on-surface-variant/80">Truy
                                    xuất trực tiếp siêu tốc L3 Cache</span>
                            </div>
                            <div class="flex items-baseline gap-1">
                                <span
                                    class="font-display-hero text-display-hero font-light text-on-surface tracking-tighter">1.8</span>
                                <span
                                    class="font-headline-sm text-headline-sm text-primary font-normal">ns</span>
                            </div>
                        </div>
                    </div>

                    <!-- Bento Card 2 -->
                    <div
                        class="col-span-12 lg:col-span-7 min-h-[460px] p-2 rounded-lg bg-surface-container/60 backdrop-blur-2xl shadow-xl flex flex-col relative overflow-hidden group hover:shadow-[0_0_35px_rgba(159,208,255,0.2)] hover:scale-[1.01] transition-all duration-500">
                        <div
                            class="relative w-full h-full min-h-[420px] rounded-DEFAULT overflow-hidden flex flex-col justify-end p-space-xl">
                            <img alt="Flagship GPU and Hardware Architecture"
                                class="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                                src="https://lh3.googleusercontent.com/aida/ALJJyrCBcUeUEsvPTID1g720SJz5v8Vq11BP-YCMGuClN4Crqk8btYBtsgmiASuYWLlOX-ppKXAhyOUx6eliVcDXCD6yaTfflfetQM41g0xC80-PXj1m04sE4RPxfojdGb6aRayeQdIgWU4Yovnfw3sxdjtZRafEz_YgCpC20o8IDQqbnNOT5ldRJgByuPs5CXOcU_16Q0CG-dxHJM8TFTqopF8Ts2swudEU1m4Pvl-JfdPs" />
                            <div
                                class="absolute inset-0 bg-gradient-to-t from-surface-container-lowest via-surface-container-lowest/50 to-transparent">
                            </div>
                            <div
                                class="absolute inset-0 bg-gradient-to-r from-surface-container-lowest/60 via-transparent to-transparent">
                            </div>
                            <div class="relative z-10 max-w-xl">
                                <div
                                    class="inline-flex items-center gap-2 px-space-sm py-1 rounded-full bg-surface-container-lowest/80 backdrop-blur-md mb-space-sm">
                                    <span class="w-1.5 h-1.5 rounded-full bg-primary"></span>
                                    <span
                                        class="font-label-technical text-label-technical tracking-widest text-primary uppercase">DÒNG
                                        SẢN PHẨM FLAGSHIP // GPU &amp; SILICON</span>
                                </div>
                                <h3
                                    class="font-headline-lg text-headline-lg font-medium text-white tracking-tight mb-2 drop-shadow-md">
                                    Băng Thông 1.2 TB/s Cực Hạn
                                </h3>
                                <p
                                    class="font-body-md text-body-md text-on-surface-variant font-light leading-relaxed mb-space-md">
                                    Tương thích hoàn hảo cùng các dòng VGA đồ họa RTX 4090, 5090 và
                                    bo mạch chủ cao cấp Z790/X670E, khai phóng hiệu năng render 3D,
                                    huấn luyện AI LLM và gaming 4K không giới hạn.
                                </p>
                                <div
                                    class="flex items-center gap-space-lg font-label-technical text-label-technical text-on-surface">
                                    <div class="flex items-center gap-1.5">
                                        <span
                                            class="material-symbols-outlined text-[16px] text-primary">memory</span>
                                        <span>DDR5 8000+ MHz XMP</span>
                                    </div>
                                    <div class="flex items-center gap-1.5">
                                        <span
                                            class="material-symbols-outlined text-[16px] text-primary">speed</span>
                                        <span>PCIe 5.0 NVMe SSD READY</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ALL PRODUCTS SHOWROOM & HARDWARE CATALOG SECTION -->
            <section id="catalog-section"
                class="w-full max-w-7xl mx-auto px-gutter my-16 pt-8 scroll-mt-24">
                <!-- Section Header with Custom PC Builder CTA Banner -->
                <div
                    class="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10 pb-8 border-b border-surface-container-high/40">
                    <div class="max-w-2xl">
                        <div
                            class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-container-high/60 border border-primary/30 backdrop-blur-md mb-3">
                            <span class="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                            <span
                                class="font-label-technical text-label-technical tracking-[0.2em] text-primary uppercase font-medium">KHO
                                SẢN PHẨM PHẦN CỨNG // SẴN HÀNG TOÀN QUỐC</span>
                        </div>
                        <h2
                            class="font-headline-lg text-3xl sm:text-4xl lg:text-5xl font-medium text-white tracking-tight">
                            Tất Cả Sản Phẩm Đang Có Để Bán
                        </h2>
                        <p
                            class="font-body-md text-on-surface-variant font-light mt-3 leading-relaxed">
                            Cung cấp đầy đủ màn hình cao cấp, vi xử lý CPU, bộ nhớ RAM và card đồ
                            họa VGA thế hệ mới. Cam kết 100% chính hãng, bảo hành 1 đổi 1 tận nơi 36
                            tháng.
                        </p>
                    </div>

                    <!-- Highlighted Action: Build Cấu Hình Theo Yêu Cầu -->
                    <div
                        class="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
                        <button id="trigger-builder-catalog-btn" type="button"
                            class="group relative inline-flex items-center justify-center gap-3 px-6 py-4 rounded-2xl bg-gradient-to-r from-primary-container via-sky-300 to-primary text-surface-container-lowest font-headline-sm text-base font-bold tracking-tight shadow-[0_0_35px_rgba(159,208,255,0.45)] hover:shadow-[0_0_55px_rgba(159,208,255,0.75)] hover:scale-[1.02] active:scale-[0.98] transition-all duration-300">
                            <span
                                class="w-8 h-8 rounded-xl bg-surface-container-lowest/20 flex items-center justify-center text-surface-container-lowest group-hover:rotate-12 transition-transform">
                                <span
                                    class="material-symbols-outlined text-[20px]">precision_manufacturing</span>
                            </span>
                            <div class="text-left">
                                <div
                                    class="text-[10px] uppercase font-label-technical tracking-wider opacity-80">
                                    Tự Lựa Chọn &amp; Ước Tính Giá</div>
                                <div
                                    class="text-base font-bold leading-tight flex items-center gap-1.5">
                                    Build Cấu Hình Theo Yêu Cầu
                                    <span
                                        class="material-symbols-outlined text-[18px] group-hover:translate-x-1 transition-transform">arrow_forward</span>
                                </div>
                            </div>
                        </button>
                    </div>
                </div>

                <!-- Product Filters & Control Bar -->
                <div
                    class="bg-surface-container/60 backdrop-blur-2xl rounded-2xl p-4 sm:p-5 border border-surface-container-high/60 shadow-xl mb-8 space-y-4">
                    <!-- Category Filter Buttons (Pills) -->
                    <div class="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none"
                        id="category-pills">
                        <a href="${ctx}/home?keyword=<c:out value='${keyword}'/>&brandId=${brandId}"
                            class="cat-pill px-4 py-2 rounded-xl text-xs font-label-technical uppercase tracking-wider transition-all whitespace-nowrap ${empty categoryId ? 'active bg-primary text-on-primary font-bold shadow-[0_0_15px_rgba(159,208,255,0.4)]' : 'bg-surface-container-high/60 text-on-surface-variant hover:text-white hover:bg-surface-container-high border border-surface-container-high/50'}">
                            Tất Cả (${fn:length(products)})
                        </a>
                        <c:forEach var="c" items="${categories}">
                            <a href="${ctx}/home?categoryId=${c.categoryId}&keyword=<c:out value='${keyword}'/>&brandId=${brandId}"
                                class="cat-pill px-4 py-2 rounded-xl text-xs font-label-technical uppercase tracking-wider transition-all whitespace-nowrap ${categoryId == c.categoryId ? 'active bg-primary text-on-primary font-bold shadow-[0_0_15px_rgba(159,208,255,0.4)]' : 'bg-surface-container-high/60 text-on-surface-variant hover:text-white hover:bg-surface-container-high border border-surface-container-high/50'}">
                                <c:out value="${c.categoryName}" />
                            </a>
                        </c:forEach>
                    </div>

                    <!-- Secondary Filter Form: Brand, Price, Sort, Keyword (Preserving backend GET params) -->
                    <form method="get" action="${ctx}/home" id="catalog-filter-form"
                        class="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 pt-2 border-t border-surface-container-high/40 text-xs">
                        <input type="hidden" name="categoryId" value="${categoryId}" />
                        <div class="flex flex-wrap items-center gap-2 sm:gap-4">
                            <!-- Brand Filter -->
                            <div
                                class="flex items-center gap-1.5 text-on-surface-variant font-label-technical">
                                <span>THƯƠNG HIỆU:</span>
                                <select name="brandId" onchange="this.form.submit()"
                                    class="bg-surface-container-low px-3 py-1.5 rounded-lg border border-surface-container-high text-on-surface focus:outline-none focus:border-primary">
                                    <option value="">-- Tất cả thương hiệu --</option>
                                    <c:forEach var="b" items="${brands}">
                                        <option value="${b.brandId}" ${brandId==b.brandId
                                            ? 'selected' : '' }>
                                            <c:out value="${b.brandName}" />
                                        </option>
                                    </c:forEach>
                                </select>
                            </div>

                            <!-- Price Range Filter (In-page filter) -->
                            <div
                                class="flex items-center gap-1.5 text-on-surface-variant font-label-technical">
                                <span>MỨC GIÁ:</span>
                                <select id="price-filter-select"
                                    class="bg-surface-container-low px-3 py-1.5 rounded-lg border border-surface-container-high text-on-surface focus:outline-none focus:border-primary">
                                    <option value="all">Tất Cả Mức Giá</option>
                                    <option value="under10">Dưới 10 Triệu</option>
                                    <option value="10to25">10 Triệu - 25 Triệu</option>
                                    <option value="above25">Trên 25 Triệu</option>
                                </select>
                            </div>

                            <!-- Sort Options -->
                            <div
                                class="flex items-center gap-1.5 text-on-surface-variant font-label-technical">
                                <span>SẮP XẾP:</span>
                                <select id="sort-filter-select"
                                    class="bg-surface-container-low px-3 py-1.5 rounded-lg border border-surface-container-high text-on-surface focus:outline-none focus:border-primary">
                                    <option value="featured">Mặc Định</option>
                                    <option value="price-asc">Giá: Thấp đến Cao</option>
                                    <option value="price-desc">Giá: Cao đến Thấp</option>
                                    <option value="name">Tên: A - Z</option>
                                </select>
                            </div>
                        </div>

                        <!-- Search Summary & Quick In-page Search -->
                        <div class="flex items-center gap-3">
                            <span id="filtered-count-text"
                                class="text-on-surface-variant font-label-technical text-xs whitespace-nowrap">
                                Đang hiển thị <strong
                                    class="text-primary font-semibold">${fn:length(products)}</strong>
                                sản phẩm
                            </span>
                            <div class="relative w-full sm:w-56">
                                <input id="inpage-search-input" name="keyword" type="text"
                                    value="<c:out value='${keyword}'/>"
                                    placeholder="Tìm theo tên/SKU..."
                                    class="w-full bg-surface-container-low pl-8 pr-8 py-1.5 rounded-lg border border-surface-container-high text-on-surface text-xs focus:outline-none focus:border-primary" />
                                <span
                                    class="material-symbols-outlined text-[16px] text-on-surface-variant absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none">search</span>
                                <button type="submit"
                                    class="absolute right-2 top-1/2 -translate-y-1/2 text-primary hover:text-white"
                                    title="Tìm kiếm">
                                    <span
                                        class="material-symbols-outlined text-[16px]">arrow_forward</span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- Empty State Alert when search yields 0 items -->
                <c:if test="${empty products}">
                    <div id="empty-products-state"
                        class="text-center py-16 px-4 bg-surface-container/40 rounded-2xl border border-surface-container-high mb-8">
                        <span
                            class="material-symbols-outlined text-6xl text-primary/50 mb-3">inventory_2</span>
                        <h3 class="font-headline-md text-white text-xl font-medium mb-1">Không tìm
                            thấy linh kiện phù hợp</h3>
                        <p
                            class="font-body-md text-on-surface-variant text-sm max-w-md mx-auto mb-5">
                            Không có sản phẩm nào phù hợp với bộ lọc hiện tại. Thử tìm kiếm với từ
                            khóa khác hoặc xóa bộ lọc.
                        </p>
                        <a href="${ctx}/home"
                            class="inline-block px-5 py-2.5 rounded-full bg-primary-container text-on-primary-container font-label-technical text-xs uppercase tracking-wider hover:bg-primary transition-all">
                            Xem Tất Cả Sản Phẩm
                        </a>
                    </div>
                </c:if>

                <!-- Dynamic Empty State for In-page Filters (hidden by default) -->
                <div id="js-empty-state"
                    class="hidden text-center py-16 px-4 bg-surface-container/40 rounded-2xl border border-surface-container-high mb-8">
                    <span
                        class="material-symbols-outlined text-6xl text-primary/50 mb-3">filter_alt_off</span>
                    <h3 class="font-headline-md text-white text-xl font-medium mb-1">Không có kết
                        quả trong trang</h3>
                    <p class="font-body-md text-on-surface-variant text-sm max-w-md mx-auto mb-5">
                        Thử điều chỉnh lại mức giá hoặc từ khóa tìm kiếm nhanh trên danh sách hiện
                        tại.
                    </p>
                    <button id="reset-inpage-filter-btn" type="button"
                        class="px-5 py-2.5 rounded-full bg-primary-container text-on-primary-container font-label-technical text-xs uppercase tracking-wider hover:bg-primary transition-all">
                        Đặt Lại Bộ Lọc
                    </button>
                </div>

                <!-- Products Grid -->
                <div id="products-grid"
                    class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    <c:forEach var="p" items="${products}">
                        <div class="product-card group relative rounded-2xl bg-surface-container/60 hover:bg-surface-container/90 backdrop-blur-xl border border-surface-container-high/60 hover:border-primary/50 shadow-lg hover:shadow-[0_0_35px_rgba(159,208,255,0.25)] flex flex-col justify-between overflow-hidden transition-all duration-300"
                            data-id="${p.productId}" data-name="<c:out value='${p.productName}'/>"
                            data-sku="<c:out value='${p.sku}'/>" data-price="${p.price}"
                            data-category="<c:out value='${p.category.categoryName}'/>"
                            data-category-id="${p.category.categoryId}"
                            data-brand="<c:out value='${p.brand.brandName}'/>"
                            data-stock="${p.stock != null ? p.stock : 0}"
                            data-image="<c:out value='${p.thumbnailUrl}'/>">

                            <!-- Top Ribbon / Badges -->
                            <div class="p-4 pb-0 flex items-center justify-between z-10">
                                <span
                                    class="px-2.5 py-1 rounded-full bg-primary/15 border border-primary/30 text-primary font-label-technical text-[10px] uppercase font-bold tracking-wider">
                                    <c:out value="${p.category.categoryName}" />
                                </span>
                                <span
                                    class="px-2 py-0.5 rounded-full ${p.stock > 0 ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'} font-label-technical text-[10px] font-bold">
                                    ${p.stock > 0 ? 'Còn hàng' : 'Hết hàng'}
                                </span>
                            </div>

                            <!-- Product Image -->
                            <div
                                class="relative w-full h-48 px-4 flex items-center justify-center overflow-hidden my-2">
                                <c:choose>
                                    <c:when test="${not empty p.thumbnailUrl}">
                                        <img src="<c:out value='${p.thumbnailUrl}'/>"
                                            alt="<c:out value='${p.productName}'/>"
                                            class="w-full h-full object-contain rounded-xl group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100" />
                                    </c:when>
                                    <c:otherwise>
                                        <div
                                            class="w-full h-full flex flex-col items-center justify-center bg-surface-container-high/40 rounded-xl text-on-surface-variant">
                                            <span
                                                class="material-symbols-outlined text-4xl text-primary/40">memory</span>
                                            <span
                                                class="text-xs font-label-technical mt-1">CoreTech</span>
                                        </div>
                                    </c:otherwise>
                                </c:choose>
                                <div
                                    class="absolute inset-0 bg-gradient-to-t from-surface-container/80 via-transparent to-transparent pointer-events-none">
                                </div>
                            </div>

                            <!-- Product Info -->
                            <div class="p-5 pt-1 flex-1 flex flex-col justify-between">
                                <div>
                                    <div
                                        class="flex items-center gap-1.5 text-xs text-amber-400 font-label-technical mb-1">
                                        <span
                                            class="material-symbols-outlined text-[14px]">verified</span>
                                        <span class="text-white font-medium">
                                            <c:out value="${p.brand.brandName}" />
                                        </span>
                                        <span class="text-on-surface-variant">&middot; SKU:
                                            <c:out value="${p.sku}" />
                                        </span>
                                    </div>

                                    <h3 class="font-headline-sm text-base font-semibold text-white tracking-tight line-clamp-2 group-hover:text-primary transition-colors"
                                        title="<c:out value='${p.productName}'/>">
                                        <c:out value="${p.productName}" />
                                    </h3>

                                    <p
                                        class="font-body-sm text-xs text-on-surface-variant line-clamp-2 mt-1 mb-3">
                                        <c:choose>
                                            <c:when test="${not empty p.description}">
                                                <c:out value="${p.description}" />
                                            </c:when>
                                            <c:otherwise>
                                                Chính hãng 100% &middot; Bảo hành
                                                <c:out value="${p.warrantyMonths}" /> tháng &middot;
                                                Giao hàng hoả tốc
                                            </c:otherwise>
                                        </c:choose>
                                    </p>
                                </div>

                                <div>
                                    <!-- Price Block -->
                                    <div class="mb-4">
                                        <div class="flex items-baseline gap-2">
                                            <span
                                                class="text-xl font-headline-md font-bold text-white tracking-tight">
                                                <t:money value="${p.price}" />
                                            </span>
                                        </div>
                                        <div
                                            class="flex items-center gap-1 text-[10px] font-label-technical text-emerald-400 mt-0.5">
                                            <span
                                                class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                                            <span>Bảo hành:
                                                <c:out value="${p.warrantyMonths}" /> tháng &middot;
                                                ${p.stock > 0 ? 'Có sẵn tại kho' : 'Tạm hết hàng'}
                                            </span>
                                        </div>
                                    </div>

                                    <!-- Action Buttons -->
                                    <div class="grid ${canBuy ? 'grid-cols-2' : 'grid-cols-1'} gap-2">
<c:if test="${canBuy}">
                                        <button type="button" onclick="handleAddToCart(this)"
                                            class="w-full py-2.5 rounded-xl bg-primary-container/80 hover:bg-primary text-on-primary-container font-label-technical text-xs uppercase tracking-wider font-semibold transition-all flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(159,208,255,0.25)]">
                                            <span
                                                class="material-symbols-outlined text-[16px]">shopping_cart</span>
                                            <span>Thêm Giỏ</span>
                                        </button>
</c:if>
                                        <button type="button" onclick="handleAddToBuilder(this)"
                                            class="w-full py-2.5 rounded-xl bg-surface-container-high/60 hover:bg-surface-bright text-on-surface font-label-technical text-xs uppercase tracking-wider font-semibold transition-all flex items-center justify-center gap-1 border border-surface-container-high">
                                            <span
                                                class="material-symbols-outlined text-[16px] text-primary">tune</span>
                                            <span>+ Cấu Hình</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </section>

            <!-- THREE-COLUMN FEATURE CARDS -->
            <section class="w-full max-w-6xl mx-auto px-gutter my-12 mb-28">
                <div
                    class="flex flex-col md:flex-row md:items-end justify-between mb-space-xl gap-space-md">
                    <div>
                        <span
                            class="font-label-technical text-label-technical tracking-[0.2em] text-primary uppercase">TIÊU
                            CHUẨN PHẦN CỨNG ENTHUSIAST</span>
                        <h2
                            class="font-headline-lg text-headline-lg font-medium text-on-surface tracking-tight mt-1">
                            Hệ Sinh Thái Linh Kiện Cao Cấp
                        </h2>
                    </div>
                    <p class="font-body-md text-body-md text-on-surface-variant max-w-md">
                        Cam kết 100% linh kiện chính hãng, bảo hành đổi mới tận nơi 36 tháng, tư vấn
                        tối ưu hoá hệ thống và tra keo tản nhiệt kim loại lỏng chuyên nghiệp.
                    </p>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Feature Card 1 -->
                    <div
                        class="rounded-lg p-space-xl bg-surface-container/60 backdrop-blur-2xl shadow-xl flex flex-col justify-between group hover:shadow-[0_0_35px_rgba(159,208,255,0.22)] hover:scale-[1.02] transition-all duration-500">
                        <div>
                            <div
                                class="w-12 h-12 rounded-2xl bg-surface-container-high flex items-center justify-center mb-space-lg text-primary group-hover:scale-110 group-hover:bg-primary group-hover:text-on-primary transition-all duration-300 shadow-sm">
                                <span
                                    class="material-symbols-outlined text-[24px]">developer_board</span>
                            </div>
                            <h3
                                class="font-headline-md text-headline-md font-medium text-on-surface tracking-tight mb-space-sm">
                                CPU &amp; Processors
                            </h3>
                            <p
                                class="font-body-md text-body-md text-on-surface-variant font-light leading-relaxed mb-space-lg">
                                Đầy đủ các dòng CPU Intel Core Ultra 9, AMD Ryzen 9 3D V-Cache và vi
                                xử lý máy trạm Threadripper Pro phục vụ đồ hoạ nặng và tính toán
                                khoa học.
                            </p>
                        </div>
                        <div class="pt-space-md flex items-center justify-between">
                            <span
                                class="font-label-technical text-label-technical text-on-surface tracking-wider uppercase font-semibold">100%
                                CHÍNH HÃNG BOX</span>
                            <span
                                class="material-symbols-outlined text-primary text-[18px]">verified</span>
                        </div>
                    </div>
                    <!-- Feature Card 2 -->
                    <div
                        class="rounded-lg p-space-xl bg-surface-container/60 backdrop-blur-2xl shadow-xl flex flex-col justify-between group hover:shadow-[0_0_35px_rgba(159,208,255,0.22)] hover:scale-[1.02] transition-all duration-500">
                        <div>
                            <div
                                class="w-12 h-12 rounded-2xl bg-surface-container-high flex items-center justify-center mb-space-lg text-primary group-hover:scale-110 group-hover:bg-primary group-hover:text-on-primary transition-all duration-300 shadow-sm">
                                <span
                                    class="material-symbols-outlined text-[24px]">view_in_ar</span>
                            </div>
                            <h3
                                class="font-headline-md text-headline-md font-medium text-on-surface tracking-tight mb-space-sm">
                                Card Đồ Họa VGA
                            </h3>
                            <p
                                class="font-body-md text-body-md text-on-surface-variant font-light leading-relaxed mb-space-lg">
                                Thế hệ GPU cao cấp trang bị buồng hơi làm mát Vapor Chamber, kiến
                                trúc Ray Tracing thời gian thực và nhân Tensor phục vụ tăng tốc trí
                                tuệ nhân tạo.
                            </p>
                        </div>
                        <div class="pt-space-md flex items-center justify-between">
                            <span
                                class="font-label-technical text-label-technical text-on-surface tracking-wider uppercase font-semibold">RAY
                                TRACING // DLSS 3.5</span>
                            <span
                                class="material-symbols-outlined text-primary text-[18px]">bolt</span>
                        </div>
                    </div>
                    <!-- Feature Card 3 -->
                    <div
                        class="rounded-lg p-space-xl bg-surface-container/60 backdrop-blur-2xl shadow-xl flex flex-col justify-between group hover:shadow-[0_0_35px_rgba(159,208,255,0.22)] hover:scale-[1.02] transition-all duration-500">
                        <div>
                            <div
                                class="w-12 h-12 rounded-2xl bg-surface-container-high flex items-center justify-center mb-space-lg text-primary group-hover:scale-110 group-hover:bg-primary group-hover:text-on-primary transition-all duration-300 shadow-sm">
                                <span class="material-symbols-outlined text-[24px]">mode_fan</span>
                            </div>
                            <h3
                                class="font-headline-md text-headline-md font-medium text-on-surface tracking-tight mb-space-sm">
                                Tản Nước Custom &amp; PSU
                            </h3>
                            <p
                                class="font-body-md text-body-md text-on-surface-variant font-light leading-relaxed mb-space-lg">
                                Hệ thống tản nhiệt nước AIO 360mm/420mm kết hợp khối nguồn Titanium
                                ATX 3.1 chuẩn PCIe 5.1 đảm bảo độ ổn định tuyệt đối trong suốt quá
                                trình ép xung.
                            </p>
                        </div>
                        <div class="pt-space-md flex items-center justify-between">
                            <span
                                class="font-label-technical text-label-technical text-on-surface tracking-wider uppercase font-semibold">80
                                PLUS TITANIUM / PLATINUM</span>
                            <span
                                class="material-symbols-outlined text-primary text-[18px]">thermostat</span>
                        </div>
                    </div>
                </div>
            </section>

            <!-- IMMERSIVE CALL-TO-ACTION PRE-ORDER CONSOLE -->
            <section class="w-full max-w-6xl mx-auto px-gutter mb-24">
                <div
                    class="rounded-lg p-space-xl md:p-14 bg-surface-container/80 backdrop-blur-2xl shadow-2xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-space-xl">
                    <div
                        class="absolute -left-12 -bottom-12 w-96 h-96 bg-primary-container/20 rounded-full blur-[100px] pointer-events-none">
                    </div>
                    <div class="relative z-10 max-w-xl">
                        <span
                            class="font-label-technical text-label-technical tracking-[0.2em] text-primary uppercase">BUILD
                            YOUR ULTIMATE RIG</span>
                        <h2
                            class="font-headline-lg text-headline-lg font-medium text-white tracking-tight mt-2 mb-space-sm">
                            Khởi Đầu Cỗ Máy Chiến Game &amp; Đồ Họa Của Bạn
                        </h2>
                        <p class="font-body-md text-body-md text-on-surface-variant font-light">
                            Hỗ trợ trả góp 0%, miễn phí lắp ráp custom nước và giao hàng hoả tốc
                            toàn quốc kèm gói bảo hành tận nhà VIP 3 năm.
                        </p>
                    </div>
                    <div
                        class="relative z-10 flex flex-col sm:flex-row items-center gap-space-md w-full md:w-auto">
                        <div class="flex flex-col text-right sm:pr-space-md">
                            <span
                                class="font-label-technical text-[10px] text-on-surface-variant uppercase">COMBO
                                TỪ</span>
                            <span
                                class="font-headline-md text-headline-md font-semibold text-white tracking-tight">18.990.000₫</span>
                        </div>
                        <button id="cta-builder-btn" type="button"
                            class="w-full sm:w-auto inline-flex items-center justify-center gap-space-sm px-space-xl py-space-md rounded-full bg-primary-container text-on-primary-container font-headline-sm text-headline-sm font-semibold tracking-tight shadow-[0_0_30px_rgba(159,208,255,0.4)] hover:shadow-[0_0_50px_rgba(159,208,255,0.7)] hover:scale-[1.02] active:scale-[0.98] transition-all duration-300">
                            <span>Xem Báo Giá Ngay</span>
                            <span class="material-symbols-outlined text-[20px]">bolt</span>
                        </button>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <!-- FOOTER -->
    <footer class="relative z-10 w-full mt-space-xl pb-space-lg">
        <div
            class="w-full px-margin md:px-margin-desktop flex flex-col md:flex-row items-center justify-between gap-space-md font-label-technical text-label-technical text-on-surface-variant">
            <div class="flex items-center gap-space-sm">
                <span
                    class="w-2 h-2 rounded-full bg-primary-container animate-pulse shadow-[0_0_8px_rgba(159,208,255,0.8)]"></span>
                <span>CORETECH HARDWARE // QUANTUM ARCHITECTURE PLATFORM &middot; DỰ ÁN JAVA 1
                    &ndash; FPT POLYTECHNIC</span>
            </div>
            <div class="text-center md:text-right">
                &copy; CORETECH HARDWARE INC. ALL RIGHTS RESERVED. HIGH-END COMPUTING.
            </div>
        </div>
    </footer>

    <!-- ========================================================================= -->
    <!-- MODALS & DRAWERS: CART, PC BUILDER, AUTH & TOASTS                           -->
    <!-- ========================================================================= -->

    <!-- 1. CART SLIDE-OVER DRAWER -->
    <div id="cart-drawer-overlay"
        class="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm hidden transition-opacity duration-300">
        <div class="fixed inset-y-0 right-0 max-w-full flex">
            <div id="cart-drawer-panel"
                class="w-screen max-w-md bg-surface-container-lowest/95 backdrop-blur-2xl border-l border-surface-container-high/60 shadow-2xl flex flex-col transform translate-x-full transition-transform duration-300 ease-in-out">
                <!-- Cart Header -->
                <div
                    class="p-6 border-b border-surface-container-high/50 flex items-center justify-between">
                    <div class="flex items-center gap-2.5">
                        <span
                            class="w-8 h-8 rounded-full bg-primary-container/30 flex items-center justify-center text-primary">
                            <span class="material-symbols-outlined text-[18px]">shopping_bag</span>
                        </span>
                        <div>
                            <h3
                                class="font-headline-sm text-lg font-medium text-white tracking-tight">
                                Giỏ Hàng Công Nghệ</h3>
                            <p class="font-label-technical text-xs text-on-surface-variant"><span
                                    id="cart-drawer-count">0</span> sản phẩm đã chọn</p>
                        </div>
                    </div>
                    <button id="close-cart-btn" type="button"
                        class="w-8 h-8 rounded-full bg-surface-container-high/50 hover:bg-surface-bright flex items-center justify-center text-on-surface hover:text-white transition-all">
                        <span class="material-symbols-outlined text-[18px]">close</span>
                    </button>
                </div>

                <!-- Cart Items Scrollable List -->
                <div id="cart-items-container" class="flex-1 overflow-y-auto p-6 space-y-4"></div>

                <!-- Empty Cart State -->
                <div id="cart-empty-state"
                    class="hidden flex-1 flex flex-col items-center justify-center p-6 text-center">
                    <span
                        class="material-symbols-outlined text-5xl text-on-surface-variant/40 mb-3">remove_shopping_cart</span>
                    <p class="font-headline-sm text-sm text-white mb-1">Giỏ hàng của bạn đang trống
                    </p>
                    <p class="font-body-sm text-xs text-on-surface-variant mb-4">Hãy chọn linh kiện
                        màn hình, CPU, RAM hoặc VGA để thêm vào giỏ.</p>
                    <button id="cart-empty-shop-btn" type="button"
                        class="px-4 py-2 rounded-full bg-primary-container text-on-primary-container font-label-technical text-xs uppercase tracking-wider hover:bg-primary transition-all">
                        Khám Phá Linh Kiện
                    </button>
                </div>

                <!-- Cart Footer / Summary -->
                <div id="cart-footer-summary"
                    class="p-6 border-t border-surface-container-high/50 bg-surface-container-low/50 space-y-3">
                    <div
                        class="flex items-center justify-between text-xs font-label-technical text-on-surface-variant">
                        <span>TẠM TÍNH</span>
                        <span id="cart-subtotal" class="text-white font-medium">0₫</span>
                    </div>
                    <div
                        class="flex items-center justify-between text-xs font-label-technical text-on-surface-variant">
                        <span>VẬN CHUYỂN VIP HOẢ TỐC</span>
                        <span class="text-primary font-medium">MIỄN PHÍ</span>
                    </div>
                    <div
                        class="pt-2 border-t border-surface-container-high/40 flex items-center justify-between">
                        <span class="font-headline-sm text-sm text-white">TỔNG THANH TOÁN</span>
                        <span id="cart-total"
                            class="font-headline-md text-xl font-bold text-primary tracking-tight">0₫</span>
                    </div>
                    <button id="cart-checkout-btn" type="button"
                        class="w-full py-3.5 rounded-full bg-primary text-on-primary font-headline-sm text-sm font-semibold tracking-tight shadow-[0_0_20px_rgba(159,208,255,0.4)] hover:bg-white hover:shadow-[0_0_30px_rgba(255,255,255,0.6)] active:scale-[0.98] transition-all flex items-center justify-center gap-2">
                        <span>Tiến Hành Đặt Hàng &amp; Thanh Toán</span>
                        <span class="material-symbols-outlined text-[18px]">arrow_forward</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- 3. AUTH MODAL (LOGIN & REGISTER) -->
    <div id="auth-modal"
        class="fixed inset-0 z-50 bg-black/80 backdrop-blur-md hidden items-center justify-center p-4">
        <div
            class="w-full max-w-md bg-surface-container-lowest/95 backdrop-blur-2xl border border-surface-container-high/70 rounded-3xl p-6 sm:p-8 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
            <!-- Close Button -->
            <button id="close-auth-btn" type="button"
                class="absolute top-5 right-5 w-8 h-8 rounded-full bg-surface-container-high/60 hover:bg-surface-bright flex items-center justify-center text-on-surface hover:text-white transition-all">
                <span class="material-symbols-outlined text-[18px]">close</span>
            </button>

            <!-- Brand Icon -->
            <div
                class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-primary to-primary-container flex items-center justify-center text-surface-container-lowest shadow-[0_0_20px_rgba(159,208,255,0.4)] mb-4">
                <span class="material-symbols-outlined text-[24px]">account_circle</span>
            </div>

            <!-- Tab Switcher -->
            <div
                class="flex items-center p-1 rounded-xl bg-surface-container-high/50 border border-surface-container-high/60 mb-6">
                <button id="tab-login-btn" type="button"
                    class="flex-1 py-2 text-xs font-label-technical uppercase tracking-wider rounded-lg font-bold bg-primary text-on-primary transition-all shadow-sm">
                    Đăng Nhập
                </button>
                <button id="tab-register-btn" type="button"
                    class="flex-1 py-2 text-xs font-label-technical uppercase tracking-wider rounded-lg font-medium text-on-surface-variant hover:text-white transition-all">
                    Đăng Ký
                </button>
            </div>

            <!-- LOGIN FORM (Posts to ${ctx}/login) -->
            <form id="login-form" method="post" action="${ctx}/login" class="space-y-4">
                <div>
                    <label
                        class="block text-[11px] font-label-technical uppercase tracking-wider text-on-surface-variant mb-1.5">
                        Email hoặc Tên Đăng Nhập
                    </label>
                    <div class="relative">
                        <input name="username" type="text" required
                            placeholder="name@example.com hoặc SĐT"
                            class="w-full bg-surface-container-low px-4 py-2.5 rounded-xl border border-surface-container-high text-on-surface text-sm focus:outline-none focus:border-primary transition-all" />
                        <span
                            class="material-symbols-outlined text-[18px] text-on-surface-variant absolute right-3 top-1/2 -translate-y-1/2">mail</span>
                    </div>
                </div>
                <div>
                    <div class="flex items-center justify-between mb-1.5">
                        <label
                            class="block text-[11px] font-label-technical uppercase tracking-wider text-on-surface-variant">Mật
                            Khẩu</label>
                        <a href="${ctx}/login"
                            class="text-[11px] text-primary hover:underline font-label-technical">Quên
                            mật khẩu?</a>
                    </div>
                    <div class="relative">
                        <input name="password" type="password" required placeholder="••••••••"
                            class="w-full bg-surface-container-low px-4 py-2.5 rounded-xl border border-surface-container-high text-on-surface text-sm focus:outline-none focus:border-primary transition-all" />
                        <span
                            class="material-symbols-outlined text-[18px] text-on-surface-variant absolute right-3 top-1/2 -translate-y-1/2">lock</span>
                    </div>
                </div>
                <div class="flex items-center">
                    <input id="remember-me" type="checkbox" checked
                        class="w-4 h-4 rounded bg-surface-container-low border-surface-container-high text-primary focus:ring-0">
                    <label for="remember-me" class="ml-2 text-xs text-on-surface-variant">Ghi nhớ
                        đăng nhập 30 ngày</label>
                </div>
                <button type="submit"
                    class="w-full py-3 rounded-full bg-primary text-on-primary font-headline-sm text-sm font-semibold tracking-tight shadow-[0_0_20px_rgba(159,208,255,0.4)] hover:bg-white transition-all">
                    Đăng Nhập Ngay
                </button>
            </form>

            <!-- REGISTER FORM (Posts to ${ctx}/register) -->
            <form id="register-form" method="post" action="${ctx}/register" class="space-y-3 hidden">
                <div>
                    <label
                        class="block text-[11px] font-label-technical uppercase tracking-wider text-on-surface-variant mb-1">Họ
                        và Tên</label>
                    <input name="fullName" type="text" required placeholder="Nguyễn Văn A"
                        class="w-full bg-surface-container-low px-4 py-2 rounded-xl border border-surface-container-high text-on-surface text-sm focus:outline-none focus:border-primary" />
                </div>
                <div>
                    <label
                        class="block text-[11px] font-label-technical uppercase tracking-wider text-on-surface-variant mb-1">Email</label>
                    <input name="email" type="email" placeholder="name@example.com"
                        class="w-full bg-surface-container-low px-4 py-2 rounded-xl border border-surface-container-high text-on-surface text-sm focus:outline-none focus:border-primary" />
                </div>
                <div>
                    <label
                        class="block text-[11px] font-label-technical uppercase tracking-wider text-on-surface-variant mb-1">Số điện thoại</label>
                    <input name="phone" type="text" placeholder="09xxxxxxxx"
                        class="w-full bg-surface-container-low px-4 py-2 rounded-xl border border-surface-container-high text-on-surface text-sm focus:outline-none focus:border-primary" />
                </div>
                <div>
                    <label
                        class="block text-[11px] font-label-technical uppercase tracking-wider text-on-surface-variant mb-1">Mật
                        Khẩu</label>
                    <input name="password" type="password" required minlength="6" placeholder="Tối thiểu 6 ký tự"
                        class="w-full bg-surface-container-low px-4 py-2 rounded-xl border border-surface-container-high text-on-surface text-sm focus:outline-none focus:border-primary" />
                </div>
                <div>
                    <label
                        class="block text-[11px] font-label-technical uppercase tracking-wider text-on-surface-variant mb-1">Nhập lại Mật Khẩu</label>
                    <input name="confirmPassword" type="password" required minlength="6" placeholder="Nhập lại mật khẩu"
                        class="w-full bg-surface-container-low px-4 py-2 rounded-xl border border-surface-container-high text-on-surface text-sm focus:outline-none focus:border-primary" />
                </div>
                <button type="submit"
                    class="w-full py-3 mt-2 rounded-full bg-primary text-on-primary font-headline-sm text-sm font-semibold tracking-tight shadow-[0_0_20px_rgba(159,208,255,0.4)] hover:bg-white transition-all">
                    Đăng Ký Tài Khoản
                </button>
            </form>

            <div class="relative my-6">
                <div class="absolute inset-0 flex items-center">
                    <div class="w-full border-t border-surface-container-high/60"></div>
                </div>
                <div
                    class="relative flex justify-center text-[10px] font-label-technical uppercase tracking-wider">
                    <span class="bg-surface-container-lowest px-3 text-on-surface-variant">HOẶC TIẾP
                        TỤC VỚI</span>
                </div>
            </div>

            <a href="${ctx}/login"
                class="w-full py-2.5 rounded-xl bg-surface-container-high/50 hover:bg-surface-bright border border-surface-container-high flex items-center justify-center gap-2 text-xs text-on-surface font-medium transition-all">
                <svg class="w-4 h-4" viewBox="0 0 24 24">
                    <path fill="#4285F4"
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853"
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05"
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335"
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Đăng nhập hệ thống</span>
            </a>
        </div>
    </div>

    <!-- 4. TOAST NOTIFICATIONS CONTAINER -->
    <div id="toast-container"
        class="fixed bottom-6 right-6 z-[100] flex flex-col gap-2.5 pointer-events-none max-w-sm w-full px-4">
    </div>

    <!-- JAVASCRIPT LOGIC -->
<script src="${ctx}/assets/js/common/shop.js"></script>
<script src="${ctx}/assets/js/home/home.js"></script>
</body>

</html>
