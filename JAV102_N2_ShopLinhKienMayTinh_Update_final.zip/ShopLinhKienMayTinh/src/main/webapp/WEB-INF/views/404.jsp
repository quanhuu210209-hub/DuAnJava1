<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Không tìm thấy — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/public.css">
</head>
<body class="public">
<div class="auth-card">
<h1>404 - Không tìm thấy trang</h1>
<p>Đường dẫn bạn truy cập không tồn tại.</p>
<p><a href="${pageContext.request.contextPath}/home">Về trang chủ</a></p>
</div>
</body>
</html>
