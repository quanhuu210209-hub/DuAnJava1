<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Không có quyền — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/public.css">
</head>
<body class="public">
<div class="auth-card">
<h1>403 - Không có quyền truy cập</h1>
<p>Tài khoản của bạn không được phép vào trang này.</p>
<p><a href="${pageContext.request.contextPath}/home">Về trang chủ</a></p>
</div>
</body>
</html>
