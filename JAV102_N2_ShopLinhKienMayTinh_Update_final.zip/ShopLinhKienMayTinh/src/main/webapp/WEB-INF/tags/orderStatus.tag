<%@ tag pageEncoding="UTF-8" body-content="empty" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ attribute name="value" required="true" type="java.lang.String" %>
<c:choose>
    <c:when test="${value == 'Pending'}">Chờ xử lý</c:when>
    <c:when test="${value == 'Paid'}">Đã thanh toán</c:when>
    <c:when test="${value == 'Shipping'}">Đang giao</c:when>
    <c:when test="${value == 'Completed'}">Hoàn tất</c:when>
    <c:when test="${value == 'Cancelled'}">Đã hủy</c:when>
    <c:otherwise><c:out value="${value}"/></c:otherwise>
</c:choose>