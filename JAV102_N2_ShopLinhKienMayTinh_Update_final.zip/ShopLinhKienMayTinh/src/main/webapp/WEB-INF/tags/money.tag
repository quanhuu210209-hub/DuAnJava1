<%@ tag pageEncoding="UTF-8" %>
<%@ tag body-content="empty" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ attribute name="value" required="false" type="java.lang.Object" %>
<c:if test="${not empty value}"><fmt:formatNumber value="${value}" type="number" groupingUsed="true" maxFractionDigits="0"/> &#8363;</c:if>
