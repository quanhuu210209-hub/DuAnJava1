<%@ tag body-content="empty" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ attribute name="value" required="false" type="java.lang.Object" %>
<c:if test="${not empty value}"><c:out value="${fn:replace(fn:substring(value, 0, 16), 'T', ' ')}"/></c:if>
