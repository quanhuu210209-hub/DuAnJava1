<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<c:set var="ctx" value="${pageContext.request.contextPath}" />
<c:set var="me" value="${sessionScope.loginUser}" />
<c:set var="canBuy" value="${empty me or me.roleCode == 'CUSTOMER'}" />
<!DOCTYPE html>
<html class="dark" lang="vi">

<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="web_standard" name="shell-type" />
    <title>Build Cấu Hình PC - CoreTech</title>
    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"
        rel="stylesheet" />
    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap"
        rel="stylesheet" />
    <link
        href="https://fonts.googleapis.com/css2?family=Geist:wght@100..900&amp;family=JetBrains+Mono:wght@100..900&amp;display=swap"
        rel="stylesheet" />
<link rel="stylesheet" href="${ctx}/assets/css/home.css" />
    <script src="https://cdn.tailwindcss.com"></script>
<script src="${ctx}/assets/js/home/tailwind-config.js"></script>
</head>

<body data-ctx="${ctx}" data-role="${me.roleCode}"
    class="bg-surface-container-lowest font-body-md text-body-md text-on-surface min-h-screen relative selection:bg-primary-container selection:text-on-primary-container">

    <header class="fixed top-4 left-1/2 -translate-x-1/2 z-40 w-[calc(100%-2rem)] max-w-4xl flex items-center justify-between px-5 py-3 rounded-full bg-surface-container-lowest/80 backdrop-blur-2xl border border-surface-container-high/60">
        <a href="${ctx}/home" class="text-white font-bold italic tracking-tight">CoreTech
            <span class="not-italic font-label-technical text-xs text-on-surface-variant">// HARDWARE</span></a>
        <div class="flex items-center gap-2 text-xs">
<c:if test="${canBuy}">
            <a href="${ctx}/home?cart=1"
                class="px-3 py-1.5 rounded-full bg-surface-container-high/60 hover:bg-surface-bright text-on-surface flex items-center gap-1">
                <span class="material-symbols-outlined text-[16px]">shopping_cart</span> Giỏ hàng</a>
</c:if>
            <c:choose>
                <c:when test="${not empty me}">
                    <span class="px-3 py-1.5 rounded-full bg-primary/10 border border-primary/30 text-primary font-semibold">
                        <c:out value="${me.fullName}" /></span>
                </c:when>
                <c:otherwise>
                    <a href="${ctx}/login" class="px-3 py-1.5 rounded-full bg-primary text-on-primary font-semibold">Đăng nhập</a>
                </c:otherwise>
            </c:choose>
        </div>
    </header>

    <!-- Danh sách linh kiện (ẩn) để chọn trong Build -->
    <div id="build-catalog" class="hidden">
        <c:forEach var="p" items="${products}">
            <div class="product-card" data-id="${p.productId}" data-name="<c:out value='${p.productName}'/>"
                data-sku="<c:out value='${p.sku}'/>" data-price="${p.price}"
                data-category="<c:out value='${p.category.categoryName}'/>"
                data-brand="<c:out value='${p.brand.brandName}'/>"
                data-image="<c:out value='${p.thumbnailUrl}'/>"></div>
        </c:forEach>
    </div>

    <main class="relative z-10 flex justify-center px-3 sm:px-6 pt-24 pb-16">
        <div
            class="w-full max-w-4xl bg-surface-container-lowest/95 backdrop-blur-2xl border border-surface-container-high/70 rounded-3xl shadow-2xl flex flex-col my-auto overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <!-- Modal Header -->
            <div
                class="p-6 border-b border-surface-container-high/50 flex items-center justify-between bg-surface-container-low/40">
                <div class="flex items-center gap-3">
                    <div
                        class="w-10 h-10 rounded-2xl bg-gradient-to-tr from-primary to-primary-container flex items-center justify-center text-surface-container-lowest shadow-[0_0_15px_rgba(159,208,255,0.4)]">
                        <span
                            class="material-symbols-outlined text-[22px]">precision_manufacturing</span>
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <h3
                                class="font-headline-md text-xl font-medium text-white tracking-tight">
                                Build Cấu Hình Theo Yêu Cầu</h3>
                            <span
                                class="px-2 py-0.5 rounded-full bg-primary/20 text-primary font-label-technical text-[10px] tracking-wider uppercase font-semibold">Interactive
                                Studio</span>
                        </div>
                        <p class="font-body-sm text-xs text-on-surface-variant font-light">Tự do lựa
                            chọn từng linh kiện phần cứng theo ý thích &amp; tự động kiểm tra tương
                            thích.</p>
                    </div>
                </div>
                <a href="${ctx}/home"
                    class="px-3 py-1.5 rounded-full bg-surface-container-high/60 hover:bg-surface-bright flex items-center gap-1 text-xs text-on-surface hover:text-white transition-all">
                    <span class="material-symbols-outlined text-[16px]">arrow_back</span> Trang chủ
                </a>
            </div>

            <!-- Builder Slots Container -->
            <div class="p-6 space-y-4" id="builder-slots-container">
            </div>

            <!-- Component Selection Popup Dropdown/Drawer in Builder -->
            <div id="builder-picker-modal"
                class="hidden fixed inset-0 z-[60] bg-black/80 backdrop-blur-md items-center justify-center p-4">
                <div
                    class="w-full max-w-2xl bg-surface-container rounded-2xl border border-surface-container-high p-5 shadow-2xl max-h-[80vh] flex flex-col">
                    <div
                        class="flex items-center justify-between pb-3 border-b border-surface-container-high">
                        <h4 id="picker-title" class="font-headline-sm text-base text-white">Chọn
                            Linh Kiện</h4>
                        <button id="close-picker-btn" type="button"
                            class="text-on-surface-variant hover:text-white">
                            <span class="material-symbols-outlined text-[20px]">close</span>
                        </button>
                    </div>
                    <div id="picker-list" class="overflow-y-auto flex-1 py-4 space-y-3"></div>
                </div>
            </div>

            <!-- Builder Footer & Telemetry -->
            <div
                class="p-6 border-t border-surface-container-high/60 bg-surface-container-low/70 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                <div class="flex items-center gap-6">
                    <div>
                        <div
                            class="text-[10px] font-label-technical uppercase tracking-wider text-on-surface-variant">
                            ƯỚC TÍNH NGUỒN CẦN THIẾT</div>
                        <div
                            class="flex items-center gap-1.5 text-primary font-label-technical font-semibold text-sm">
                            <span class="material-symbols-outlined text-[16px]">bolt</span>
                            <span id="builder-wattage">~450W - 650W</span>
                        </div>
                    </div>
                    <div class="h-8 w-px bg-surface-container-high/60"></div>
                    <div>
                        <div
                            class="text-[10px] font-label-technical uppercase tracking-wider text-on-surface-variant">
                            TỔNG CHI PHÍ DÀN MÁY</div>
                        <div id="builder-total-price"
                            class="text-xl sm:text-2xl font-headline-md font-bold text-white tracking-tight">
                            0₫</div>
                    </div>
                </div>

                <div class="flex items-center gap-2.5">
                    <button id="builder-reset-btn" type="button"
                        class="px-4 py-3 rounded-full bg-surface-container-high/60 hover:bg-surface-bright text-on-surface text-xs font-label-technical uppercase tracking-wider transition-all">
                        Làm Mới
                    </button>
<c:if test="${canBuy}">
                    <button id="builder-add-all-cart-btn" type="button"
                        class="px-6 py-3 rounded-full bg-gradient-to-r from-primary-container to-primary text-surface-container-lowest font-headline-sm text-xs font-bold uppercase tracking-wider shadow-[0_0_20px_rgba(159,208,255,0.4)] hover:shadow-[0_0_35px_rgba(159,208,255,0.7)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2">
                        <span class="material-symbols-outlined text-[18px]">add_shopping_cart</span>
                        <span>Thêm Toàn Bộ Vào Giỏ Hàng</span>
                    </button>
</c:if>
                </div>
            </div>
        </div>
    </main>

    <div id="toast-container"
        class="fixed bottom-6 right-6 z-[100] flex flex-col gap-2.5 pointer-events-none max-w-sm w-full px-4">
    </div>

<script src="${ctx}/assets/js/common/shop.js"></script>
<script src="${ctx}/assets/js/build/build.js"></script>
</body>

</html>
