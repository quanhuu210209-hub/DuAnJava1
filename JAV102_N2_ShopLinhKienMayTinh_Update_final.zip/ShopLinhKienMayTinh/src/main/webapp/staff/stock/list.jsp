<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tra cứu kho — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Tra cứu tồn kho và sản phẩm</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="get" action="${pageContext.request.contextPath}/staff/stock" class="filter-form">
        <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Tên hoặc SKU sản phẩm">
        <select name="categoryId">
            <option value="0">-- Tất cả danh mục --</option>
            <c:forEach var="cat" items="${categories}">
                <option value="${cat.categoryId}" ${categoryId == cat.categoryId ? 'selected' : ''}><c:out value="${cat.categoryName}"/></option>
            </c:forEach>
        </select>
        <button type="submit">Tìm</button>
    </form>
    <div class="table-card"><table>
        <thead><tr><th>Sản phẩm</th><th>SKU</th><th>Danh mục</th><th>Giá bán</th><th>Bảo hành</th><th>Tồn chi nhánh</th><th></th></tr></thead>
        <tbody>
        <c:forEach var="p" items="${products}">
            <c:set var="inv" value="${inventory[p.productId]}"/>
            <tr>
                <td><c:out value="${p.productName}"/></td>
                <td><c:out value="${p.sku}"/></td>
                <td><c:out value="${p.category.categoryName}"/></td>
                <td><t:money value="${p.price}"/></td>
                <td>${p.warrantyMonths} tháng</td>
                <td>
                    <c:choose>
                        <c:when test="${empty inv}">—</c:when>
                        <c:when test="${inv.hidden}">Ẩn tại chi nhánh</c:when>
                        <c:when test="${inv.quantity <= 0}"><span class="badge-out">Hết hàng</span></c:when>
                        <c:when test="${inv.quantity <= inv.lowStockThreshold}"><span class="badge-low">${inv.quantity} (sắp hết)</span></c:when>
                        <c:otherwise>${inv.quantity}</c:otherwise>
                    </c:choose>
                </td>
                <td><a href="${pageContext.request.contextPath}/staff/stock?action=detail&id=${p.productId}" class="btn-xs ghost">Chi tiết</a></td>
            </tr>
        </c:forEach>
        <c:if test="${empty products}"><tr><td colspan="7">Không tìm thấy sản phẩm.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
