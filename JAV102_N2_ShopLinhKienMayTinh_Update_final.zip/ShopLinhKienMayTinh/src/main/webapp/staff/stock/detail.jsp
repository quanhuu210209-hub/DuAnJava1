<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chi tiết sản phẩm — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1><c:out value="${product.productName}"/></h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <p><a href="${pageContext.request.contextPath}/staff/stock">&larr; Tra cứu sản phẩm</a></p>
    <c:if test="${not empty product.thumbnailUrl}"><img src="<c:out value='${product.thumbnailUrl}'/>" alt="" class="stock-thumb"></c:if>
    <div class="table-card"><table>
        <tr><th>SKU</th><td><c:out value="${product.sku}"/></td></tr>
        <tr><th>Danh mục</th><td><c:out value="${product.category.categoryName}"/></td></tr>
        <tr><th>Thương hiệu</th><td><c:out value="${product.brand.brandName}"/></td></tr>
        <tr><th>Giá bán</th><td><t:money value="${product.price}"/></td></tr>
        <tr><th>Chính sách bảo hành</th><td>${product.warrantyMonths} tháng</td></tr>
        <tr><th>Mô tả</th><td><c:out value="${product.description}"/></td></tr>
        <tr><th>Tồn tại chi nhánh của bạn</th><td>
            <c:choose>
                <c:when test="${empty mine}">Chưa có dữ liệu tồn kho</c:when>
                <c:when test="${mine.hidden}">Đang ẩn tại chi nhánh</c:when>
                <c:otherwise>${mine.quantity} (cảnh báo khi còn ≤ ${mine.lowStockThreshold})</c:otherwise>
            </c:choose>
        </td></tr>
    </table></div>

    <h2>Thông số kỹ thuật</h2>
    <div class="table-card"><table>
        <c:forEach var="sp" items="${product.specs}">
            <tr><th><c:out value="${sp.specName}"/></th><td><c:out value="${sp.specValue}"/></td></tr>
        </c:forEach>
        <c:if test="${empty product.specs}"><tr><td>Chưa có thông số.</td></tr></c:if>
    </table></div>

    <h2>Tồn kho các chi nhánh</h2>
    <div class="table-card"><table>
        <thead><tr><th>Chi nhánh</th><th>Số lượng</th></tr></thead>
        <tbody>
        <c:forEach var="b" items="${branches}">
            <tr><td><c:out value="${b.branch.branchName}"/></td><td>${b.quantity}</td></tr>
        </c:forEach>
        <c:if test="${empty branches}"><tr><td colspan="2">Chưa có chi nhánh nào bán sản phẩm này.</td></tr></c:if>
        </tbody>
    </table></div>

    <c:if test="${canAdjust}">
      <h2>Điều chỉnh tồn kho</h2>
      <form method="post" action="${pageContext.request.contextPath}/staff/stock" data-validate>
        <input type="hidden" name="action" value="adjust">
        <input type="hidden" name="productId" value="${product.productId}">
        <div class="form-row">
          <label for="quantity">Số lượng thực tế (hiện tại: ${mine.quantity}) *</label>
          <input id="quantity" name="quantity" type="number" min="0" required data-label="Số lượng thực tế" data-type="int" data-min="0">
          <span class="field-error" data-for="quantity"></span>
        </div>
        <div class="form-row">
          <label for="reason">Lý do điều chỉnh *</label>
          <input id="reason" name="reason" type="text" required maxlength="255" data-label="Lý do điều chỉnh">
          <span class="field-error" data-for="reason"></span>
        </div>
        <button type="submit">Lưu điều chỉnh</button>
      </form>
    </c:if>

    <h2>Lịch sử xuất nhập gần đây</h2>
    <div class="table-card"><table>
        <thead><tr><th>Thời gian</th><th>Loại</th><th>Thay đổi</th><th>Ghi chú</th><th>Người thực hiện</th></tr></thead>
        <tbody>
        <c:forEach var="m" items="${movements}">
            <tr>
                <td><t:dt value="${m.createdAt}"/></td>
                <td><c:out value="${m.movementType}"/></td>
                <td class="${m.quantityChange > 0 ? 'mv-in' : 'mv-out'}">${m.quantityChange > 0 ? '+' : ''}${m.quantityChange}</td>
                <td><c:out value="${m.note}"/></td>
                <td><c:out value="${m.createdBy.fullName}"/></td>
            </tr>
        </c:forEach>
        <c:if test="${empty movements}"><tr><td colspan="5">Chưa có biến động kho.</td></tr></c:if>
        </tbody>
    </table></div>
    <p><a href="${pageContext.request.contextPath}/staff/movement">Xem toàn bộ lịch sử kho &rarr;</a></p>
    <p class="hint">Nhân viên chỉ được xem; chỉ quản lý chi nhánh mới điều chỉnh được số lượng tồn.</p>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>
