<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>

<aside class="sidebar">
  <div class="sidebar-logo-badge">
    <span class="logo-badge-box">CT</span>
    <span class="logo-badge-text">CoreTech</span>
    <span class="sidebar-role-tag">Nhân viên</span>
  </div>

  <nav class="sidebar-menu">

    <div class="menu-group">Bán hàng</div>
    <a href="${pageContext.request.contextPath}/staff/pos" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/staff/pos/') ? 'active' : ''}"><span class="icon">🛒</span> Bán tại quầy</a>
    <a href="${pageContext.request.contextPath}/staff/order" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/staff/order/') ? 'active' : ''}"><span class="icon">📋</span> Đơn hàng</a>
    <a href="${pageContext.request.contextPath}/staff/invoice" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/staff/invoice/') ? 'active' : ''}"><span class="icon">🧾</span> Hóa đơn</a>

    <div class="menu-group">Kho &amp; hỗ trợ</div>
    <a href="${pageContext.request.contextPath}/staff/stock" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/staff/stock/') ? 'active' : ''}"><span class="icon">📦</span> Tra cứu kho</a>
    <a href="${pageContext.request.contextPath}/staff/movement" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/staff/movement/') ? 'active' : ''}"><span class="icon">📜</span> Lịch sử kho</a>
    <a href="${pageContext.request.contextPath}/staff/warranty" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/staff/warranty/') ? 'active' : ''}"><span class="icon">🛠</span> Bảo hành / đổi trả</a>

    <div class="menu-group">Khách hàng</div>
    <a href="${pageContext.request.contextPath}/staff/customer" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/staff/customer/') ? 'active' : ''}"><span class="icon">👤</span> Khách hàng</a>
    <a href="${pageContext.request.contextPath}/staff/notification" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/staff/notification/') ? 'active' : ''}"><span class="icon">🔔</span> Thông báo</a>
  </nav>

  <div class="sidebar-footer-card">
    <div class="footer-card-identity">
      <span class="footer-card-avatar">${fn:toUpperCase(fn:substring(sessionScope.loginUser.fullName, 0, 1))}</span>
      <div class="footer-card-text">
        <div class="footer-card-name"><c:out value="${sessionScope.loginUser.fullName}"/></div>
        <span class="footer-card-tag">${sessionScope.loginUser.roleCode}</span>
      </div>
    </div>
    <div class="footer-card-divider"></div>
    <div class="footer-card-actions">
      <a href="${pageContext.request.contextPath}/home" class="btn-xs ghost">⬡ Về trang chủ</a>
      <a href="${pageContext.request.contextPath}/logout" class="btn-xs ghost">↩ Đăng xuất</a>
    </div>
  </div>
</aside>
