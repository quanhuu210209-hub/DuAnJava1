<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tiếp nhận bảo hành — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Tiếp nhận bảo hành / đổi trả</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <p><a href="${pageContext.request.contextPath}/staff/warranty">&larr; Danh sách yêu cầu</a></p>
    <h2>Bước 1: Tra cứu hóa đơn</h2>
    <form method="get" action="${pageContext.request.contextPath}/staff/warranty" class="filter-form">
        <input type="hidden" name="action" value="form">
        <input type="text" name="key" value="<c:out value='${key}'/>" placeholder="Số hóa đơn hoặc mã đơn hàng" required>
        <button type="submit">Tra cứu</button>
    </form>
    <c:if test="${notFound}"><div class="alert alert-danger">Không tìm thấy hóa đơn hoặc đơn hàng này.</div></c:if>

    <c:if test="${not empty order}">
    <h2>Bước 2: Chọn sản phẩm và ghi nhận lý do</h2>
    <div class="table-card"><table>
        <tr><th>Mã đơn</th><td><c:out value="${order.orderCode}"/> (<t:orderStatus value="${order.status}"/>)</td></tr>
        <tr><th>Khách hàng</th><td><c:out value="${order.customer.fullName}"/> - <c:out value="${order.customer.phone}"/></td></tr>
    </table></div>

    <form method="post" action="${pageContext.request.contextPath}/staff/warranty" data-validate>
        <input type="hidden" name="key" value="<c:out value='${key}'/>">
        <div class="table-card"><table>
            <thead><tr><th></th><th>Sản phẩm</th><th>Đã mua</th><th>Hạn bảo hành</th><th>Còn yêu cầu được</th></tr></thead>
            <tbody>
            <c:forEach var="row" items="${rows}">
                <tr>
                    <td><input type="radio" name="orderDetailId" value="${row[0].orderDetailId}" ${row[2] <= 0 ? 'disabled' : ''}></td>
                    <td><c:out value="${row[0].product.productName}"/></td>
                    <td>${row[0].quantity}</td>
                    <td><t:dt value="${row[1]}"/></td>
                    <td>${row[2]}</td>
                </tr>
            </c:forEach>
            </tbody>
        </table></div>
        <div class="form-row">
            <label for="requestType">Loại yêu cầu *</label>
            <select id="requestType" name="requestType" required>
                <c:forEach var="ty" items="${types}"><option value="${ty.key}"><c:out value="${ty.value}"/></option></c:forEach>
            </select>
        </div>
        <div class="form-row">
            <label for="quantity">Số lượng *</label>
            <input id="quantity" name="quantity" type="number" min="1" value="1" required data-label="Số lượng">
        </div>
        <div class="form-row">
            <label for="reason">Lý do / tình trạng sản phẩm *</label>
            <input id="reason" name="reason" type="text" required maxlength="1000" data-label="Lý do">
            <span class="field-error" data-for="reason"></span>
        </div>
        <button type="submit" class="btn-solid">Tiếp nhận và chuyển quản lý</button>
    </form>
    </c:if>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>
