<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bảo hành / đổi trả — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Bảo hành và đổi trả</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header">
      <form method="get" action="${pageContext.request.contextPath}/staff/warranty" class="filter-form">
        <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Mã yêu cầu hoặc SĐT khách">
        <input type="text" name="status" value="<c:out value='${status}'/>" placeholder="Trạng thái (để trống = tất cả)">
        <button type="submit">Lọc</button>
      </form>
      <a href="${pageContext.request.contextPath}/staff/warranty?action=form" class="btn-solid">+ Tiếp nhận yêu cầu</a>
    </div>
    <div class="table-card"><table>
        <thead><tr><th>Mã yêu cầu</th><th>Khách hàng</th><th>Sản phẩm</th><th>Loại</th><th>SL</th><th>Trạng thái</th><th>Ngày tạo</th><th></th></tr></thead>
        <tbody>
        <c:forEach var="w" items="${requests}">
            <tr>
                <td><c:out value="${w.requestCode}"/></td>
                <td><c:out value="${w.customer.fullName}"/><br><small><c:out value="${w.customer.phone}"/></small></td>
                <td><c:out value="${w.orderDetail.product.productName}"/></td>
                <td><c:out value="${empty types[w.requestType] ? w.requestType : types[w.requestType]}"/></td>
                <td>${w.quantity}</td>
                <td><c:out value="${w.status}"/></td>
                <td><t:dt value="${w.createdAt}"/></td>
                <td><a href="${pageContext.request.contextPath}/staff/warranty?action=detail&id=${w.requestId}" class="btn-xs ghost">Chi tiết</a></td>
            </tr>
        </c:forEach>
        <c:if test="${empty requests}"><tr><td colspan="8">Chưa có yêu cầu nào.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
