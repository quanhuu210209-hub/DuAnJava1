<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chi tiết yêu cầu — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Yêu cầu <c:out value="${request.requestCode}"/></h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <p><a href="${pageContext.request.contextPath}/staff/warranty">&larr; Danh sách yêu cầu</a></p>
    <div class="table-card"><table>
        <tr><th>Trạng thái</th><td><c:out value="${request.status}"/></td></tr>
        <tr><th>Loại yêu cầu</th><td><c:out value="${empty types[request.requestType] ? request.requestType : types[request.requestType]}"/></td></tr>
        <tr><th>Khách hàng</th><td><c:out value="${request.customer.fullName}"/> - <c:out value="${request.customer.phone}"/></td></tr>
        <tr><th>Sản phẩm</th><td><c:out value="${request.orderDetail.product.productName}"/> (SL: ${request.quantity})</td></tr>
        <tr><th>Chi nhánh</th><td><c:out value="${request.branch.branchName}"/></td></tr>
        <tr><th>Lý do</th><td><c:out value="${request.reason}"/></td></tr>
        <tr><th>Nhân viên tiếp nhận</th><td><c:out value="${request.receivedBy.fullName}"/></td></tr>
        <c:if test="${not empty request.handledBy}"><tr><th>Người xử lý</th><td><c:out value="${request.handledBy.fullName}"/></td></tr></c:if>
        <tr><th>Ngày tiếp nhận</th><td><t:dt value="${request.createdAt}"/></td></tr>
        <tr><th>Kết quả xử lý</th><td><c:out value="${empty request.resolutionNote ? 'Chờ quản lý chi nhánh xử lý' : request.resolutionNote}"/></td></tr>
        <c:if test="${request.refundApproved}"><tr><th>Hoàn tiền</th><td><t:money value="${request.refundAmount}"/></td></tr></c:if>
    </table></div>

    <c:set var="canHandle" value="${sessionScope.loginUser.roleCode == 'ADMIN' or (sessionScope.loginUser.roleCode == 'MANAGER' and sessionScope.loginUser.branchId == request.branch.branchId)}"/>
    <c:if test="${canHandle and (request.status == 'Pending' or request.status == 'Processing')}">
        <h2>Xử lý yêu cầu</h2>

        <c:if test="${request.status == 'Pending'}">
            <form method="post" action="${pageContext.request.contextPath}/staff/warranty-handle" class="inline">
                <input type="hidden" name="action" value="approve">
                <input type="hidden" name="id" value="${request.requestId}">
                <button type="submit">Duyệt yêu cầu</button>
            </form>
        </c:if>

        <c:if test="${request.status == 'Processing'}">
            <form method="post" action="${pageContext.request.contextPath}/staff/warranty-handle" data-validate>
                <input type="hidden" name="action" value="complete">
                <input type="hidden" name="id" value="${request.requestId}">
                <div class="form-row">
                    <label for="noteDone">Kết quả xử lý</label>
                    <input id="noteDone" name="note" type="text" maxlength="1000" data-label="Kết quả xử lý">
                    <span class="field-error" data-for="note"></span>
                </div>
                <button type="submit">Hoàn tất xử lý</button>
            </form>

            <c:if test="${request.requestType == 'Return' and not request.refundApproved}">
                <h2>Hoàn tiền</h2>
                <form method="post" action="${pageContext.request.contextPath}/staff/warranty-handle" data-validate onsubmit="return confirm('Duyệt hoàn tiền và nhập lại hàng vào kho?');">
                    <input type="hidden" name="action" value="refund">
                    <input type="hidden" name="id" value="${request.requestId}">
                    <div class="form-row">
                        <label for="amount">Số tiền hoàn (tối đa <t:money value="${request.orderDetail.unitPrice * request.quantity}"/>) *</label>
                        <input id="amount" name="amount" type="number" min="0" required value="${request.orderDetail.unitPrice * request.quantity}" data-label="Số tiền hoàn">
                        <span class="field-error" data-for="amount"></span>
                    </div>
                    <div class="form-row">
                        <label for="noteRefund">Ghi chú</label>
                        <input id="noteRefund" name="note" type="text" maxlength="1000" data-label="Ghi chú">
                    </div>
                    <button type="submit">Duyệt hoàn tiền</button>
                </form>
            </c:if>
        </c:if>

        <h2>Từ chối</h2>
        <form method="post" action="${pageContext.request.contextPath}/staff/warranty-handle" data-validate onsubmit="return confirm('Từ chối yêu cầu này?');">
            <input type="hidden" name="action" value="reject">
            <input type="hidden" name="id" value="${request.requestId}">
            <div class="form-row">
                <label for="noteReject">Lý do từ chối *</label>
                <input id="noteReject" name="note" type="text" required maxlength="1000" data-label="Lý do từ chối">
                <span class="field-error" data-for="note"></span>
            </div>
            <button type="submit">Từ chối</button>
        </form>
    </c:if>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>
