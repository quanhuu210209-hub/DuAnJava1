<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Lịch sử kho — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Lịch sử xuất nhập kho</h1>
    </div>
  </div>

  <div class="content">
    <form method="get" action="${pageContext.request.contextPath}/staff/movement" class="filter-form">
        <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Tên hoặc SKU sản phẩm">
        <select name="type">
            <option value="">-- Tất cả loại --</option>
            <c:forEach var="e" items="${types}">
                <option value="${e.key}" ${type == e.key ? 'selected' : ''}><c:out value="${e.value}"/></option>
            </c:forEach>
        </select>
        <button type="submit">Lọc</button>
    </form>
    <div class="table-card"><table>
        <thead><tr><th>Thời gian</th><th>Chi nhánh</th><th>Sản phẩm</th><th>Loại</th><th>Thay đổi</th><th>Tham chiếu</th><th>Ghi chú</th><th>Người thực hiện</th></tr></thead>
        <tbody>
        <c:forEach var="m" items="${movements}">
            <tr>
                <td><t:dt value="${m.createdAt}"/></td>
                <td><c:out value="${m.branch.branchName}"/></td>
                <td><c:out value="${m.product.productName}"/><br><small><c:out value="${m.product.sku}"/></small></td>
                <td><c:out value="${empty types[m.movementType] ? m.movementType : types[m.movementType]}"/></td>
                <td class="${m.quantityChange > 0 ? 'mv-in' : 'mv-out'}">${m.quantityChange > 0 ? '+' : ''}${m.quantityChange}</td>
                <td><c:if test="${not empty m.refType}"><c:out value="${m.refType}"/> #${m.refId}</c:if></td>
                <td><c:out value="${m.note}"/></td>
                <td><c:out value="${m.createdBy.fullName}"/></td>
            </tr>
        </c:forEach>
        <c:if test="${empty movements}"><tr><td colspan="8">Chưa có biến động kho nào.</td></tr></c:if>
        </tbody>
    </table></div>
    <p class="hint">Hiển thị tối đa 200 dòng gần nhất.</p>
  </div>
</div>
</body>
</html>
