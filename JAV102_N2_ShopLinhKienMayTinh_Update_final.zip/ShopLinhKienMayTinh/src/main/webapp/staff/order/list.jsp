<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Đơn hàng — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Quản lý đơn hàng</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="get" action="${pageContext.request.contextPath}/staff/order" class="filter-form">
        <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Mã đơn hoặc SĐT">
        <select name="channel">
            <option value="">-- Tất cả kênh --</option>
            <option value="online" ${channel == 'online' ? 'selected' : ''}>Đơn online</option>
            <option value="offline" ${channel == 'offline' ? 'selected' : ''}>Bán tại quầy</option>
        </select>
        <select name="status">
            <option value="">-- Tất cả trạng thái --</option>
            <option value="Pending" ${status == 'Pending' ? 'selected' : ''}>Chờ xử lý</option>
            <option value="Paid" ${status == 'Paid' ? 'selected' : ''}>Đã thanh toán</option>
            <option value="Shipping" ${status == 'Shipping' ? 'selected' : ''}>Đang giao</option>
            <option value="Completed" ${status == 'Completed' ? 'selected' : ''}>Hoàn tất</option>
            <option value="Cancelled" ${status == 'Cancelled' ? 'selected' : ''}>Đã hủy</option>
        </select>
        <button type="submit">Lọc</button>
    </form>
    <div class="table-card"><table>
        <thead><tr><th>Mã đơn</th><th>Kênh</th><th>Người nhận</th><th>Chi nhánh</th><th>Tổng tiền</th><th>Trạng thái</th><th>Thanh toán</th><th>Ngày tạo</th><th></th></tr></thead>
        <tbody>
        <c:forEach var="o" items="${orders}">
            <tr>
                <td><c:out value="${o.orderCode}"/></td>
                <td><c:out value="${o.channel}"/></td>
                <td><c:out value="${o.receiverName}"/></td>
                <td><c:out value="${o.branch.branchName}"/></td>
                <td><t:money value="${o.totalAmount}"/></td>
                <td><t:orderStatus value="${o.status}"/></td>
                <td><c:out value="${o.paymentStatus}"/></td>
                <td><t:dt value="${o.createdAt}"/></td>
                <td><a href="${pageContext.request.contextPath}/staff/order?action=detail&id=${o.orderId}" class="btn-xs ghost">Chi tiết</a></td>
            </tr>
        </c:forEach>
        <c:if test="${empty orders}"><tr><td colspan="9">Không có đơn hàng.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
