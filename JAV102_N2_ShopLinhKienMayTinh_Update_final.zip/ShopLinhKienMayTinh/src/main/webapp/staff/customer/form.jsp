<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tạo khách hàng — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Tạo khách hàng tại quầy</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <p><a href="${pageContext.request.contextPath}/staff/customer">&larr; Danh sách khách hàng</a></p>
    <form method="post" action="${pageContext.request.contextPath}/staff/customer" data-validate>
        <div class="form-row">
            <label for="fullName">Họ tên *</label>
            <input id="fullName" name="fullName" type="text" required maxlength="100" data-label="Họ tên" value="<c:out value='${fullName}'/>">
            <span class="field-error" data-for="fullName"><c:out value="${errors.fullName}"/></span>
        </div>
        <div class="form-row">
            <label for="phone">Số điện thoại *</label>
            <input id="phone" name="phone" type="text" required maxlength="20" data-label="Số điện thoại" value="<c:out value='${phone}'/>">
            <span class="field-error" data-for="phone"><c:out value="${errors.phone}"/></span>
        </div>
        <div class="form-row">
            <label for="email">Email</label>
            <input id="email" name="email" type="email" maxlength="150" data-label="Email" value="<c:out value='${email}'/>">
            <span class="field-error" data-for="email"><c:out value="${errors.email}"/></span>
        </div>
        <button type="submit" class="btn-solid">Lưu khách hàng</button>
        <a href="${pageContext.request.contextPath}/staff/customer" class="btn-xs ghost">Hủy</a>
    </form>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>
