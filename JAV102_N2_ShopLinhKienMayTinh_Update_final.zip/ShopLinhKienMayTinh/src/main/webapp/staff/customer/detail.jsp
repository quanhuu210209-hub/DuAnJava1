<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chi tiết khách hàng — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Khách hàng: <c:out value="${customer.fullName}"/></h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <p><a href="${pageContext.request.contextPath}/staff/customer">&larr; Danh sách khách hàng</a></p>
    <div class="table-card"><table>
        <tr><th>Họ tên</th><td><c:out value="${customer.fullName}"/></td></tr>
        <tr><th>Số điện thoại</th><td><c:out value="${customer.phone}"/></td></tr>
        <tr><th>Email</th><td><c:out value="${customer.email}"/></td></tr>
        <tr><th>Tài khoản website</th><td>${empty customer.user ? 'Chưa có (khách mua tại quầy)' : 'Có'}</td></tr>
        <tr><th>Ngày tạo</th><td><t:dt value="${customer.createdAt}"/></td></tr>
    </table></div>
    <form method="post" action="${pageContext.request.contextPath}/staff/pos" class="inline">
        <input type="hidden" name="action" value="customer">
        <input type="hidden" name="customerId" value="${customer.customerId}">
        <button type="submit" class="btn-solid">Bán hàng cho khách này</button>
    </form>

    <h2>Lịch sử mua hàng</h2>
    <div class="table-card"><table>
        <thead><tr><th>Mã đơn</th><th>Kênh</th><th>Chi nhánh</th><th>Tổng tiền</th><th>Trạng thái</th><th>Ngày tạo</th><th></th></tr></thead>
        <tbody>
        <c:forEach var="o" items="${orders}">
            <tr>
                <td><c:out value="${o.orderCode}"/></td>
                <td><c:out value="${o.channel}"/></td>
                <td><c:out value="${o.branch.branchName}"/></td>
                <td><t:money value="${o.totalAmount}"/></td>
                <td><t:orderStatus value="${o.status}"/></td>
                <td><t:dt value="${o.createdAt}"/></td>
                <td><a href="${pageContext.request.contextPath}/staff/order?action=detail&id=${o.orderId}" class="btn-xs ghost">Xem</a></td>
            </tr>
        </c:forEach>
        <c:if test="${empty orders}"><tr><td colspan="7">Khách chưa có đơn hàng nào.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
