<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Khách hàng — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Khách hàng tại quầy</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header">
      <form method="get" action="${pageContext.request.contextPath}/staff/customer" class="filter-form">
        <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Số điện thoại hoặc họ tên">
        <button type="submit">Tìm</button>
      </form>
      <a href="${pageContext.request.contextPath}/staff/customer?action=form" class="btn-solid">+ Tạo khách hàng</a>
    </div>
    <div class="table-card"><table>
        <thead><tr><th>Họ tên</th><th>Số điện thoại</th><th>Email</th><th>Tài khoản website</th><th>Ngày tạo</th><th></th></tr></thead>
        <tbody>
        <c:forEach var="c" items="${customers}">
            <tr>
                <td><c:out value="${c.fullName}"/></td>
                <td><c:out value="${c.phone}"/></td>
                <td><c:out value="${c.email}"/></td>
                <td>${empty c.user ? 'Không' : 'Có'}</td>
                <td><t:dt value="${c.createdAt}"/></td>
                <td>
                    <a href="${pageContext.request.contextPath}/staff/customer?action=detail&id=${c.customerId}" class="btn-xs ghost">Chi tiết</a>
                    <form method="post" action="${pageContext.request.contextPath}/staff/pos" class="inline">
                        <input type="hidden" name="action" value="customer">
                        <input type="hidden" name="customerId" value="${c.customerId}">
                        <button type="submit" class="btn-xs ghost">Bán hàng</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty customers}"><tr><td colspan="6">Không tìm thấy khách hàng.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
