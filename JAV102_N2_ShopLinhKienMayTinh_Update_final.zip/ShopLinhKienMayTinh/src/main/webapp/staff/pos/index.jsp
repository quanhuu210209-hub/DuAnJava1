<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bán hàng tại quầy — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff-pos.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Bán hàng tại quầy</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="pos-grid">
      <section>
        <h2>Tìm sản phẩm</h2>
        <form method="get" action="${pageContext.request.contextPath}/staff/pos" class="filter-form">
            <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Tên hoặc SKU sản phẩm">
            <button type="submit">Tìm</button>
        </form>
        <c:if test="${not empty q}">
        <div class="table-card"><table>
            <thead><tr><th>Sản phẩm</th><th>Giá</th><th>Tồn</th><th></th></tr></thead>
            <tbody>
            <c:forEach var="p" items="${products}">
                <c:set var="have" value="${empty stock[p.productId] ? 0 : stock[p.productId]}"/>
                <tr>
                    <td><c:out value="${p.productName}"/><br><small><c:out value="${p.sku}"/></small></td>
                    <td><t:money value="${p.price}"/></td>
                    <td>${have}</td>
                    <td>
                        <c:if test="${have > 0}">
                        <form method="post" action="${pageContext.request.contextPath}/staff/pos" class="inline">
                            <input type="hidden" name="action" value="add">
                            <input type="hidden" name="productId" value="${p.productId}">
                            <input type="hidden" name="q" value="<c:out value='${q}'/>">
                            <input type="number" name="qty" value="1" min="1" max="${have}" class="pos-qty">
                            <button type="submit" class="btn-xs ghost">Thêm</button>
                        </form>
                        </c:if>
                        <c:if test="${have <= 0}"><span class="pos-out">Hết hàng</span></c:if>
                    </td>
                </tr>
            </c:forEach>
            <c:if test="${empty products}"><tr><td colspan="4">Không tìm thấy sản phẩm.</td></tr></c:if>
            </tbody>
        </table></div>
        </c:if>
      </section>

      <aside>
        <div class="pos-card">
          <h2>Khách hàng</h2>
          <c:choose>
            <c:when test="${not empty customer}">
              <p><strong><c:out value="${customer.fullName}"/></strong><br><c:out value="${customer.phone}"/></p>
              <form method="post" action="${pageContext.request.contextPath}/staff/pos" class="inline">
                  <input type="hidden" name="action" value="noCustomer">
                  <button type="submit" class="btn-xs ghost">Đổi khách</button>
              </form>
            </c:when>
            <c:otherwise>
              <form method="get" action="${pageContext.request.contextPath}/staff/pos" class="filter-form">
                  <input type="text" name="cq" value="<c:out value='${cq}'/>" placeholder="SĐT hoặc họ tên khách">
                  <button type="submit">Tìm</button>
              </form>
              <c:forEach var="c" items="${customers}">
                  <form method="post" action="${pageContext.request.contextPath}/staff/pos" class="pos-pick">
                      <input type="hidden" name="action" value="customer">
                      <input type="hidden" name="customerId" value="${c.customerId}">
                      <span><c:out value="${c.fullName}"/> - <c:out value="${c.phone}"/></span>
                      <button type="submit" class="btn-xs ghost">Chọn</button>
                  </form>
              </c:forEach>
              <c:if test="${not empty cq and empty customers}"><p>Không tìm thấy khách.</p></c:if>
              <a href="${pageContext.request.contextPath}/staff/customer?action=form" class="btn-xs ghost">+ Tạo khách mới</a>
            </c:otherwise>
          </c:choose>
        </div>

        <div class="pos-card">
          <h2>Giỏ hàng</h2>
          <c:if test="${empty lines}"><p>Chưa có sản phẩm.</p></c:if>
          <c:forEach var="l" items="${lines}">
              <div class="pos-line">
                  <div><c:out value="${l.product.productName}"/><br><small><t:money value="${l.product.price}"/></small></div>
                  <form method="post" action="${pageContext.request.contextPath}/staff/pos" class="inline">
                      <input type="hidden" name="action" value="qty">
                      <input type="hidden" name="productId" value="${l.product.productId}">
                      <input type="number" name="qty" value="${l.quantity}" min="0" max="99" class="pos-qty">
                      <button type="submit" class="btn-xs ghost">Sửa</button>
                  </form>
                  <strong><t:money value="${l.lineTotal}"/></strong>
                  <form method="post" action="${pageContext.request.contextPath}/staff/pos" class="inline">
                      <input type="hidden" name="action" value="remove">
                      <input type="hidden" name="productId" value="${l.product.productId}">
                      <button type="submit" class="btn-xs danger">Xóa</button>
                  </form>
              </div>
          </c:forEach>
          <div class="pos-total"><span>Tổng cộng</span><strong><t:money value="${total}"/></strong></div>

          <c:if test="${not empty lines}">
          <form method="post" action="${pageContext.request.contextPath}/staff/pos">
              <input type="hidden" name="action" value="pay">
              <div class="form-row">
                  <label for="paymentMethodId">Phương thức thanh toán</label>
                  <select id="paymentMethodId" name="paymentMethodId" required>
                      <c:forEach var="m" items="${methods}"><option value="${m.paymentMethodId}"><c:out value="${m.methodName}"/></option></c:forEach>
                  </select>
              </div>
              <button type="submit" class="btn-solid" onclick="return confirm('Xác nhận thanh toán và xuất hóa đơn?');">Thanh toán</button>
          </form>
          <form method="post" action="${pageContext.request.contextPath}/staff/pos" class="inline">
              <input type="hidden" name="action" value="clear">
              <button type="submit" class="btn-xs ghost">Hủy giỏ</button>
          </form>
          </c:if>
        </div>
      </aside>
    </div>
  </div>
</div>
</body>
</html>
