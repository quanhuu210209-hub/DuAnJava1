<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Thông báo — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Thông báo</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <c:if test="${not empty pendingOnline and pendingOnline > 0}">
      <div class="alert alert-info">Có <strong>${pendingOnline}</strong> đơn online đang chờ xử lý tại chi nhánh.
        <a href="${pageContext.request.contextPath}/staff/order?channel=online">Xem đơn online</a></div>
    </c:if>

    <c:if test="${not empty lowStock}">
      <h2>Sản phẩm sắp hết hàng tại chi nhánh</h2>
      <div class="table-card"><table>
        <thead><tr><th>Sản phẩm</th><th>Còn lại</th><th>Ngưỡng cảnh báo</th><th></th></tr></thead>
        <tbody>
        <c:forEach var="i" items="${lowStock}">
          <tr>
            <td><c:out value="${i.product.productName}"/></td>
            <td><span class="${i.quantity <= 0 ? 'badge-out' : 'badge-low'}">${i.quantity}</span></td>
            <td>${i.lowStockThreshold}</td>
            <td><a href="${pageContext.request.contextPath}/staff/stock?action=detail&id=${i.product.productId}" class="btn-xs ghost">Xem</a></td>
          </tr>
        </c:forEach>
        </tbody>
      </table></div>
    </c:if>

    <div class="page-header">
      <h2>Thông báo của tôi (${unread} chưa đọc)</h2>
      <form method="post" action="${pageContext.request.contextPath}/staff/notification" class="inline">
        <input type="hidden" name="action" value="readAll">
        <button type="submit" class="btn-xs ghost">Đánh dấu đã đọc tất cả</button>
      </form>
    </div>
    <c:forEach var="n" items="${notifications}">
      <div class="noti-item ${n.read ? '' : 'noti-unread'}">
        <div>
          <strong><c:out value="${n.title}"/></strong>
          <p><c:out value="${n.content}"/></p>
          <small><t:dt value="${n.createdAt}"/></small>
          <c:set var="ref" value="${fn:toLowerCase(n.refType)}"/>
          <c:if test="${not empty n.refId and ref == 'order'}"><a href="${pageContext.request.contextPath}/staff/order?action=detail&id=${n.refId}" class="btn-xs ghost">Xem đơn</a></c:if>
          <c:if test="${not empty n.refId and ref == 'warranty'}"><a href="${pageContext.request.contextPath}/staff/warranty?action=detail&id=${n.refId}" class="btn-xs ghost">Xem yêu cầu</a></c:if>
          <c:if test="${not empty n.refId and ref == 'product'}"><a href="${pageContext.request.contextPath}/staff/stock?action=detail&id=${n.refId}" class="btn-xs ghost">Xem sản phẩm</a></c:if>
        </div>
        <c:if test="${not n.read}">
          <form method="post" action="${pageContext.request.contextPath}/staff/notification" class="inline">
            <input type="hidden" name="id" value="${n.notificationId}">
            <button type="submit" class="btn-xs ghost">Đã đọc</button>
          </form>
        </c:if>
      </div>
    </c:forEach>
    <c:if test="${empty notifications}"><p>Chưa có thông báo nào.</p></c:if>
  </div>
</div>
</body>
</html>
