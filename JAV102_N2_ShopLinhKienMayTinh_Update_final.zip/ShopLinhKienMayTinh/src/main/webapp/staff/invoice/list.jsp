<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hóa đơn — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Hóa đơn bán hàng</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="get" action="${pageContext.request.contextPath}/staff/invoice" class="filter-form">
        <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Số hóa đơn, mã đơn hoặc SĐT khách">
        <button type="submit">Tìm</button>
    </form>
    <div class="table-card"><table>
        <thead><tr><th>Số hóa đơn</th><th>Mã đơn</th><th>Khách hàng</th><th>Chi nhánh</th><th>Tổng tiền</th><th>Ngày xuất</th><th>Đã in</th><th></th></tr></thead>
        <tbody>
        <c:forEach var="i" items="${invoices}">
            <tr>
                <td><c:out value="${i.invoiceNo}"/></td>
                <td><c:out value="${i.salesOrder.orderCode}"/></td>
                <td><c:out value="${i.salesOrder.customer.fullName}"/></td>
                <td><c:out value="${i.salesOrder.branch.branchName}"/></td>
                <td><t:money value="${i.salesOrder.totalAmount}"/></td>
                <td><t:dt value="${i.issuedAt}"/></td>
                <td>${i.printCount} lần</td>
                <td><a href="${pageContext.request.contextPath}/staff/invoice?action=print&id=${i.invoiceId}" class="btn-xs ghost" target="_blank">In</a></td>
            </tr>
        </c:forEach>
        <c:if test="${empty invoices}"><tr><td colspan="8">Chưa có hóa đơn nào.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
