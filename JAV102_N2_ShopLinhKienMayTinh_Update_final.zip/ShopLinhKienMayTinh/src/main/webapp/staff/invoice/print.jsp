<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hóa đơn <c:out value="${invoice.invoiceNo}"/> — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/invoice-print.css">
</head>
<body>
<div class="invoice-page">
  <div class="no-print invoice-actions">
    <button type="button" onclick="window.print()">In hóa đơn</button>
    <a href="${pageContext.request.contextPath}/staff/invoice">&larr; Danh sách hóa đơn</a>
  </div>

  <header class="invoice-head">
    <h1>CORETECH</h1>
    <p><c:out value="${invoice.salesOrder.branch.branchName}"/></p>
    <p><c:out value="${invoice.salesOrder.branch.address}"/> &middot; <c:out value="${invoice.salesOrder.branch.phone}"/></p>
  </header>

  <h2 class="invoice-title">HÓA ĐƠN BÁN HÀNG</h2>
  <p class="invoice-copy">
    <c:choose>
      <c:when test="${invoice.printCount <= 1}">Bản gốc</c:when>
      <c:otherwise>Bản in lại (lần ${invoice.printCount - 1})</c:otherwise>
    </c:choose>
  </p>

  <table class="invoice-meta">
    <tr><th>Số hóa đơn</th><td><c:out value="${invoice.invoiceNo}"/></td><th>Ngày xuất</th><td><t:dt value="${invoice.issuedAt}"/></td></tr>
    <tr><th>Mã đơn</th><td><c:out value="${invoice.salesOrder.orderCode}"/></td><th>Nhân viên</th><td><c:out value="${invoice.issuedBy.fullName}"/></td></tr>
    <tr><th>Khách hàng</th><td><c:out value="${invoice.salesOrder.customer.fullName}"/></td><th>Điện thoại</th><td><c:out value="${invoice.salesOrder.customer.phone}"/></td></tr>
  </table>

  <table class="invoice-lines">
    <thead><tr><th>STT</th><th>Sản phẩm</th><th>SL</th><th>Đơn giá</th><th>Bảo hành</th><th>Thành tiền</th></tr></thead>
    <tbody>
    <c:forEach var="d" items="${invoice.salesOrder.details}" varStatus="st">
      <tr>
        <td>${st.index + 1}</td>
        <td><c:out value="${d.product.productName}"/></td>
        <td>${d.quantity}</td>
        <td><t:money value="${d.unitPrice}"/></td>
        <td>${d.warrantyMonths} tháng</td>
        <td><t:money value="${d.lineTotal}"/></td>
      </tr>
    </c:forEach>
    </tbody>
    <tfoot>
      <tr><th colspan="5">Phí vận chuyển</th><td><t:money value="${invoice.salesOrder.shippingFee}"/></td></tr>
      <tr class="invoice-total"><th colspan="5">TỔNG CỘNG</th><td><t:money value="${invoice.salesOrder.totalAmount}"/></td></tr>
    </tfoot>
  </table>

  <p class="invoice-pay">Hình thức thanh toán:
    <c:forEach var="p" items="${payments}" varStatus="st"><c:if test="${not st.first}">, </c:if><c:out value="${p.paymentMethod.methodName}"/> (<t:money value="${p.amount}"/>)</c:forEach>
    <c:if test="${empty payments}">Chưa ghi nhận</c:if>
  </p>

  <div class="invoice-sign"><span>Khách hàng<br><em>(Ký, ghi rõ họ tên)</em></span><span>Nhân viên bán hàng<br><em>(Ký, ghi rõ họ tên)</em></span></div>
  <p class="invoice-thanks">Cảm ơn quý khách. Vui lòng giữ hóa đơn để được bảo hành.</p>
</div>
</body>
</html>
