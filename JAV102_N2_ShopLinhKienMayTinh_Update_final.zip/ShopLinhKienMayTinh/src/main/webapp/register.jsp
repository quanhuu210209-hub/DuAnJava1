<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng ký tài khoản - CoreTech</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/base.css">
</head>
<body>
<div class="container">
    <h2>Đăng ký tài khoản khách hàng</h2>

    <c:if test="${not empty error}">
        <div class="alert-error"><c:out value="${error}"/></div>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/register">
        <div>
            <label for="fullName">Họ và tên</label>
            <input id="fullName" type="text" name="fullName" required maxlength="100"
                   value="<c:out value='${param.fullName}'/>">
        </div>
        <div>
            <label for="email">Email</label>
            <input id="email" type="email" name="email" maxlength="150"
                   value="<c:out value='${param.email}'/>">
        </div>
        <div>
            <label for="phone">Số điện thoại</label>
            <input id="phone" type="text" name="phone" maxlength="20"
                   value="<c:out value='${param.phone}'/>">
        </div>
        <div>
            <label for="password">Mật khẩu</label>
            <input id="password" type="password" name="password" required minlength="6"
                   autocomplete="new-password">
        </div>
        <div>
            <label for="confirmPassword">Nhập lại mật khẩu</label>
            <input id="confirmPassword" type="password" name="confirmPassword" required minlength="6"
                   autocomplete="new-password">
        </div>
        <button type="submit">Đăng ký</button>
    </form>

    <p>Đã có tài khoản? <a href="${pageContext.request.contextPath}/login">Đăng nhập</a></p>
</div>
</body>
</html>