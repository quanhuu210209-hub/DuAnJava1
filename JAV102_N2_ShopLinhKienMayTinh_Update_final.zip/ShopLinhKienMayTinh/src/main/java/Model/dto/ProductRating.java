package Model.dto;

/** Điểm trung bình và số lượt đánh giá (chỉ tính đánh giá đang hiện). Không phải entity. */
public class ProductRating {
    private final double avgRating;
    private final long totalReviews;

    public ProductRating(double avgRating, long totalReviews) {
        this.avgRating = avgRating;
        this.totalReviews = totalReviews;
    }
    public double getAvgRating() { return avgRating; }
    public long getTotalReviews() { return totalReviews; }
}
