package Model.dto;

import Model.admin.Product;

import java.math.BigDecimal;

/** Một dòng trong giỏ bán tại quầy (chỉ dùng để hiển thị, không lưu DB). */
public class PosLine {

    private final Product product;
    private final int quantity;

    public PosLine(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }

    public BigDecimal getLineTotal() {
        return product.getPrice().multiply(BigDecimal.valueOf(quantity));
    }
}
