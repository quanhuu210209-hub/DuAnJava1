package Model.manager;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class BranchInventoryId implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "BranchID")
    private int branchId;

    @Column(name = "ProductID")
    private int productId;

    public BranchInventoryId() {}

    public BranchInventoryId(int branchId, int productId) {
        this.branchId = branchId;
        this.productId = productId;
    }

    public int getBranchId() { return branchId; }
    public void setBranchId(int branchId) { this.branchId = branchId; }

    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BranchInventoryId)) return false;
        BranchInventoryId x = (BranchInventoryId) o;
        return branchId == x.branchId && productId == x.productId;
    }
    @Override public int hashCode() { return Objects.hash(branchId, productId); }
}
