package Model.user;

import java.io.Serializable;

public class ProductRating implements Serializable {
    private static final long serialVersionUID = 1L;

    private int productId;
    private int totalReviews;
    private double avgRating;

    public ProductRating() {
    }

    public ProductRating(int productId, int totalReviews, double avgRating) {
        this.productId = productId;
        this.totalReviews = totalReviews;
        this.avgRating = avgRating;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getTotalReviews() {
        return totalReviews;
    }

    public void setTotalReviews(int totalReviews) {
        this.totalReviews = totalReviews;
    }

    public double getAvgRating() {
        return avgRating;
    }

    public void setAvgRating(double avgRating) {
        this.avgRating = avgRating;
    }
}