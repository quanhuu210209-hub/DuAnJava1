package Filter;

import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.Arrays;

/**
 * Kiểm tra đăng nhập + phân quyền (Y2) theo tiền tố URL.
 *
 *   /admin/*   -> ADMIN
 *   /manager/* -> ADMIN, MANAGER
 *   /staff/*   -> ADMIN, MANAGER, STAFF
 *   /user/*    -> CUSTOMER
 *   còn lại (/home, /login, ...) là công khai.
 */
@WebFilter("/*")
public class AuthFilter implements Filter {

    private static final String[][] RULES = {
        {"/admin",   "ADMIN"},
        {"/manager", "ADMIN,MANAGER"},
        {"/staff",   "ADMIN,MANAGER,STAFF"},
        {"/user",    "CUSTOMER"}
    };

    /** Vai trò này có được vào đường dẫn này không? Đường dẫn công khai luôn là true. */
    public static boolean isAllowed(String path, String roleCode) {
        String[] allowed = rolesFor(path);
        return allowed == null || (roleCode != null && Arrays.asList(allowed).contains(roleCode));
    }

    private static String[] rolesFor(String path) {
        for (String[] r : RULES) {
            if (path.equals(r[0]) || path.startsWith(r[0] + "/")) return r[1].split(",");
        }
        return null;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        // getServletPath + getPathInfo: container đã chuẩn hóa (bỏ ;jsessionid, //, ../)
        String path = req.getServletPath() + (req.getPathInfo() == null ? "" : req.getPathInfo());

        if (rolesFor(path) == null) {          // trang công khai
            chain.doFilter(request, response);
            return;
        }

        User user = ServletUtils.currentUser(req);
        if (user == null) {                    // chưa đăng nhập
            if ("GET".equalsIgnoreCase(req.getMethod())) {
                String q = req.getQueryString();
                req.getSession().setAttribute("returnTo", path + (q == null ? "" : "?" + q));
            }
            ServletUtils.redirect(req, resp, "/login");
            return;
        }

        if (!isAllowed(path, user.getRoleCode())) {   // đăng nhập rồi nhưng sai vai trò
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        // Không cho trình duyệt cache trang quản trị (bấm Back sau khi đăng xuất sẽ không thấy lại dữ liệu)
        resp.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
        resp.setHeader("Pragma", "no-cache");
        resp.setDateHeader("Expires", 0);
        chain.doFilter(request, response);
    }
}
