package Servlet.admin;

import DAO.admin.PriceHistoryDAO;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** Xem lịch sử thay đổi giá. URL: /admin/price-history?q=  (chỉ xem; giá được ghi khi sửa sản phẩm) */
@WebServlet("/admin/price-history")
public class PriceHistoryServlet extends HttpServlet {

    private final PriceHistoryDAO dao = new PriceHistoryDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String q = ServletUtils.trim(req.getParameter("q"));
        req.setAttribute("q", q);
        req.setAttribute("histories", dao.search(q));
        ServletUtils.forward(req, resp, "/admin/price-history/list.jsp");
    }
}
