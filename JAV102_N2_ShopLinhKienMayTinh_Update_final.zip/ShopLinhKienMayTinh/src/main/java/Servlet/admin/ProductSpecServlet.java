package Servlet.admin;

import DAO.admin.ProductDAO;
import DAO.admin.ProductSpecDAO;
import Model.admin.Product;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** Thông số kỹ thuật của sản phẩm. URL: /admin/product-spec?productId=  (POST: save | delete) */
@WebServlet("/admin/product-spec")
public class ProductSpecServlet extends HttpServlet {

    private final ProductSpecDAO dao = new ProductSpecDAO();
    private final ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Product p = productDAO.findById(ServletUtils.parseInt(req.getParameter("productId"), 0));
        if (p == null) {
            ServletUtils.setFlash(req, "danger", "Không tìm thấy sản phẩm");
            ServletUtils.redirect(req, resp, "/admin/product");
            return;
        }
        ServletUtils.loadFlash(req);
        req.setAttribute("product", p);
        req.setAttribute("specs", dao.findByProduct(p.getProductId()));
        ServletUtils.forward(req, resp, "/admin/product-spec/list.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int productId = ServletUtils.parseInt(req.getParameter("productId"), 0);
        String back = "/admin/product-spec?productId=" + productId;

        if ("delete".equals(ServletUtils.trim(req.getParameter("action")))) {
            boolean ok = dao.delete(ServletUtils.parseInt(req.getParameter("id"), 0));
            ServletUtils.setFlash(req, ok ? "success" : "danger", ok ? "Đã xóa thông số" : "Xóa thông số thất bại");
            ServletUtils.redirect(req, resp, back);
            return;
        }

        String name = ServletUtils.trim(req.getParameter("specName"));
        String value = ServletUtils.trim(req.getParameter("specValue"));
        Validator v = new Validator()
                .required("specName", name, "Tên thông số")
                .maxLength("specName", name, 100, "Tên thông số")
                .required("specValue", value, "Giá trị")
                .maxLength("specValue", value, 200, "Giá trị");
        if (!v.isValid()) {
            ServletUtils.setFlash(req, "danger", v.getErrors().values().iterator().next());
        } else {
            boolean ok = dao.save(productId, name, value);
            ServletUtils.setFlash(req, ok ? "success" : "danger", ok ? "Đã lưu thông số" : "Lưu thông số thất bại");
        }
        ServletUtils.redirect(req, resp, back);
    }
}
