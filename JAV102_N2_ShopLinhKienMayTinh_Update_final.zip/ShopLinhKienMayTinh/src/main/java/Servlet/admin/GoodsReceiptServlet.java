package Servlet.admin;

import DAO.admin.AuditLogDAO;
import DAO.admin.BranchDAO;
import DAO.admin.GoodsReceiptDAO;
import DAO.admin.ProductDAO;
import DAO.admin.SupplierDAO;
import Model.admin.Branch;
import Model.admin.Product;
import Model.manager.GoodsReceipt;
import Model.manager.GoodsReceiptDetail;
import Model.manager.Supplier;
import Servlet.common.ServletUtils;
import Util.OrderConst;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Nhập hàng. URL: /admin/receipt?action=list|new|view&id=  (POST: save). Phiếu đã lưu không sửa/xóa vì đã cộng tồn kho. */
@WebServlet("/admin/receipt")
public class GoodsReceiptServlet extends HttpServlet {

    private static final String LIST = "/admin/receipt/list.jsp";
    private static final String FORM = "/admin/receipt/form.jsp";
    private static final String VIEW = "/admin/receipt/detail.jsp";
    private static final String URL  = "/admin/receipt";
    private final GoodsReceiptDAO dao = new GoodsReceiptDAO();
    private final BranchDAO branchDAO = new BranchDAO();
    private final SupplierDAO supplierDAO = new SupplierDAO();
    private final ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        switch (action) {
            case "new":
                List<GoodsReceiptDetail> first = new ArrayList<>();
                first.add(new GoodsReceiptDetail());   // 1 dòng trống ban đầu
                showForm(req, resp, new GoodsReceipt(), first);
                break;
            case "view":
                GoodsReceipt r = dao.findDetail(ServletUtils.parseInt(req.getParameter("id"), 0));
                if (r == null) {
                    ServletUtils.setFlash(req, "danger", "Không tìm thấy phiếu nhập");
                    ServletUtils.redirect(req, resp, URL);
                    return;
                }
                req.setAttribute("receipt", r);
                req.setAttribute("lines", dao.lines(r.getReceiptId()));
                ServletUtils.forward(req, resp, VIEW);
                break;
            default:
                String q = ServletUtils.trim(req.getParameter("q"));
                Integer branchId = ServletUtils.parseIntOrNull(req.getParameter("branchId"));
                ServletUtils.loadFlash(req);
                req.setAttribute("q", q);
                req.setAttribute("branchId", branchId);
                req.setAttribute("branches", branchDAO.findActive());
                req.setAttribute("receipts", dao.search(q, branchId));
                ServletUtils.forward(req, resp, LIST);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        GoodsReceipt r = new GoodsReceipt();
        r.setNote(ServletUtils.trim(req.getParameter("note")));
        Integer branchId = ServletUtils.parseIntOrNull(req.getParameter("branchId"));
        Integer supplierId = ServletUtils.parseIntOrNull(req.getParameter("supplierId"));
        Branch branch = branchId == null ? null : branchDAO.findById(branchId);
        Supplier sup = supplierId == null ? null : supplierDAO.findById(supplierId);
        r.setBranch(branch);
        r.setSupplier(sup);

        Validator v = new Validator().maxLength("note", r.getNote(), 500, "Ghi chú");
        if (branch == null) v.error("branchId", "Vui lòng chọn chi nhánh");
        if (sup == null) v.error("supplierId", "Vui lòng chọn nhà cung cấp");
        else if (!sup.isActive()) v.error("supplierId", "Nhà cung cấp đang ẩn");
        else if (branch != null && sup.getBranch() != null && sup.getBranch().getBranchId() != branch.getBranchId())
            v.error("supplierId", "Nhà cung cấp không thuộc chi nhánh đã chọn");

        // ---- các dòng sản phẩm ----
        String[] pids = req.getParameterValues("productId");
        String[] qtys = req.getParameterValues("quantity");
        String[] prices = req.getParameterValues("importPrice");
        List<GoodsReceiptDetail> lines = new ArrayList<>();
        Set<Integer> seen = new HashSet<>();
        String lineError = null;
        int n = pids == null ? 0 : pids.length;
        for (int i = 0; i < n; i++) {
            Integer pid = ServletUtils.parseIntOrNull(pids[i]);
            Product p = pid == null ? null : productDAO.findById(pid);
            String qty = at(qtys, i), price = at(prices, i);
            String err = checkLine(p, qty, price, i + 1, seen);
            if (err != null && lineError == null) lineError = err;

            GoodsReceiptDetail d = new GoodsReceiptDetail();
            d.setProduct(p);
            d.setQuantity(ServletUtils.parseInt(qty, 0));
            d.setImportPrice(toMoney(price));
            lines.add(d);
        }
        if (lines.isEmpty()) lineError = "Phiếu nhập cần ít nhất 1 sản phẩm";
        if (lineError != null) v.error("lines", lineError);

        if (!v.isValid()) {
            req.setAttribute("errors", v.getErrors());
            showForm(req, resp, r, lines);
            return;
        }

        r.setReceiptCode(OrderConst.newCode("PN"));
        r.setCreatedBy(ServletUtils.currentUser(req));
        if (r.getNote().isEmpty()) r.setNote(null);
        boolean ok = dao.create(r, lines);
        if (ok) AuditLogDAO.log(r.getCreatedBy(), "Create", "GoodsReceipt", r.getReceiptId(),
                "Nhập hàng " + r.getReceiptCode() + ", " + lines.size() + " dòng, tổng " + r.getTotalAmount());
        ServletUtils.setFlash(req, ok ? "success" : "danger",
                ok ? "Đã nhập kho, mã phiếu " + r.getReceiptCode() : "Lưu thất bại, vui lòng thử lại");
        ServletUtils.redirect(req, resp, URL);
    }

    /** Trả về thông báo lỗi của một dòng, hoặc null nếu hợp lệ. */
    private String checkLine(Product p, String qty, String price, int k, Set<Integer> seen) {
        String pre = "Dòng " + k + ": ";
        if (p == null) return pre + "chưa chọn sản phẩm";
        if ("Discontinued".equals(p.getStatus())) return pre + "sản phẩm đã ngừng kinh doanh";
        if (!seen.add(p.getProductId())) return pre + "sản phẩm bị trùng, hãy gộp số lượng";
        Validator v = new Validator().intRange("q", qty, 1, 100000, "số lượng").money("p", price, "đơn giá");
        return v.isValid() ? null : pre + String.join("; ", v.getErrors().values());
    }

    private static String at(String[] a, int i) { return a != null && i < a.length ? a[i] : ""; }

    private static BigDecimal toMoney(String s) {
        try { return new BigDecimal(s.trim()); } catch (Exception e) { return BigDecimal.ZERO; }
    }

    private void showForm(HttpServletRequest req, HttpServletResponse resp, GoodsReceipt r,
                          List<GoodsReceiptDetail> lines) throws ServletException, IOException {
        req.setAttribute("receipt", r);
        req.setAttribute("lines", lines);
        req.setAttribute("branches", branchDAO.findActive());
        req.setAttribute("suppliers", supplierDAO.findAll());
        req.setAttribute("products", productDAO.findAll());
        ServletUtils.forward(req, resp, FORM);
    }
}