package Servlet.admin;

import DAO.admin.BranchDAO;
import DAO.admin.SupplierDAO;
import Model.manager.Supplier;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** CRUD Nhà cung cấp. URL: /admin/supplier?action=list|new|edit&id=  (POST: save | delete) */
@WebServlet("/admin/supplier")
public class SupplierServlet extends HttpServlet {

    private static final String LIST = "/admin/supplier/list.jsp";
    private static final String FORM = "/admin/supplier/form.jsp";
    private static final String URL  = "/admin/supplier";
    private final SupplierDAO dao = new SupplierDAO();
    private final BranchDAO branchDAO = new BranchDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        switch (action) {
            case "new":
                Supplier s = new Supplier();
                s.setActive(true);
                showForm(req, resp, s);
                break;
            case "edit":
                Supplier found = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
                if (found == null) {
                    ServletUtils.setFlash(req, "danger", "Không tìm thấy nhà cung cấp");
                    ServletUtils.redirect(req, resp, URL);
                    return;
                }
                showForm(req, resp, found);
                break;
            default:
                String q = ServletUtils.trim(req.getParameter("q"));
                ServletUtils.loadFlash(req);
                req.setAttribute("q", q);
                req.setAttribute("suppliers", dao.search(q));
                ServletUtils.forward(req, resp, LIST);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        if ("delete".equals(action)) {
            int id = ServletUtils.parseInt(req.getParameter("id"), 0);
            if (dao.delete(id)) ServletUtils.setFlash(req, "success", "Đã xóa nhà cung cấp");
            else ServletUtils.setFlash(req, "danger",
                    "Không xóa được vì nhà cung cấp đã có phiếu nhập. Hãy chuyển sang trạng thái ẩn.");
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        Supplier s = new Supplier();
        s.setSupplierId(ServletUtils.parseInt(req.getParameter("supplierId"), 0));
        s.setSupplierName(ServletUtils.trim(req.getParameter("supplierName")));
        s.setAddress(ServletUtils.trim(req.getParameter("address")));
        s.setPhone(ServletUtils.trim(req.getParameter("phone")));
        s.setEmail(ServletUtils.trim(req.getParameter("email")));
        s.setActive(req.getParameter("active") != null);
        Integer branchId = ServletUtils.parseIntOrNull(req.getParameter("branchId"));
        s.setBranch(branchId == null ? null : branchDAO.findById(branchId));

        Validator v = new Validator()
                .required("supplierName", s.getSupplierName(), "Tên nhà cung cấp")
                .maxLength("supplierName", s.getSupplierName(), 150, "Tên nhà cung cấp")
                .maxLength("address", s.getAddress(), 300, "Địa chỉ")
                .phone("phone", s.getPhone())
                .email("email", s.getEmail())
                .maxLength("email", s.getEmail(), 150, "Email");
        if (v.isValid() && dao.nameExists(s.getSupplierName(), s.getSupplierId()))
            v.error("supplierName", "Tên nhà cung cấp đã tồn tại");

        if (!v.isValid()) {
            req.setAttribute("errors", v.getErrors());
            showForm(req, resp, s);
            return;
        }

        if (s.getAddress().isEmpty()) s.setAddress(null);
        if (s.getPhone().isEmpty()) s.setPhone(null);
        if (s.getEmail().isEmpty()) s.setEmail(null);
        boolean ok = s.getSupplierId() == 0 ? dao.insert(s) : dao.update(s);
        ServletUtils.setFlash(req, ok ? "success" : "danger",
                ok ? "Đã lưu nhà cung cấp" : "Lưu thất bại, vui lòng thử lại");
        ServletUtils.redirect(req, resp, URL);
    }

    private void showForm(HttpServletRequest req, HttpServletResponse resp, Supplier s)
            throws ServletException, IOException {
        req.setAttribute("supplier", s);
        req.setAttribute("branches", branchDAO.findActive());
        ServletUtils.forward(req, resp, FORM);
    }
}
