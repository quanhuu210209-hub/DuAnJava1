package Servlet.admin;

import DAO.admin.BrandDAO;
import Model.admin.Brand;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** CRUD Thương hiệu. URL: /admin/brand?action=list|new|edit&id=  (POST: save | delete) */
@WebServlet("/admin/brand")
public class BrandServlet extends HttpServlet {

    private static final String LIST = "/admin/brand/list.jsp";
    private static final String FORM = "/admin/brand/form.jsp";
    private static final String URL  = "/admin/brand";
    private final BrandDAO dao = new BrandDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        switch (action) {
            case "new":
                Brand b = new Brand();
                b.setActive(true);
                req.setAttribute("brand", b);
                ServletUtils.forward(req, resp, FORM);
                break;
            case "edit":
                Brand found = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
                if (found == null) {
                    ServletUtils.setFlash(req, "danger", "Không tìm thấy thương hiệu");
                    ServletUtils.redirect(req, resp, URL);
                    return;
                }
                req.setAttribute("brand", found);
                ServletUtils.forward(req, resp, FORM);
                break;
            default:
                ServletUtils.loadFlash(req);
                req.setAttribute("brands", dao.findAll());
                ServletUtils.forward(req, resp, LIST);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        if ("delete".equals(action)) {
            int id = ServletUtils.parseInt(req.getParameter("id"), 0);
            if (dao.delete(id)) ServletUtils.setFlash(req, "success", "Đã xóa thương hiệu");
            else ServletUtils.setFlash(req, "danger",
                    "Không xóa được vì thương hiệu đang có sản phẩm. Hãy chuyển sang trạng thái ẩn.");
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        Brand b = new Brand();
        b.setBrandId(ServletUtils.parseInt(req.getParameter("brandId"), 0));
        b.setBrandName(ServletUtils.trim(req.getParameter("brandName")));
        b.setLogoUrl(ServletUtils.trim(req.getParameter("logoUrl")));
        b.setActive(req.getParameter("active") != null);

        Validator v = new Validator()
                .required("brandName", b.getBrandName(), "Tên thương hiệu")
                .maxLength("brandName", b.getBrandName(), 100, "Tên thương hiệu")
                .maxLength("logoUrl", b.getLogoUrl(), 300, "Đường dẫn logo");
        if (v.isValid() && dao.nameExists(b.getBrandName(), b.getBrandId()))
            v.error("brandName", "Tên thương hiệu đã tồn tại");

        if (!v.isValid()) {
            req.setAttribute("errors", v.getErrors());
            req.setAttribute("brand", b);
            ServletUtils.forward(req, resp, FORM);
            return;
        }

        if (b.getLogoUrl().isEmpty()) b.setLogoUrl(null);
        boolean ok = b.getBrandId() == 0 ? dao.insert(b) : dao.update(b);
        ServletUtils.setFlash(req, ok ? "success" : "danger",
                ok ? "Đã lưu thương hiệu" : "Lưu thất bại, vui lòng thử lại");
        ServletUtils.redirect(req, resp, URL);
    }
}
