package Servlet.admin;

import DAO.admin.ReviewDAO;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** Kiểm duyệt đánh giá. URL: /admin/review?status=visible|hidden&q=  (POST: show | hide) */
@WebServlet("/admin/review")
public class ReviewServlet extends HttpServlet {

    private final ReviewDAO dao = new ReviewDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String status = ServletUtils.trim(req.getParameter("status"));
        String q = ServletUtils.trim(req.getParameter("q"));
        ServletUtils.loadFlash(req);
        req.setAttribute("status", status);
        req.setAttribute("q", q);
        req.setAttribute("reviews", dao.search(status, q));
        ServletUtils.forward(req, resp, "/admin/review/list.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        boolean show = "show".equals(ServletUtils.trim(req.getParameter("action")));
        boolean ok = dao.setVisible(ServletUtils.parseInt(req.getParameter("id"), 0), show);
        ServletUtils.setFlash(req, ok ? "success" : "danger",
                ok ? (show ? "Đã hiện đánh giá" : "Đã ẩn đánh giá") : "Không tìm thấy đánh giá");
        // quay lại đúng bộ lọc đang xem
        ServletUtils.redirect(req, resp, "/admin/review?status=" + ServletUtils.trim(req.getParameter("status"))
                + "&q=" + URLEncoder.encode(ServletUtils.trim(req.getParameter("q")), StandardCharsets.UTF_8));
    }
}
