package Servlet.admin;

import DAO.admin.BranchDAO;
import DAO.admin.RevenueDAO;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.time.LocalDate;

/** Báo cáo doanh thu. URL: /admin/revenue?from=yyyy-MM-dd&to=yyyy-MM-dd&branchId= (mặc định 30 ngày gần nhất) */
@WebServlet("/admin/revenue")
public class RevenueServlet extends HttpServlet {

    private final RevenueDAO dao = new RevenueDAO();
    private final BranchDAO branchDAO = new BranchDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        LocalDate today = LocalDate.now();
        LocalDate from = parseDate(req.getParameter("from"), today.minusDays(29));
        LocalDate to = parseDate(req.getParameter("to"), today);
        if (from.isAfter(to)) {
            req.setAttribute("error", "Ngày bắt đầu phải trước hoặc bằng ngày kết thúc");
            from = today.minusDays(29);
            to = today;
        }
        Integer branchId = ServletUtils.parseIntOrNull(req.getParameter("branchId"));

        req.setAttribute("from", from);
        req.setAttribute("to", to);
        req.setAttribute("branchId", branchId);
        req.setAttribute("branches", branchDAO.findActive());
        req.setAttribute("summary", dao.summary(from, to, branchId));
        req.setAttribute("days", dao.byDay(from, to, branchId));
        req.setAttribute("bestSellers", dao.bestSellers(from, to, branchId));
        req.setAttribute("staffs", dao.byStaff(from, to, branchId));
        ServletUtils.forward(req, resp, "/admin/revenue/index.jsp");
    }

    private LocalDate parseDate(String s, LocalDate def) {
        try { return LocalDate.parse(s.trim()); } catch (Exception e) { return def; }
    }
}
