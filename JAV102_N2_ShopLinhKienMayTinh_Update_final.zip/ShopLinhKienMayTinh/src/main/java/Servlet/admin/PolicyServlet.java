package Servlet.admin;

import DAO.admin.PolicyDAO;
import Model.admin.Policy;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.time.LocalDateTime;

/** CRUD Chính sách bảo hành / đổi trả. URL: /admin/policy?action=list|new|edit&id=  (POST: save | delete) */
@WebServlet("/admin/policy")
public class PolicyServlet extends HttpServlet {

    private static final String LIST = "/admin/policy/list.jsp";
    private static final String FORM = "/admin/policy/form.jsp";
    private static final String URL  = "/admin/policy";
    private final PolicyDAO dao = new PolicyDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        switch (action) {
            case "new":
                Policy p = new Policy();
                p.setPolicyType("Warranty");
                p.setActive(true);
                req.setAttribute("policy", p);
                ServletUtils.forward(req, resp, FORM);
                break;
            case "edit":
                Policy found = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
                if (found == null) {
                    ServletUtils.setFlash(req, "danger", "Không tìm thấy chính sách");
                    ServletUtils.redirect(req, resp, URL);
                    return;
                }
                req.setAttribute("policy", found);
                ServletUtils.forward(req, resp, FORM);
                break;
            default:
                ServletUtils.loadFlash(req);
                req.setAttribute("policies", dao.findAll());
                ServletUtils.forward(req, resp, LIST);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        if ("delete".equals(action)) {
            boolean ok = dao.delete(ServletUtils.parseInt(req.getParameter("id"), 0));
            ServletUtils.setFlash(req, ok ? "success" : "danger", ok ? "Đã xóa chính sách" : "Xóa chính sách thất bại");
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        Policy p = new Policy();
        p.setPolicyId(ServletUtils.parseInt(req.getParameter("policyId"), 0));
        p.setPolicyType(ServletUtils.trim(req.getParameter("policyType")));
        p.setTitle(ServletUtils.trim(req.getParameter("title")));
        p.setContent(ServletUtils.trim(req.getParameter("content")));
        p.setActive(req.getParameter("active") != null);

        Validator v = new Validator()
                .oneOf("policyType", p.getPolicyType(), "Loại chính sách", "Warranty", "Return")
                .required("title", p.getTitle(), "Tiêu đề")
                .maxLength("title", p.getTitle(), 200, "Tiêu đề")
                .required("content", p.getContent(), "Nội dung")
                .maxLength("content", p.getContent(), 4000, "Nội dung");
        if (!v.isValid()) {
            req.setAttribute("errors", v.getErrors());
            req.setAttribute("policy", p);
            ServletUtils.forward(req, resp, FORM);
            return;
        }

        int userId = ServletUtils.currentUser(req).getUserId();
        boolean ok;
        if (p.getPolicyId() == 0) {
            p.setUpdatedBy(ServletUtils.currentUser(req));
            p.setUpdatedAt(LocalDateTime.now());
            ok = dao.insert(p);
        } else {
            ok = dao.update(p, userId);
        }
        ServletUtils.setFlash(req, ok ? "success" : "danger", ok ? "Đã lưu chính sách" : "Lưu thất bại, vui lòng thử lại");
        ServletUtils.redirect(req, resp, URL);
    }
}
