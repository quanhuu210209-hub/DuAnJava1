package Servlet.admin;

import DAO.admin.SystemSettingDAO;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** Cấu hình hệ thống. URL: /admin/setting  (POST: đổi giá trị một cấu hình) */
@WebServlet("/admin/setting")
public class SystemSettingServlet extends HttpServlet {

    private static final String URL = "/admin/setting";
    private final SystemSettingDAO dao = new SystemSettingDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ServletUtils.loadFlash(req);
        req.setAttribute("settings", dao.findAll());
        ServletUtils.forward(req, resp, "/admin/setting/list.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String key = ServletUtils.trim(req.getParameter("settingKey"));
        String value = ServletUtils.trim(req.getParameter("settingValue"));

        Validator v = new Validator()
                .required("settingValue", value, "Giá trị")
                .maxLength("settingValue", value, 500, "Giá trị");
        if (key.endsWith("_FEE") || key.endsWith("_MIN"))      // các cấu hình tiền phải là số nguyên không âm
            v.pattern("settingValue", value, "\\d+", "Giá trị phải là số nguyên không âm");

        if (!v.isValid()) {
            ServletUtils.setFlash(req, "danger", v.getErrors().values().iterator().next());
        } else {
            boolean ok = dao.updateValue(key, value, ServletUtils.currentUser(req).getUserId());
            ServletUtils.setFlash(req, ok ? "success" : "danger", ok ? "Đã cập nhật cấu hình" : "Không tìm thấy cấu hình");
        }
        ServletUtils.redirect(req, resp, URL);
    }
}
