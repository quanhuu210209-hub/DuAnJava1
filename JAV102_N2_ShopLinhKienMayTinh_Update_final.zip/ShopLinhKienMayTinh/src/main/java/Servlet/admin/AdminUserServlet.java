package Servlet.admin;

import DAO.admin.BranchDAO;
import DAO.admin.RoleDAO;
import DAO.user.UserDAO;
import Model.admin.Role;
import Model.user.User;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** CRUD Người dùng (nhân viên, quản lý, khách). URL: /admin/user  (POST: save | delete) */
@WebServlet("/admin/user")
public class AdminUserServlet extends HttpServlet {

    private static final String LIST = "/admin/user/list.jsp";
    private static final String FORM = "/admin/user/form.jsp";
    private static final String URL  = "/admin/user";

    private final UserDAO dao = new UserDAO();
    private final RoleDAO roleDAO = new RoleDAO();
    private final BranchDAO branchDAO = new BranchDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        switch (action) {
            case "new":
                User u = new User();
                u.setActive(true);
                showForm(req, resp, u);
                break;
            case "edit":
                User found = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
                if (found == null) {
                    ServletUtils.setFlash(req, "danger", "Không tìm thấy người dùng");
                    ServletUtils.redirect(req, resp, URL);
                    return;
                }
                found.setPasswordHash(null);     // không đẩy hash ra form
                showForm(req, resp, found);
                break;
            default:
                ServletUtils.loadFlash(req);
                req.setAttribute("users", dao.findAll());
                ServletUtils.forward(req, resp, LIST);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        String action = ServletUtils.trim(req.getParameter("action"));

        if ("delete".equals(action)) {            // "xóa" = khóa tài khoản
            int id = ServletUtils.parseInt(req.getParameter("id"), 0);
            if (id == me.getUserId()) {
                ServletUtils.setFlash(req, "danger", "Bạn không thể khóa chính tài khoản đang đăng nhập");
            } else if (dao.deactivate(id)) {
                ServletUtils.setFlash(req, "success", "Đã khóa tài khoản");
            } else {
                ServletUtils.setFlash(req, "danger", "Thao tác thất bại");
            }
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        // ---- save ----
        User u = new User();
        u.setUserId(ServletUtils.parseInt(req.getParameter("userId"), 0));
        u.setFullName(ServletUtils.trim(req.getParameter("fullName")));
        u.setEmail(ServletUtils.trim(req.getParameter("email")));
        u.setPhone(ServletUtils.trim(req.getParameter("phone")));
        u.setRole(roleDAO.findById(ServletUtils.parseInt(req.getParameter("roleId"), 0)));
        Integer branchId = ServletUtils.parseIntOrNull(req.getParameter("branchId"));
        u.setBranch(branchId == null ? null : branchDAO.findById(branchId));
        u.setActive(req.getParameter("active") != null);
        u.setVerified(true);
        String password = req.getParameter("password");
        boolean isNew = u.getUserId() == 0;

        // Không cho tự đổi vai trò / tự khóa mình
        if (!isNew && u.getUserId() == me.getUserId()) {
            u.setRole(me.getRole());
            u.setActive(true);
        }

        Role role = u.getRole();

        Validator v = new Validator()
                .required("fullName", u.getFullName(), "Họ tên")
                .maxLength("fullName", u.getFullName(), 100, "Họ tên")
                .maxLength("email", u.getEmail(), 150, "Email")
                .email("email", u.getEmail())
                .phone("phone", u.getPhone());
        if (u.getEmail().isEmpty() && u.getPhone().isEmpty())
            v.error("email", "Cần nhập ít nhất email hoặc số điện thoại để đăng nhập");
        if (role == null) v.error("roleId", "Vui lòng chọn vai trò");

        // Quản lý / nhân viên bắt buộc thuộc 1 chi nhánh; vai trò khác thì không có chi nhánh
        if (role != null) {
            boolean needBranch = role.getRoleCode().equals("MANAGER") || role.getRoleCode().equals("STAFF");
            if (needBranch && u.getBranch() == null) v.error("branchId", "Quản lý/Nhân viên phải thuộc một chi nhánh");
            if (!needBranch) u.setBranch(null);
        }

        if (isNew) {
            v.required("password", password, "Mật khẩu");
        }
        if (password != null && !password.isEmpty()) {
            v.minLength("password", password, 6, "Mật khẩu").maxLength("password", password, 72, "Mật khẩu");
        }

        if (v.isValid()) {
            if (!u.getEmail().isEmpty() && dao.emailExists(u.getEmail(), u.getUserId())) v.error("email", "Email đã được sử dụng");
            if (!u.getPhone().isEmpty() && dao.phoneExists(u.getPhone(), u.getUserId())) v.error("phone", "Số điện thoại đã được sử dụng");
        }

        if (!v.isValid()) {
            req.setAttribute("errors", v.getErrors());
            showForm(req, resp, u);
            return;
        }

        boolean ok;
        if (isNew) {
            ok = dao.insert(u, password);
        } else {
            ok = dao.update(u, password);   // password rỗng = giữ mật khẩu cũ
        }
        ServletUtils.setFlash(req, ok ? "success" : "danger", ok ? "Đã lưu người dùng" : "Lưu thất bại, vui lòng thử lại");
        ServletUtils.redirect(req, resp, URL);
    }

    private void showForm(HttpServletRequest req, HttpServletResponse resp, User u)
            throws ServletException, IOException {
        req.setAttribute("editUser", u);
        req.setAttribute("roles", roleDAO.findAll());
        req.setAttribute("branches", branchDAO.findActive());
        ServletUtils.forward(req, resp, FORM);
    }
}
