package Servlet.admin;

import DAO.admin.AuditLogDAO;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** Xem nhật ký hệ thống. URL: /admin/audit?q=&action=  (chỉ xem). */
@WebServlet("/admin/audit")
public class AuditLogServlet extends HttpServlet {

    private static final String LIST = "/admin/audit/list.jsp";
    private final AuditLogDAO dao = new AuditLogDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String q = ServletUtils.trim(req.getParameter("q"));
        String action = ServletUtils.trim(req.getParameter("action"));
        req.setAttribute("q", q);
        req.setAttribute("action", action);
        req.setAttribute("actions", dao.actions());
        req.setAttribute("logs", dao.search(q, action));
        ServletUtils.forward(req, resp, LIST);
    }
}
