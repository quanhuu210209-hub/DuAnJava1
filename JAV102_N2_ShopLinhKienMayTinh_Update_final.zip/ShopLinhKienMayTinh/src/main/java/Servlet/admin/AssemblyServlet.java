package Servlet.admin;

import DAO.admin.AssemblyJobDAO;
import DAO.user.OrderDAO;
import DAO.user.UserDAO;
import Model.staff.AssemblyJob;
import Model.user.Order;
import Model.user.User;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.time.LocalDateTime;

/** Phân công lắp đặt. URL: /admin/assembly?action=list|new|edit&id=  (POST: save | delete) */
@WebServlet("/admin/assembly")
public class AssemblyServlet extends HttpServlet {

    private static final String LIST = "/admin/assembly/list.jsp";
    private static final String FORM = "/admin/assembly/form.jsp";
    private static final String URL  = "/admin/assembly";
    private final AssemblyJobDAO dao = new AssemblyJobDAO();
    private final OrderDAO orderDAO = new OrderDAO();
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        switch (action) {
            case "new":
                AssemblyJob j = new AssemblyJob();
                j.setStatus("Waiting");
                showForm(req, resp, j);
                break;
            case "edit":
                AssemblyJob found = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
                if (found == null || "Done".equals(found.getStatus())) {
                    ServletUtils.setFlash(req, "danger", "Không tìm thấy việc lắp đặt hoặc việc đã hoàn thành");
                    ServletUtils.redirect(req, resp, URL);
                    return;
                }
                showForm(req, resp, found);
                break;
            default:
                String status = ServletUtils.trim(req.getParameter("status"));
                ServletUtils.loadFlash(req);
                req.setAttribute("status", status);
                req.setAttribute("jobs", dao.search(status));
                ServletUtils.forward(req, resp, LIST);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        if ("delete".equals(action)) {
            AssemblyJob j = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
            if (j != null && "Waiting".equals(j.getStatus()) && dao.delete(j.getJobId()))
                ServletUtils.setFlash(req, "success", "Đã xóa việc lắp đặt");
            else ServletUtils.setFlash(req, "danger", "Chỉ xóa được việc đang ở trạng thái Chờ");
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        int jobId = ServletUtils.parseInt(req.getParameter("jobId"), 0);
        AssemblyJob job = jobId == 0 ? new AssemblyJob() : dao.findById(jobId);
        if (job == null || "Done".equals(job.getStatus())) {
            ServletUtils.setFlash(req, "danger", "Không tìm thấy việc lắp đặt hoặc việc đã hoàn thành");
            ServletUtils.redirect(req, resp, URL);
            return;
        }
        if (jobId == 0) {      // việc mới: chọn đơn
            job.setStatus("Waiting");
            job.setSalesOrder(orderDAO.findById(ServletUtils.parseInt(req.getParameter("orderId"), 0)));
        }
        User staff = userDAO.findById(ServletUtils.parseInt(req.getParameter("assignedTo"), 0));
        job.setAssignedTo(staff);
        job.setRequirement(ServletUtils.trim(req.getParameter("requirement")));

        Order order = job.getSalesOrder();
        Validator v = new Validator()
                .maxLength("requirement", job.getRequirement(), 500, "Yêu cầu");
        if (order == null) v.error("orderId", "Vui lòng chọn đơn hàng");
        else if ("Cancelled".equals(order.getStatus())) v.error("orderId", "Đơn hàng đã hủy");
        if (staff == null) v.error("assignedTo", "Vui lòng chọn người thực hiện");
        else if (order != null && (staff.getBranchId() == null || staff.getBranchId() != order.getBranch().getBranchId()))
            v.error("assignedTo", "Người thực hiện phải cùng chi nhánh với đơn hàng");

        if (!v.isValid()) {
            req.setAttribute("errors", v.getErrors());
            showForm(req, resp, job);
            return;
        }

        if (job.getRequirement().isEmpty()) job.setRequirement(null);
        boolean ok;
        if (jobId == 0) {
            job.setBranch(order.getBranch());
            job.setAssignedBy(ServletUtils.currentUser(req));
            job.setAssignedAt(LocalDateTime.now());
            ok = dao.insert(job);
        } else {
            ok = dao.update(job);
        }
        ServletUtils.setFlash(req, ok ? "success" : "danger",
                ok ? "Đã lưu phân công lắp đặt" : "Lưu thất bại, vui lòng thử lại");
        ServletUtils.redirect(req, resp, URL);
    }

    private void showForm(HttpServletRequest req, HttpServletResponse resp, AssemblyJob job)
            throws ServletException, IOException {
        req.setAttribute("job", job);
        req.setAttribute("orders", job.getJobId() == 0 ? dao.availableOrders() : null);
        req.setAttribute("staffs", dao.assignees());
        ServletUtils.forward(req, resp, FORM);
    }
}
