package Servlet.admin;

import DAO.admin.CategoryDAO;
import Model.admin.Category;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** CRUD Danh mục. URL: /admin/category?action=list|new|edit&id=  (POST: save | delete) */
@WebServlet("/admin/category")
public class CategoryServlet extends HttpServlet {

    private static final String LIST = "/admin/category/list.jsp";
    private static final String FORM = "/admin/category/form.jsp";
    private static final String URL  = "/admin/category";
    private final CategoryDAO dao = new CategoryDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        switch (action) {
            case "new":
                Category c = new Category();
                c.setActive(true);
                req.setAttribute("category", c);
                ServletUtils.forward(req, resp, FORM);
                break;
            case "edit":
                Category found = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
                if (found == null) {
                    ServletUtils.setFlash(req, "danger", "Không tìm thấy danh mục");
                    ServletUtils.redirect(req, resp, URL);
                    return;
                }
                req.setAttribute("category", found);
                ServletUtils.forward(req, resp, FORM);
                break;
            default:
                ServletUtils.loadFlash(req);
                req.setAttribute("categories", dao.findAll());
                ServletUtils.forward(req, resp, LIST);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        if ("delete".equals(action)) {
            int id = ServletUtils.parseInt(req.getParameter("id"), 0);
            if (dao.delete(id)) ServletUtils.setFlash(req, "success", "Đã xóa danh mục");
            else ServletUtils.setFlash(req, "danger",
                    "Không xóa được vì danh mục đang có sản phẩm. Hãy chuyển sang trạng thái ẩn.");
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        // ---- save (thêm mới nếu id = 0, ngược lại cập nhật) ----
        Category c = new Category();
        c.setCategoryId(ServletUtils.parseInt(req.getParameter("categoryId"), 0));
        c.setCategoryName(ServletUtils.trim(req.getParameter("categoryName")));
        c.setDescription(ServletUtils.trim(req.getParameter("description")));
        c.setActive(req.getParameter("active") != null);

        Validator v = new Validator()
                .required("categoryName", c.getCategoryName(), "Tên danh mục")
                .maxLength("categoryName", c.getCategoryName(), 100, "Tên danh mục")
                .maxLength("description", c.getDescription(), 255, "Mô tả");
        if (v.isValid() && dao.nameExists(c.getCategoryName(), c.getCategoryId()))
            v.error("categoryName", "Tên danh mục đã tồn tại");

        if (!v.isValid()) {
            req.setAttribute("errors", v.getErrors());
            req.setAttribute("category", c);
            ServletUtils.forward(req, resp, FORM);
            return;
        }

        boolean ok = c.getCategoryId() == 0 ? dao.insert(c) : dao.update(c);
        ServletUtils.setFlash(req, ok ? "success" : "danger",
                ok ? "Đã lưu danh mục" : "Lưu thất bại, vui lòng thử lại");
        ServletUtils.redirect(req, resp, URL);
    }
}
