package Servlet.admin;

import DAO.admin.BrandDAO;
import DAO.admin.CategoryDAO;
import DAO.admin.ProductDAO;
import Model.admin.Product;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.math.BigDecimal;

/** CRUD Sản phẩm. URL: /admin/product?action=list|new|edit&id=  (POST: save | delete) */
@WebServlet("/admin/product")
public class ProductServlet extends HttpServlet {

    private static final String LIST = "/admin/product/list.jsp";
    private static final String FORM = "/admin/product/form.jsp";
    private static final String URL  = "/admin/product";
    private static final String[] STATUSES = {"Active", "Hidden", "Discontinued"};

    private final ProductDAO dao = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final BrandDAO brandDAO = new BrandDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        switch (action) {
            case "new":
                Product p = new Product();
                p.setStatus("Active");
                p.setWarrantyMonths(12);
                showForm(req, resp, p);
                break;
            case "edit":
                Product found = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
                if (found == null) {
                    ServletUtils.setFlash(req, "danger", "Không tìm thấy sản phẩm");
                    ServletUtils.redirect(req, resp, URL);
                    return;
                }
                showForm(req, resp, found);
                break;
            default:
                ServletUtils.loadFlash(req);
                String keyword = ServletUtils.trim(req.getParameter("keyword"));
                Integer categoryId = ServletUtils.parseIntOrNull(req.getParameter("categoryId"));
                Integer brandId = ServletUtils.parseIntOrNull(req.getParameter("brandId"));
                req.setAttribute("products", dao.search(keyword, categoryId, brandId, false));
                req.setAttribute("categories", categoryDAO.findAll());
                req.setAttribute("brands", brandDAO.findAll());
                req.setAttribute("keyword", keyword);
                req.setAttribute("categoryId", categoryId);
                req.setAttribute("brandId", brandId);
                ServletUtils.forward(req, resp, LIST);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        if ("delete".equals(action)) {
            boolean ok = dao.discontinue(ServletUtils.parseInt(req.getParameter("id"), 0));
            ServletUtils.setFlash(req, ok ? "success" : "danger",
                    ok ? "Đã chuyển sản phẩm sang trạng thái ngừng kinh doanh" : "Thao tác thất bại");
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        // ---- save ----
        String priceRaw = ServletUtils.trim(req.getParameter("price"));
        String warrantyRaw = ServletUtils.trim(req.getParameter("warrantyMonths"));
        Product p = new Product();
        p.setProductId(ServletUtils.parseInt(req.getParameter("productId"), 0));
        p.setSku(ServletUtils.trim(req.getParameter("sku")));
        p.setProductName(ServletUtils.trim(req.getParameter("productName")));
        p.setCategory(categoryDAO.findById(ServletUtils.parseInt(req.getParameter("categoryId"), 0)));
        p.setBrand(brandDAO.findById(ServletUtils.parseInt(req.getParameter("brandId"), 0)));
        p.setDescription(ServletUtils.trim(req.getParameter("description")));
        p.setThumbnailUrl(ServletUtils.trim(req.getParameter("thumbnailUrl")));
        p.setStatus(ServletUtils.trim(req.getParameter("status")));
        p.setWarrantyMonths(ServletUtils.parseInt(warrantyRaw, 0));
        p.setPrice(priceRaw.matches("\\d{1,15}") ? new BigDecimal(priceRaw) : null);

        Validator v = new Validator()
                .required("sku", p.getSku(), "Mã SKU")
                .maxLength("sku", p.getSku(), 50, "Mã SKU")
                .pattern("sku", p.getSku(), "[A-Za-z0-9_-]+", "SKU chỉ gồm chữ, số, gạch ngang, gạch dưới")
                .required("productName", p.getProductName(), "Tên sản phẩm")
                .maxLength("productName", p.getProductName(), 250, "Tên sản phẩm")
                .maxLength("thumbnailUrl", p.getThumbnailUrl(), 300, "Đường dẫn ảnh")
                .money("price", priceRaw, "Giá bán")
                .intRange("warrantyMonths", warrantyRaw, 0, 120, "Thời gian bảo hành (tháng)")
                .oneOf("status", p.getStatus(), "Trạng thái", STATUSES);
        if (p.getCategory() == null) v.error("categoryId", "Vui lòng chọn danh mục");
        if (p.getBrand() == null) v.error("brandId", "Vui lòng chọn thương hiệu");
        if (v.isValid() && dao.skuExists(p.getSku(), p.getProductId())) v.error("sku", "Mã SKU đã tồn tại");

        if (!v.isValid()) {
            req.setAttribute("errors", v.getErrors());
            req.setAttribute("priceRaw", priceRaw);
            showForm(req, resp, p);
            return;
        }

        if (p.getThumbnailUrl().isEmpty()) p.setThumbnailUrl(null);
        if (p.getDescription().isEmpty()) p.setDescription(null);

        // Thêm mới (id = 0) hoặc cập nhật. Khi cập nhật, DAO tự ghi PriceHistory nếu giá đổi.
        boolean ok = p.getProductId() == 0
                ? dao.insert(p)
                : dao.update(p, ServletUtils.currentUser(req).getUserId());
        ServletUtils.setFlash(req, ok ? "success" : "danger", ok ? "Đã lưu sản phẩm" : "Lưu thất bại, vui lòng thử lại");
        ServletUtils.redirect(req, resp, URL);
    }

    private void showForm(HttpServletRequest req, HttpServletResponse resp, Product p)
            throws ServletException, IOException {
        req.setAttribute("product", p);
        req.setAttribute("categories", categoryDAO.findAll());
        req.setAttribute("brands", brandDAO.findAll());
        ServletUtils.forward(req, resp, FORM);
    }
}
