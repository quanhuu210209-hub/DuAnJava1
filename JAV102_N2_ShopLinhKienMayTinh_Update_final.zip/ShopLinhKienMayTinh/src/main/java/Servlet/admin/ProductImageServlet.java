package Servlet.admin;

import DAO.admin.ProductDAO;
import DAO.admin.ProductImageDAO;
import Model.admin.Product;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** Ảnh phụ của sản phẩm. URL: /admin/product-image?productId=  (POST: add | delete) */
@WebServlet("/admin/product-image")
public class ProductImageServlet extends HttpServlet {

    private final ProductImageDAO dao = new ProductImageDAO();
    private final ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Product p = productDAO.findById(ServletUtils.parseInt(req.getParameter("productId"), 0));
        if (p == null) {
            ServletUtils.setFlash(req, "danger", "Không tìm thấy sản phẩm");
            ServletUtils.redirect(req, resp, "/admin/product");
            return;
        }
        ServletUtils.loadFlash(req);
        req.setAttribute("product", p);
        req.setAttribute("images", dao.findByProduct(p.getProductId()));
        ServletUtils.forward(req, resp, "/admin/product-image/list.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int productId = ServletUtils.parseInt(req.getParameter("productId"), 0);
        String back = "/admin/product-image?productId=" + productId;

        if ("delete".equals(ServletUtils.trim(req.getParameter("action")))) {
            boolean ok = dao.delete(ServletUtils.parseInt(req.getParameter("id"), 0));
            ServletUtils.setFlash(req, ok ? "success" : "danger", ok ? "Đã xóa ảnh" : "Xóa ảnh thất bại");
            ServletUtils.redirect(req, resp, back);
            return;
        }

        String url = ServletUtils.trim(req.getParameter("imageUrl"));
        Validator v = new Validator()
                .required("imageUrl", url, "Đường dẫn ảnh")
                .maxLength("imageUrl", url, 300, "Đường dẫn ảnh");
        if (!v.isValid()) {
            ServletUtils.setFlash(req, "danger", v.getErrors().values().iterator().next());
        } else {
            boolean ok = dao.add(productId, url, ServletUtils.parseInt(req.getParameter("sortOrder"), 0));
            ServletUtils.setFlash(req, ok ? "success" : "danger", ok ? "Đã thêm ảnh" : "Thêm ảnh thất bại");
        }
        ServletUtils.redirect(req, resp, back);
    }
}
