package Servlet.user;

import DAO.user.CustomerDAO;
import DAO.user.OrderDAO;
import Model.admin.PaymentMethod;
import Model.user.Customer;
import Model.user.Order;
import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

/** Khách hàng xem, thanh toán và hủy đơn của mình. URL: /user/order  hoặc /user/order?id= */
@WebServlet("/user/order")
public class UserOrderServlet extends HttpServlet {

    private final OrderDAO orderDAO = new OrderDAO();
    private final CustomerDAO customerDAO = new CustomerDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        Customer customer = customerDAO.findByUserId(me.getUserId());
        if (customer == null) {
            ServletUtils.setFlash(req, "warning", "Tài khoản chưa có hồ sơ khách hàng");
            ServletUtils.redirect(req, resp, "/home");
            return;
        }

        ServletUtils.loadFlash(req);

        int id = ServletUtils.parseInt(req.getParameter("id"), 0);
        if (id > 0) {
            Order o = orderDAO.findById(id);
            // Chống xem đơn của người khác bằng cách đoán id
            if (o == null || o.getCustomer() == null || o.getCustomer().getCustomerId() != customer.getCustomerId()) {
                ServletUtils.setFlash(req, "danger", "Không tìm thấy đơn hàng");
                ServletUtils.redirect(req, resp, "/user/order");
                return;
            }
            List<PaymentMethod> paymentMethods = orderDAO.findActivePaymentMethods();
            req.setAttribute("order", o);
            req.setAttribute("paymentMethods", paymentMethods);
            ServletUtils.forward(req, resp, "/user/order/detail.jsp");
            return;
        }

        req.setAttribute("orders", orderDAO.findByCustomer(customer.getCustomerId()));
        ServletUtils.forward(req, resp, "/user/order/list.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        User me = ServletUtils.currentUser(req);
        Customer customer = customerDAO.findByUserId(me.getUserId());
        if (customer == null) {
            ServletUtils.setFlash(req, "warning", "Tài khoản chưa có hồ sơ khách hàng");
            ServletUtils.redirect(req, resp, "/home");
            return;
        }

        String action = req.getParameter("action");
        int orderId = ServletUtils.parseInt(req.getParameter("orderId"), 0);

        if ("pay".equals(action)) {
            int paymentMethodId = ServletUtils.parseInt(req.getParameter("paymentMethodId"), 0);
            if (orderId <= 0 || paymentMethodId <= 0) {
                ServletUtils.setFlash(req, "danger", "Vui lòng chọn phương thức thanh toán hợp lệ");
                ServletUtils.redirect(req, resp, orderId > 0 ? "/user/order?id=" + orderId : "/user/order");
                return;
            }

            boolean paid = orderDAO.payOnlineOrder(orderId, customer.getCustomerId(), paymentMethodId);
            if (paid) {
                ServletUtils.setFlash(req, "success", "Thanh toán đơn hàng thành công");
            } else {
                ServletUtils.setFlash(req, "danger", "Không thể thanh toán đơn hàng này");
            }
            ServletUtils.redirect(req, resp, "/user/order?id=" + orderId);
            return;
        }

        if ("cancel".equals(action)) {
            String reason = req.getParameter("cancelReason");
            boolean cancelled = orderDAO.cancelCustomerOrder(orderId, customer.getCustomerId(), me.getUserId(), reason);
            if (cancelled) {
                ServletUtils.setFlash(req, "success", "Đã hủy đơn hàng");
            } else {
                ServletUtils.setFlash(req, "danger", "Không thể hủy đơn hàng này");
            }
            ServletUtils.redirect(req, resp, orderId > 0 ? "/user/order?id=" + orderId : "/user/order");
            return;
        }

        ServletUtils.redirect(req, resp, orderId > 0 ? "/user/order?id=" + orderId : "/user/order");
    }
}