package Servlet.user;

import DAO.user.CustomerDAO;
import DAO.user.OrderDAO;
import Model.user.Customer;
import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/user/checkout")
public class UserCheckoutServlet extends HttpServlet {

    private final OrderDAO orderDAO = new OrderDAO();
    private final CustomerDAO customerDAO = new CustomerDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");

        User me = ServletUtils.currentUser(req);
        if (me == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            resp.getWriter().write("{\"error\":\"Vui lòng đăng nhập.\"}");
            return;
        }

        Customer customer = customerDAO.findByUserId(me.getUserId());
        if (customer == null) {
            resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
            resp.getWriter().write("{\"error\":\"Tài khoản chưa có hồ sơ khách hàng.\"}");
            return;
        }

        Integer branchId = ServletUtils.parseInt(req.getParameter("branchId"), 0);
        if (branchId <= 0) branchId = null;

        String receiveMethod = ServletUtils.trim(req.getParameter("receiveMethod"));
        String receiverName = ServletUtils.trim(req.getParameter("receiverName"));
        String receiverPhone = ServletUtils.trim(req.getParameter("receiverPhone"));
        String shippingAddress = ServletUtils.trim(req.getParameter("shippingAddress"));
        String note = ServletUtils.trim(req.getParameter("note"));

        int orderId = orderDAO.createOnlineOrder(
                customer.getCustomerId(),
                me.getUserId(),
                branchId,
                receiveMethod,
                receiverName,
                receiverPhone,
                shippingAddress,
                note
        );

        if (orderId <= 0) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\":\"Không thể tạo đơn hàng. Vui lòng kiểm tra lại giỏ hàng.\"}");
            return;
        }

        String redirectUrl = req.getContextPath() + "/user/order?id=" + orderId;
        resp.setStatus(HttpServletResponse.SC_OK);
        resp.getWriter().write("{\"orderId\":" + orderId + ",\"redirectUrl\":\"" + escapeJson(redirectUrl) + "\"}");
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}