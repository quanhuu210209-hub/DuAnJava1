package Servlet.user;

import DAO.user.CustomerDAO;
import DAO.user.CustomerWarrantyDAO;
import Model.user.Customer;
import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Khách gửi và theo dõi yêu cầu bảo hành / đổi / trả. URL: /user/warranty */
@WebServlet("/user/warranty")
public class UserWarrantyServlet extends HttpServlet {

    private final CustomerWarrantyDAO dao = new CustomerWarrantyDAO();
    private final CustomerDAO customerDAO = new CustomerDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Customer customer = requireCustomer(req, resp);
        if (customer == null) return;
        ServletUtils.loadFlash(req);
        req.setAttribute("lines", dao.findPurchasedLines(customer.getCustomerId()));
        req.setAttribute("requests", dao.findByCustomer(customer.getCustomerId()));
        ServletUtils.forward(req, resp, "/user/order/warranty.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        Customer customer = requireCustomer(req, resp);
        if (customer == null) return;
        User me = ServletUtils.currentUser(req);

        String error = dao.submit(customer.getCustomerId(), me.getUserId(),
                ServletUtils.parseInt(req.getParameter("orderDetailId"), 0),
                ServletUtils.trim(req.getParameter("requestType")),
                ServletUtils.parseInt(req.getParameter("quantity"), 1),
                ServletUtils.trim(req.getParameter("reason")));
        if (error == null) ServletUtils.setFlash(req, "success", "Đã gửi yêu cầu, cửa hàng sẽ liên hệ với bạn sớm");
        else ServletUtils.setFlash(req, "danger", error);
        ServletUtils.redirect(req, resp, "/user/warranty");
    }

    private Customer requireCustomer(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User me = ServletUtils.currentUser(req);
        Customer c = me == null ? null : customerDAO.findByUserId(me.getUserId());
        if (c == null) {
            ServletUtils.setFlash(req, "warning", "Tài khoản chưa có hồ sơ khách hàng");
            ServletUtils.redirect(req, resp, "/home");
        }
        return c;
    }
}
