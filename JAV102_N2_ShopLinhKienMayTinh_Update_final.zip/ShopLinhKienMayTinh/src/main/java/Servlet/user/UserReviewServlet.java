package Servlet.user;

import DAO.user.CustomerDAO;
import DAO.user.ReviewDAO;
import Model.admin.Product;
import Model.user.Customer;
import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Khách đánh giá sản phẩm đã mua. URL: /user/review (danh sách) hoặc /user/review?productId= */
@WebServlet("/user/review")
public class UserReviewServlet extends HttpServlet {

    private final ReviewDAO reviewDAO = new ReviewDAO();
    private final CustomerDAO customerDAO = new CustomerDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Customer customer = requireCustomer(req, resp);
        if (customer == null) return;
        ServletUtils.loadFlash(req);

        int productId = ServletUtils.parseInt(req.getParameter("productId"), 0);
        Product product = productId > 0 ? reviewDAO.findProduct(productId) : null;
        if (product == null) {
            req.setAttribute("products", reviewDAO.findPurchasedProducts(customer.getCustomerId()));
        } else {
            boolean bought = reviewDAO.hasPurchased(customer.getCustomerId(), productId);
            boolean reviewed = reviewDAO.hasReviewed(customer.getCustomerId(), productId);
            req.setAttribute("product", product);
            req.setAttribute("rating", reviewDAO.getRating(productId));
            req.setAttribute("reviews", reviewDAO.findVisibleByProduct(productId));
            req.setAttribute("canReview", bought && !reviewed);
            req.setAttribute("reviewNote", !bought ? "Bạn cần mua sản phẩm này để đánh giá." : reviewed ? "Bạn đã đánh giá sản phẩm này." : "");
        }
        ServletUtils.forward(req, resp, "/user/order/review.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        Customer customer = requireCustomer(req, resp);
        if (customer == null) return;

        int productId = ServletUtils.parseInt(req.getParameter("productId"), 0);
        int rating = ServletUtils.parseInt(req.getParameter("rating"), 0);
        String comment = ServletUtils.trim(req.getParameter("comment"));
        boolean ok = productId > 0 && reviewDAO.submit(customer.getCustomerId(), productId, rating, comment);
        ServletUtils.setFlash(req, ok ? "success" : "danger",
                ok ? "Cảm ơn bạn đã đánh giá sản phẩm" : "Không thể gửi đánh giá (cần đã mua sản phẩm và chưa đánh giá trước đó)");
        ServletUtils.redirect(req, resp, "/user/review?productId=" + productId);
    }

    private Customer requireCustomer(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User me = ServletUtils.currentUser(req);
        Customer c = me == null ? null : customerDAO.findByUserId(me.getUserId());
        if (c == null) {
            ServletUtils.setFlash(req, "warning", "Tài khoản chưa có hồ sơ khách hàng");
            ServletUtils.redirect(req, resp, "/home");
        }
        return c;
    }
}
