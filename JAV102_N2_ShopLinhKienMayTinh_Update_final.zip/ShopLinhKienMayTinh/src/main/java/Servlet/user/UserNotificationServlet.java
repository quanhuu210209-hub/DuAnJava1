package Servlet.user;

import DAO.user.NotificationDAO;
import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Khách xem và đánh dấu đã đọc thông báo của mình. URL: /user/notifications (POST: id hoặc action=all) */
@WebServlet("/user/notifications")
public class UserNotificationServlet extends HttpServlet {

    private final NotificationDAO dao = new NotificationDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        ServletUtils.loadFlash(req);
        req.setAttribute("notifications", dao.findByUser(me.getUserId()));
        req.setAttribute("unreadCount", dao.countUnread(me.getUserId()));
        ServletUtils.forward(req, resp, "/user/order/notifications.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        if ("all".equals(req.getParameter("action"))) {
            dao.markAllRead(me.getUserId());
        } else {
            int id = ServletUtils.parseInt(req.getParameter("id"), 0);
            if (id > 0) dao.markRead(id, me.getUserId());
        }
        ServletUtils.redirect(req, resp, "/user/notifications");
    }
}
