package Servlet.user;

import DAO.user.CartDAO;
import Model.admin.Product;
import Model.user.CartItem;
import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/**
 * API giỏ hàng (trả JSON) cho khách hàng. URL: /user/cart
 * GET: xem giỏ. POST action = add | qty | remove | clear (kèm productId, qty); luôn trả lại giỏ mới.
 * Quyền CUSTOMER do AuthFilter kiểm tra.
 */
@WebServlet("/user/cart")
public class UserCartServlet extends HttpServlet {

    private static final int MAX_QTY = 99;
    private final CartDAO cartDAO = new CartDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer customerId = customerId(req, resp);
        if (customerId != null) writeCart(resp, customerId);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer customerId = customerId(req, resp);
        if (customerId == null) return;

        String action = ServletUtils.trim(req.getParameter("action"));
        int productId = ServletUtils.parseInt(req.getParameter("productId"), 0);
        int qty = Math.min(ServletUtils.parseInt(req.getParameter("qty"), 1), MAX_QTY);

        boolean ok = switch (action) {
            case "add" -> productId > 0 && qty > 0 && cartDAO.add(customerId, productId, qty);
            case "qty" -> productId > 0 && cartDAO.setQuantity(customerId, productId, qty);
            case "remove" -> productId > 0 && cartDAO.remove(customerId, productId);
            case "clear" -> cartDAO.clear(customerId);
            default -> false;
        };
        if (!ok) {
            error(resp, HttpServletResponse.SC_BAD_REQUEST, "Không thực hiện được thao tác với giỏ hàng.");
            return;
        }
        writeCart(resp, customerId);
    }

    /** Mã khách của tài khoản đang đăng nhập; nếu chưa có hồ sơ khách thì trả lỗi JSON và trả về null. */
    private Integer customerId(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User u = ServletUtils.currentUser(req);
        Integer id = u == null ? null : cartDAO.customerIdOf(u.getUserId());
        if (id == null) error(resp, HttpServletResponse.SC_NOT_FOUND, "Tài khoản chưa có hồ sơ khách hàng.");
        return id;
    }

    private void writeCart(HttpServletResponse resp, int customerId) throws IOException {
        List<CartItem> items = cartDAO.items(customerId);
        StringBuilder sb = new StringBuilder("{\"items\":[");
        for (int i = 0; i < items.size(); i++) {
            CartItem it = items.get(i);
            Product p = it.getProduct();
            if (i > 0) sb.append(',');
            sb.append("{\"id\":").append(p.getProductId())
              .append(",\"name\":").append(str(p.getProductName()))
              .append(",\"sku\":").append(str(p.getSku()))
              .append(",\"price\":").append(p.getPrice() == null ? "0" : p.getPrice().toPlainString())
              .append(",\"image\":").append(str(p.getThumbnailUrl()))
              .append(",\"quantity\":").append(it.getQuantity()).append('}');
        }
        json(resp, HttpServletResponse.SC_OK, sb.append("]}").toString());
    }

    private void error(HttpServletResponse resp, int status, String msg) throws IOException {
        json(resp, status, "{\"error\":" + str(msg) + "}");
    }

    private void json(HttpServletResponse resp, int status, String body) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json;charset=UTF-8");
        resp.getWriter().write(body);
    }

    /** Chuỗi JSON đã escape. */
    private static String str(String s) {
        if (s == null) return "\"\"";
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> sb.append(c < 0x20 ? String.format("\\u%04x", (int) c) : String.valueOf(c));
            }
        }
        return sb.append('"').toString();
    }
}
