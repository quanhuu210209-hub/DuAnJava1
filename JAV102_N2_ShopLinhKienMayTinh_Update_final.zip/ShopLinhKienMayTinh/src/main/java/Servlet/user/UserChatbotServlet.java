package Servlet.user;

import DAO.user.ChatbotDAO;
import DAO.user.CustomerDAO;
import Model.user.Customer;
import Model.user.User;
import Servlet.common.ServletUtils;
import Util.OrderConst;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/** Chatbot tư vấn. GET: trang chat. POST (message=...): trả JSON {"answer":"..."} */
@WebServlet("/user/chatbot")
public class UserChatbotServlet extends HttpServlet {

    private static final String FALLBACK =
            "Xin lỗi, mình chưa có câu trả lời cho câu hỏi này. Bạn vui lòng liên hệ nhân viên cửa hàng để được hỗ trợ.";

    private final ChatbotDAO dao = new ChatbotDAO();
    private final CustomerDAO customerDAO = new CustomerDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ServletUtils.forward(req, resp, "/user/order/chatbot.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");

        String msg = ServletUtils.trim(req.getParameter("message"));
        if (msg.isEmpty()) { resp.getWriter().write("{\"answer\":\"\"}"); return; }
        if (msg.length() > 500) msg = msg.substring(0, 500);

        String answer = dao.findAnswer(msg);
        if (answer == null) answer = FALLBACK;

        // Lưu lịch sử chat; lỗi lưu không được làm hỏng câu trả lời
        try {
            HttpSession session = req.getSession();
            Integer sid = (Integer) session.getAttribute("chatSessionId");
            if (sid == null) {
                User me = ServletUtils.currentUser(req);
                Customer c = me == null ? null : customerDAO.findByUserId(me.getUserId());
                if (c != null) {
                    int created = dao.createSession(c.getCustomerId(), session.getId());
                    if (created > 0) { sid = created; session.setAttribute("chatSessionId", sid); }
                }
            }
            if (sid != null) {
                dao.saveMessage(sid, OrderConst.CHAT_USER, msg);
                dao.saveMessage(sid, OrderConst.CHAT_BOT, answer);
            }
        } catch (RuntimeException ex) {
            ex.printStackTrace();
        }
        resp.getWriter().write("{\"answer\":\"" + escapeJson(answer) + "\"}");
    }

    private static String escapeJson(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            switch (ch) {
                case '\\': sb.append("\\\\"); break;
                case '"':  sb.append("\\\""); break;
                case '\n': sb.append("\\n"); break;
                case '\r': break;
                case '\t': sb.append("\\t"); break;
                default:   if (ch < 0x20) sb.append(' '); else sb.append(ch);
            }
        }
        return sb.toString();
    }
}
