package Servlet.user;

import DAO.user.CustomerAddressDAO;
import DAO.user.CustomerDAO;
import Model.user.Customer;
import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Sổ địa chỉ nhận hàng. URL: /user/address (POST action = add | default | delete) */
@WebServlet("/user/address")
public class UserAddressServlet extends HttpServlet {

    private final CustomerAddressDAO dao = new CustomerAddressDAO();
    private final CustomerDAO customerDAO = new CustomerDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Customer customer = requireCustomer(req, resp);
        if (customer == null) return;
        ServletUtils.loadFlash(req);
        req.setAttribute("addresses", dao.findByCustomer(customer.getCustomerId()));
        ServletUtils.forward(req, resp, "/user/order/address.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        Customer customer = requireCustomer(req, resp);
        if (customer == null) return;
        int cid = customer.getCustomerId();
        String action = ServletUtils.trim(req.getParameter("action"));
        int id = ServletUtils.parseInt(req.getParameter("id"), 0);

        boolean ok;
        String msg;
        switch (action) {
            case "add":
                ok = dao.add(cid, req.getParameter("receiverName"), req.getParameter("phone"),
                        req.getParameter("addressLine"), req.getParameter("makeDefault") != null);
                msg = ok ? "Đã thêm địa chỉ" : "Vui lòng nhập đủ tên, số điện thoại và địa chỉ";
                break;
            case "default":
                ok = dao.setDefault(id, cid);
                msg = ok ? "Đã đặt địa chỉ mặc định" : "Không tìm thấy địa chỉ";
                break;
            case "delete":
                ok = dao.remove(id, cid);
                msg = ok ? "Đã xóa địa chỉ" : "Không tìm thấy địa chỉ";
                break;
            default:
                ok = false;
                msg = "Thao tác không hợp lệ";
        }
        ServletUtils.setFlash(req, ok ? "success" : "danger", msg);
        ServletUtils.redirect(req, resp, "/user/address");
    }

    private Customer requireCustomer(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User me = ServletUtils.currentUser(req);
        Customer c = me == null ? null : customerDAO.findByUserId(me.getUserId());
        if (c == null) {
            ServletUtils.setFlash(req, "warning", "Tài khoản chưa có hồ sơ khách hàng");
            ServletUtils.redirect(req, resp, "/home");
        }
        return c;
    }
}
