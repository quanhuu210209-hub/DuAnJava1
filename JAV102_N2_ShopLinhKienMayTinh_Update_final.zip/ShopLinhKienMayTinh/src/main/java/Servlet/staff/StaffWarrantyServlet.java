package Servlet.staff;

import DAO.staff.WarrantyDAO;
import DAO.user.OrderDAO;
import Model.staff.WarrantyRequest;
import Model.user.Order;
import Model.user.OrderDetail;
import Model.user.User;
import Servlet.common.ServletUtils;
import Util.OrderConst;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

/**
 * Tiếp nhận bảo hành / đổi trả tại quầy. URL: /staff/warranty?action=list|form|detail&id=&q=&key=
 * form: tra cứu hóa đơn (số hóa đơn hoặc mã đơn) rồi chọn sản phẩm. POST: ghi nhận yêu cầu (trạng thái chờ quản lý xử lý).
 * Quản lý chi nhánh sẽ duyệt / từ chối / hoàn tiền ở chức năng của quản lý.
 */
@WebServlet("/staff/warranty")
public class StaffWarrantyServlet extends HttpServlet {

    private static final String LIST   = "/staff/warranty/list.jsp";
    private static final String FORM   = "/staff/warranty/form.jsp";
    private static final String DETAIL = "/staff/warranty/detail.jsp";
    private static final String URL    = "/staff/warranty";
    private static final List<String> TYPES =
            Arrays.asList(OrderConst.TYPE_WARRANTY, OrderConst.TYPE_RETURN, OrderConst.TYPE_EXCHANGE);

    private static final java.util.Map<String, String> TYPE_LABELS = new java.util.LinkedHashMap<>();
    static {
        TYPE_LABELS.put(OrderConst.TYPE_WARRANTY, "Bảo hành");
        TYPE_LABELS.put(OrderConst.TYPE_RETURN, "Trả hàng");
        TYPE_LABELS.put(OrderConst.TYPE_EXCHANGE, "Đổi hàng");
    }

    private final WarrantyDAO dao = new WarrantyDAO();
    private final OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        String action = ServletUtils.trim(req.getParameter("action"));
        req.setAttribute("types", TYPE_LABELS);

        if ("form".equals(action)) {
            String key = ServletUtils.trim(req.getParameter("key"));
            req.setAttribute("key", key);
            if (!key.isEmpty()) {
                Order o = orderDAO.findByInvoiceOrCode(key);
                if (o == null) {
                    req.setAttribute("notFound", true);
                } else {
                    req.setAttribute("order", o);
                    req.setAttribute("rows", describe(o));
                }
            }
            ServletUtils.forward(req, resp, FORM);
            return;
        }

        if ("detail".equals(action)) {
            WarrantyRequest w = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
            if (!canAccess(me, w)) {
                ServletUtils.setFlash(req, "danger", "Không tìm thấy yêu cầu hoặc bạn không có quyền xem");
                ServletUtils.redirect(req, resp, URL);
                return;
            }
            ServletUtils.loadFlash(req);
            req.setAttribute("request", w);
            ServletUtils.forward(req, resp, DETAIL);
            return;
        }

        ServletUtils.loadFlash(req);
        String status = ServletUtils.trim(req.getParameter("status"));
        String q = ServletUtils.trim(req.getParameter("q"));
        req.setAttribute("requests", dao.search("ADMIN".equals(me.getRoleCode()) ? null : me.getBranchId(), status, q));
        req.setAttribute("status", status);
        req.setAttribute("q", q);
        ServletUtils.forward(req, resp, LIST);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        if (me.getBranchId() == null) {
            ServletUtils.setFlash(req, "danger", "Tài khoản chưa gắn chi nhánh nên không tiếp nhận được yêu cầu");
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        String key = ServletUtils.trim(req.getParameter("key"));
        String formUrl = URL + "?action=form&key=" + java.net.URLEncoder.encode(key, java.nio.charset.StandardCharsets.UTF_8);
        int detailId = ServletUtils.parseInt(req.getParameter("orderDetailId"), 0);
        int qty = ServletUtils.parseInt(req.getParameter("quantity"), 0);
        String type = ServletUtils.trim(req.getParameter("requestType"));
        String reason = ServletUtils.trim(req.getParameter("reason"));

        Order o = orderDAO.findByInvoiceOrCode(key);
        OrderDetail line = o == null ? null : o.getDetails().stream()
                .filter(d -> d.getOrderDetailId() == detailId).findFirst().orElse(null);

        Validator v = new Validator().required("reason", reason, "Lý do").maxLength("reason", reason, 1000, "Lý do");
        String error = null;
        if (line == null) error = "Vui lòng chọn sản phẩm cần bảo hành / đổi trả";
        else if (o.getCustomer() == null) error = "Đơn hàng này chưa gắn khách hàng";
        else if (!"Completed".equals(o.getStatus())) error = "Chỉ tiếp nhận cho đơn đã hoàn tất";
        else if (!TYPES.contains(type)) error = "Vui lòng chọn loại yêu cầu";
        else if (!v.isValid()) error = v.getErrors().get("reason");
        else if (qty < 1 || qty > line.getQuantity() - dao.requestedQuantity(detailId))
            error = "Số lượng không hợp lệ (tối đa " + (line.getQuantity() - dao.requestedQuantity(detailId)) + ")";
        else if (OrderConst.TYPE_WARRANTY.equals(type) && !stillCovered(o, line))
            error = "Sản phẩm đã hết thời hạn bảo hành";

        if (error != null) {
            ServletUtils.setFlash(req, "danger", error);
            ServletUtils.redirect(req, resp, formUrl);
            return;
        }

        int id = dao.receive(me.getBranchId(), me.getUserId(), detailId, o.getCustomer().getCustomerId(), type, qty, reason);
        if (id == 0) {
            ServletUtils.setFlash(req, "danger", "Không lưu được yêu cầu (xem log Tomcat nếu lỗi lặp lại)");
            ServletUtils.redirect(req, resp, formUrl);
        } else {
            ServletUtils.setFlash(req, "success", "Đã tiếp nhận yêu cầu, chuyển quản lý chi nhánh xử lý");
            ServletUtils.redirect(req, resp, URL + "?action=detail&id=" + id);
        }
    }

    /** Hạn bảo hành = ngày hoàn tất đơn (hoặc ngày tạo) + số tháng bảo hành của dòng hàng. */
    static LocalDateTime warrantyEnd(Order o, OrderDetail d) {
        LocalDateTime from = o.getCompletedAt() != null ? o.getCompletedAt() : o.getCreatedAt();
        return from.plusMonths(d.getWarrantyMonths());
    }

    private boolean stillCovered(Order o, OrderDetail d) {
        return warrantyEnd(o, d).isAfter(LocalDateTime.now());
    }

    /** Dòng hiển thị cho từng sản phẩm: hạn bảo hành, số lượng còn có thể yêu cầu. */
    private List<Object[]> describe(Order o) {
        return o.getDetails().stream().map(d -> new Object[]{
                d, warrantyEnd(o, d), d.getQuantity() - dao.requestedQuantity(d.getOrderDetailId())
        }).toList();
    }

    private boolean canAccess(User me, WarrantyRequest w) {
        if (w == null) return false;
        return "ADMIN".equals(me.getRoleCode())
                || (me.getBranchId() != null && me.getBranchId() == w.getBranch().getBranchId());
    }
}
