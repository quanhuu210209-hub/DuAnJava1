package Servlet.staff;

import DAO.staff.InvoiceDAO;
import DAO.user.OrderDAO;
import Model.staff.Invoice;
import Model.user.Order;
import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Xuất, tra cứu và in hóa đơn. URL: /staff/invoice?action=list|print&id=&q=
 * POST action=issue&orderId=: xuất hóa đơn cho đơn đã thanh toán (đơn đã có hóa đơn thì dùng lại).
 * Quản lý và nhân viên chỉ thao tác hóa đơn của chi nhánh mình.
 */
@WebServlet("/staff/invoice")
public class StaffInvoiceServlet extends HttpServlet {

    private static final String LIST  = "/staff/invoice/list.jsp";
    private static final String PRINT = "/staff/invoice/print.jsp";
    private static final String URL   = "/staff/invoice";

    private final InvoiceDAO dao = new InvoiceDAO();
    private final OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);

        if ("print".equals(ServletUtils.trim(req.getParameter("action")))) {
            int id = ServletUtils.parseInt(req.getParameter("id"), 0);
            Invoice inv = dao.findFull(id);
            if (inv == null || !canAccess(me, inv.getSalesOrder())) {
                ServletUtils.setFlash(req, "danger", "Không tìm thấy hóa đơn hoặc bạn không có quyền xem");
                ServletUtils.redirect(req, resp, URL);
                return;
            }
            dao.markPrinted(id);
            inv = dao.findFull(id);   // lấy lại để có số lần in mới
            req.setAttribute("invoice", inv);
            req.setAttribute("payments", dao.paymentsOf(inv.getSalesOrder().getOrderId()));
            ServletUtils.forward(req, resp, PRINT);
            return;
        }

        ServletUtils.loadFlash(req);
        String q = ServletUtils.trim(req.getParameter("q"));
        req.setAttribute("q", q);
        req.setAttribute("invoices", dao.search("ADMIN".equals(me.getRoleCode()) ? null : me.getBranchId(), q));
        ServletUtils.forward(req, resp, LIST);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        int orderId = ServletUtils.parseInt(req.getParameter("orderId"), 0);
        Order o = orderDAO.findById(orderId);
        String back = "/staff/order?action=detail&id=" + orderId;

        if (!canAccess(me, o)) {
            ServletUtils.setFlash(req, "danger", "Không tìm thấy đơn hàng hoặc bạn không có quyền thao tác");
            ServletUtils.redirect(req, resp, "/staff/order");
        } else if ("Pending".equals(o.getStatus()) || "Cancelled".equals(o.getStatus())) {
            ServletUtils.setFlash(req, "danger", "Chỉ xuất hóa đơn cho đơn đã thanh toán");
            ServletUtils.redirect(req, resp, back);
        } else {
            Invoice inv = dao.issue(orderId, me.getUserId());
            if (inv == null) {
                ServletUtils.setFlash(req, "danger", "Không xuất được hóa đơn");
                ServletUtils.redirect(req, resp, back);
            } else {
                ServletUtils.redirect(req, resp, URL + "?action=print&id=" + inv.getInvoiceId());
            }
        }
    }

    private boolean canAccess(User me, Order o) {
        if (o == null) return false;
        return "ADMIN".equals(me.getRoleCode())
                || (me.getBranchId() != null && me.getBranchId() == o.getBranch().getBranchId());
    }
}
