package Servlet.staff;

import DAO.manager.BranchInventoryDAO;
import DAO.user.OrderDAO;
import Model.manager.BranchInventory;
import Model.user.Order;
import Model.user.OrderDetail;
import Model.user.User;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Xử lý đơn hàng cho ADMIN / MANAGER / STAFF. URL: /staff/order?action=list|detail&id=&status=&channel=&q=
 * POST: status (đổi trạng thái, xuất kho khi chuyển Paid -> Shipping/Completed) | cancel (hủy đơn).
 * Quản lý và nhân viên chỉ thao tác được đơn thuộc chi nhánh của mình.
 */
@WebServlet("/staff/order")
public class StaffOrderServlet extends HttpServlet {

    private static final String LIST   = "/staff/order/list.jsp";
    private static final String DETAIL = "/staff/order/detail.jsp";
    private static final String URL    = "/staff/order";
    private static final List<String> STATUSES =
            Arrays.asList("Pending", "Paid", "Shipping", "Completed", "Cancelled");

    private final OrderDAO dao = new OrderDAO();
    private final BranchInventoryDAO stockDAO = new BranchInventoryDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        String action = ServletUtils.trim(req.getParameter("action"));

        if ("detail".equals(action)) {
            Order o = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
            if (!canAccess(me, o)) {
                ServletUtils.setFlash(req, "danger", "Không tìm thấy đơn hàng hoặc bạn không có quyền xem");
                ServletUtils.redirect(req, resp, URL);
                return;
            }
            ServletUtils.loadFlash(req);
            req.setAttribute("order", o);
            req.setAttribute("nextStatuses", nextStatuses(o.getStatus()));
            req.setAttribute("stock", stockDAO.inventoryMap(o.getBranch().getBranchId()));
            ServletUtils.forward(req, resp, DETAIL);
            return;
        }

        ServletUtils.loadFlash(req);
        String status = ServletUtils.trim(req.getParameter("status"));
        if (!STATUSES.contains(status)) status = null;
        String channel = ServletUtils.trim(req.getParameter("channel"));
        String q = ServletUtils.trim(req.getParameter("q"));
        req.setAttribute("orders", dao.search(branchScope(me), status, channel, q));
        req.setAttribute("status", status);
        req.setAttribute("channel", channel);
        req.setAttribute("q", q);
        ServletUtils.forward(req, resp, LIST);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        int id = ServletUtils.parseInt(req.getParameter("id"), 0);
        String action = ServletUtils.trim(req.getParameter("action"));
        String back = URL + "?action=detail&id=" + id;

        Order o = dao.findById(id);
        if (!canAccess(me, o)) {
            ServletUtils.setFlash(req, "danger", "Không tìm thấy đơn hàng hoặc bạn không có quyền thao tác");
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        if ("cancel".equals(action)) {
            String reason = ServletUtils.trim(req.getParameter("reason"));
            Validator v = new Validator()
                    .required("reason", reason, "Lý do hủy")
                    .maxLength("reason", reason, 255, "Lý do hủy");
            if (!v.isValid()) {
                ServletUtils.setFlash(req, "danger", v.getErrors().get("reason"));
            } else if (dao.cancel(id, me.getUserId(), reason)) {
                ServletUtils.setFlash(req, "success", "Đã hủy đơn hàng");
            } else {
                ServletUtils.setFlash(req, "danger", "Chỉ hủy được đơn đang ở trạng thái Pending hoặc Paid");
            }
            ServletUtils.redirect(req, resp, back);
            return;
        }

        // action = status: chỉ cho chuyển sang trạng thái kế tiếp hợp lệ
        String newStatus = ServletUtils.trim(req.getParameter("status"));
        if (!nextStatuses(o.getStatus()).contains(newStatus)) {
            ServletUtils.setFlash(req, "danger", "Không thể chuyển từ " + o.getStatus() + " sang " + newStatus);
        } else {
            String shortage = "Paid".equals(o.getStatus()) && !"Cancelled".equals(newStatus) ? shortage(o) : null;
            if (shortage != null) {
                ServletUtils.setFlash(req, "danger", shortage);
            } else if (dao.updateStatus(id, newStatus, me.getUserId())) {
                ServletUtils.setFlash(req, "success", "Đã cập nhật trạng thái đơn hàng");
            } else {
                ServletUtils.setFlash(req, "danger", "Cập nhật thất bại");
            }
        }
        ServletUtils.redirect(req, resp, back);
    }

    /** Thông báo thiếu hàng tại chi nhánh xử lý đơn; null nếu đủ hàng cho mọi dòng. */
    private String shortage(Order o) {
        Map<Integer, BranchInventory> stock = stockDAO.inventoryMap(o.getBranch().getBranchId());
        for (OrderDetail d : o.getDetails()) {
            BranchInventory inv = stock.get(d.getProduct().getProductId());
            int have = inv == null || inv.isHidden() ? 0 : inv.getQuantity();
            if (have < d.getQuantity()) {
                return "Không đủ tồn kho cho " + d.getProduct().getProductName()
                        + " (cần " + d.getQuantity() + ", chi nhánh còn " + have + ")";
            }
        }
        return null;
    }

    /** ADMIN thấy tất cả (null); MANAGER/STAFF chỉ thấy chi nhánh của mình. */
    private Integer branchScope(User me) {
        return "ADMIN".equals(me.getRoleCode()) ? null : me.getBranchId();
    }

    private boolean canAccess(User me, Order o) {
        if (o == null) return false;
        return "ADMIN".equals(me.getRoleCode())
                || (me.getBranchId() != null && me.getBranchId() == o.getBranch().getBranchId());
    }

    /** Luồng trạng thái hợp lệ. */
    private List<String> nextStatuses(String current) {
        switch (current) {
            case "Pending":  return Arrays.asList("Paid");
            case "Paid":     return Arrays.asList("Shipping", "Completed");
            case "Shipping": return Arrays.asList("Completed");
            default:         return Arrays.asList();
        }
    }
}
