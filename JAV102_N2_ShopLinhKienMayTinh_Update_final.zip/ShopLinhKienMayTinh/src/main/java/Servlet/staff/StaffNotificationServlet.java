package Servlet.staff;

import DAO.manager.BranchInventoryDAO;
import DAO.user.NotificationDAO;
import DAO.user.OrderDAO;
import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Thông báo cho nhân viên. URL: /staff/notification. POST action = read (id) | readAll.
 * Gồm: thông báo gửi riêng cho tài khoản (ví dụ từ quản lý chi nhánh) và hai cảnh báo tính trực tiếp từ dữ liệu:
 * đơn online đang chờ xử lý và sản phẩm sắp hết hàng tại chi nhánh.
 */
@WebServlet("/staff/notification")
public class StaffNotificationServlet extends HttpServlet {

    private static final String LIST = "/staff/notification/list.jsp";
    private static final String URL  = "/staff/notification";

    private final NotificationDAO dao = new NotificationDAO();
    private final OrderDAO orderDAO = new OrderDAO();
    private final BranchInventoryDAO stockDAO = new BranchInventoryDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        ServletUtils.loadFlash(req);
        req.setAttribute("notifications", dao.findByUser(me.getUserId()));
        req.setAttribute("unread", dao.countUnread(me.getUserId()));
        if (me.getBranchId() != null) {
            req.setAttribute("pendingOnline", orderDAO.countPendingOnline(me.getBranchId()));
            req.setAttribute("lowStock", stockDAO.lowStock(me.getBranchId()));
        }
        ServletUtils.forward(req, resp, LIST);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        if ("readAll".equals(ServletUtils.trim(req.getParameter("action")))) {
            dao.markAllRead(me.getUserId());
        } else {
            dao.markRead(ServletUtils.parseInt(req.getParameter("id"), 0), me.getUserId());
        }
        ServletUtils.redirect(req, resp, URL);
    }
}
