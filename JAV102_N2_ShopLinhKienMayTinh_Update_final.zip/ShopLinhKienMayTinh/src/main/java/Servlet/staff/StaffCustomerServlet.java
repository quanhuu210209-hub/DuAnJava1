package Servlet.staff;

import DAO.user.CustomerDAO;
import DAO.user.OrderDAO;
import Model.user.Customer;
import Model.user.User;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDateTime;

/**
 * Tạo và tra cứu khách hàng tại quầy. URL: /staff/customer?action=list|form|detail&id=&q=
 * POST: tạo khách mới (không cần tài khoản website).
 */
@WebServlet("/staff/customer")
public class StaffCustomerServlet extends HttpServlet {

    private static final String LIST   = "/staff/customer/list.jsp";
    private static final String FORM   = "/staff/customer/form.jsp";
    private static final String DETAIL = "/staff/customer/detail.jsp";
    private static final String URL    = "/staff/customer";

    private final CustomerDAO dao = new CustomerDAO();
    private final OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));

        if ("form".equals(action)) {
            ServletUtils.forward(req, resp, FORM);
            return;
        }
        if ("detail".equals(action)) {
            Customer c = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
            if (c == null) {
                ServletUtils.setFlash(req, "danger", "Không tìm thấy khách hàng");
                ServletUtils.redirect(req, resp, URL);
                return;
            }
            ServletUtils.loadFlash(req);
            req.setAttribute("customer", c);
            req.setAttribute("orders", orderDAO.findByCustomer(c.getCustomerId()));
            ServletUtils.forward(req, resp, DETAIL);
            return;
        }

        ServletUtils.loadFlash(req);
        String q = ServletUtils.trim(req.getParameter("q"));
        req.setAttribute("q", q);
        req.setAttribute("customers", q.isEmpty() ? dao.recent(30) : dao.search(q));
        ServletUtils.forward(req, resp, LIST);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        String fullName = ServletUtils.trim(req.getParameter("fullName"));
        String phone = ServletUtils.trim(req.getParameter("phone"));
        String email = ServletUtils.trim(req.getParameter("email"));

        Validator v = new Validator()
                .required("fullName", fullName, "Họ tên").maxLength("fullName", fullName, 100, "Họ tên")
                .required("phone", phone, "Số điện thoại").phone("phone", phone);
        if (!email.isEmpty()) v.maxLength("email", email, 150, "Email").email("email", email);
        if (v.isValid() && dao.findByPhone(phone) != null) v.error("phone", "Số điện thoại này đã có trong hệ thống");

        if (!v.isValid()) {
            req.setAttribute("errors", v.getErrors());
            req.setAttribute("fullName", fullName);
            req.setAttribute("phone", phone);
            req.setAttribute("email", email);
            ServletUtils.forward(req, resp, FORM);
            return;
        }

        Customer c = new Customer();
        c.setFullName(fullName);
        c.setPhone(phone);
        c.setEmail(email.isEmpty() ? null : email);
        c.setCreatedBy(me);
        c.setCreatedAt(LocalDateTime.now());
        if (dao.insert(c)) {
            ServletUtils.setFlash(req, "success", "Đã tạo khách hàng " + fullName);
            ServletUtils.redirect(req, resp, URL + "?action=detail&id=" + c.getCustomerId());
        } else {
            ServletUtils.setFlash(req, "danger", "Không lưu được khách hàng");
            ServletUtils.redirect(req, resp, URL);
        }
    }
}
