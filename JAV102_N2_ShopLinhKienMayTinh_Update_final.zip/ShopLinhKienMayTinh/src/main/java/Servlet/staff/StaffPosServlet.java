package Servlet.staff;

import DAO.admin.PaymentMethodDAO;
import DAO.admin.ProductDAO;
import DAO.manager.BranchInventoryDAO;
import DAO.staff.InvoiceDAO;
import DAO.user.CustomerDAO;
import DAO.user.OrderDAO;
import Model.admin.PaymentMethod;
import Model.admin.Product;
import Model.dto.PosLine;
import Model.staff.Invoice;
import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Bán hàng tại quầy cho nhân viên (cần tài khoản có chi nhánh). URL: /staff/pos?q=&cq=
 * Giỏ và khách đang chọn lưu trong session. POST action = add | qty | remove | clear | customer | noCustomer | pay.
 */
@WebServlet("/staff/pos")
public class StaffPosServlet extends HttpServlet {

    private static final String VIEW = "/staff/pos/index.jsp";
    private static final String URL  = "/staff/pos";
    private static final String CART = "posCart";
    private static final String CUSTOMER = "posCustomerId";
    private static final int MAX_QTY = 99;

    private final ProductDAO productDAO = new ProductDAO();
    private final BranchInventoryDAO stockDAO = new BranchInventoryDAO();
    private final CustomerDAO customerDAO = new CustomerDAO();
    private final PaymentMethodDAO methodDAO = new PaymentMethodDAO();
    private final OrderDAO orderDAO = new OrderDAO();
    private final InvoiceDAO invoiceDAO = new InvoiceDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        if (me.getBranchId() == null) { noBranch(req, resp); return; }

        ServletUtils.loadFlash(req);
        String q = ServletUtils.trim(req.getParameter("q"));
        String cq = ServletUtils.trim(req.getParameter("cq"));
        if (!q.isEmpty()) {
            List<Product> found = productDAO.search(q, null, null, true);
            req.setAttribute("products", found.size() > 12 ? found.subList(0, 12) : found);
        }
        if (!cq.isEmpty()) req.setAttribute("customers", customerDAO.search(cq));

        List<PosLine> lines = lines(req);
        BigDecimal total = BigDecimal.ZERO;
        for (PosLine l : lines) total = total.add(l.getLineTotal());

        Integer cid = (Integer) req.getSession().getAttribute(CUSTOMER);
        req.setAttribute("customer", cid == null ? null : customerDAO.findById(cid));
        req.setAttribute("methods", methodDAO.findActive());
        req.setAttribute("stock", stockDAO.stockMap(me.getBranchId()));
        req.setAttribute("lines", lines);
        req.setAttribute("total", total);
        req.setAttribute("q", q);
        req.setAttribute("cq", cq);
        ServletUtils.forward(req, resp, VIEW);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        if (me.getBranchId() == null) { noBranch(req, resp); return; }

        HttpSession session = req.getSession();
        Map<Integer, Integer> cart = cart(req);
        String action = ServletUtils.trim(req.getParameter("action"));
        String q = ServletUtils.trim(req.getParameter("q"));
        int productId = ServletUtils.parseInt(req.getParameter("productId"), 0);
        int qty = Math.min(ServletUtils.parseInt(req.getParameter("qty"), 1), MAX_QTY);
        int have = productId > 0 ? stockDAO.quantity(me.getBranchId(), productId) : 0;

        switch (action) {
            case "add" -> {
                int want = cart.getOrDefault(productId, 0) + qty;
                if (productId <= 0 || qty <= 0) ServletUtils.setFlash(req, "danger", "Số lượng không hợp lệ");
                else if (want > have) ServletUtils.setFlash(req, "danger", "Chi nhánh chỉ còn " + have + " sản phẩm này");
                else cart.put(productId, want);
            }
            case "qty" -> {
                if (qty <= 0) cart.remove(productId);
                else if (qty > have) ServletUtils.setFlash(req, "danger", "Chi nhánh chỉ còn " + have + " sản phẩm này");
                else cart.put(productId, qty);
            }
            case "remove" -> cart.remove(productId);
            case "clear" -> { cart.clear(); session.removeAttribute(CUSTOMER); }
            case "customer" -> {
                int cid = ServletUtils.parseInt(req.getParameter("customerId"), 0);
                if (customerDAO.findById(cid) != null) session.setAttribute(CUSTOMER, cid);
            }
            case "noCustomer" -> session.removeAttribute(CUSTOMER);
            case "pay" -> { pay(req, resp, me, cart); return; }
            default -> { }
        }
        ServletUtils.redirect(req, resp, URL + (q.isEmpty() ? "" : "?q=" + URLEncoder.encode(q, StandardCharsets.UTF_8)));
    }

    /** Thanh toán: kiểm tra giỏ, khách, phương thức, tồn kho rồi tạo đơn + hóa đơn. */
    private void pay(HttpServletRequest req, HttpServletResponse resp, User me, Map<Integer, Integer> cart)
            throws IOException {
        HttpSession session = req.getSession();
        Integer cid = (Integer) session.getAttribute(CUSTOMER);
        int methodId = ServletUtils.parseInt(req.getParameter("paymentMethodId"), 0);
        String error = null;

        if (cart.isEmpty()) error = "Giỏ hàng đang trống";
        else if (cid == null) error = "Vui lòng chọn khách hàng trước khi thanh toán";
        else if (methodDAO.findActive().stream().noneMatch(m -> m.getPaymentMethodId() == methodId)) error = "Vui lòng chọn phương thức thanh toán";
        else {
            for (Map.Entry<Integer, Integer> e : cart.entrySet()) {
                if (stockDAO.quantity(me.getBranchId(), e.getKey()) < e.getValue()) {
                    Product p = productDAO.findById(e.getKey());
                    error = "Không đủ tồn kho cho " + (p == null ? "sản phẩm" : p.getProductName());
                    break;
                }
            }
        }
        if (error != null) {
            ServletUtils.setFlash(req, "danger", error);
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        int orderId = orderDAO.createCounterSale(me.getBranchId(), me.getUserId(), cid, methodId, new LinkedHashMap<>(cart));
        if (orderId == 0) {
            ServletUtils.setFlash(req, "danger", "Không lưu được đơn hàng, vui lòng thử lại (xem log Tomcat nếu lỗi lặp lại)");
            ServletUtils.redirect(req, resp, URL);
            return;
        }
        cart.clear();
        session.removeAttribute(CUSTOMER);
        Invoice inv = invoiceDAO.findByOrderId(orderId);
        ServletUtils.setFlash(req, "success", "Thanh toán thành công");
        ServletUtils.redirect(req, resp, inv == null
                ? "/staff/order?action=detail&id=" + orderId
                : "/staff/invoice?action=print&id=" + inv.getInvoiceId());
    }

    private void noBranch(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        ServletUtils.setFlash(req, "danger", "Tài khoản chưa gắn chi nhánh nên không bán hàng tại quầy được");
        ServletUtils.redirect(req, resp, "/staff/order");
    }

    /** Giỏ trong session: productId -> số lượng. */
    @SuppressWarnings("unchecked")
    private Map<Integer, Integer> cart(HttpServletRequest req) {
        HttpSession s = req.getSession();
        Map<Integer, Integer> cart = (Map<Integer, Integer>) s.getAttribute(CART);
        if (cart == null) { cart = new LinkedHashMap<>(); s.setAttribute(CART, cart); }
        return cart;
    }

    private List<PosLine> lines(HttpServletRequest req) {
        List<PosLine> out = new ArrayList<>();
        cart(req).entrySet().removeIf(e -> {
            Product p = productDAO.findById(e.getKey());
            if (p == null) return true;
            out.add(new PosLine(p, e.getValue()));
            return false;
        });
        return out;
    }
}
