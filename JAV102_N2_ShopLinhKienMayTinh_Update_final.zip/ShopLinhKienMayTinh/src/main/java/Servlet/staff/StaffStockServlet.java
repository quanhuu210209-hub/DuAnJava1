package Servlet.staff;

import DAO.admin.CategoryDAO;
import DAO.admin.ProductDAO;
import DAO.manager.BranchInventoryDAO;
import Model.admin.Product;
import Model.manager.BranchInventory;
import Model.user.User;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Tra cứu tồn kho và sản phẩm. URL: /staff/stock?action=list|detail&id=&q=&categoryId=
 * POST adjust (chỉ quản lý chi nhánh): điều chỉnh tồn theo số kiểm kê thực tế, có ghi lịch sử kho.
 */
@WebServlet("/staff/stock")
public class StaffStockServlet extends HttpServlet {

    private static final String LIST   = "/staff/stock/list.jsp";
    private static final String DETAIL = "/staff/stock/detail.jsp";
    private static final String URL    = "/staff/stock";

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final BranchInventoryDAO stockDAO = new BranchInventoryDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        Integer branchId = me.getBranchId();   // Admin không thuộc chi nhánh nào

        if ("detail".equals(ServletUtils.trim(req.getParameter("action")))) {
            int id = ServletUtils.parseInt(req.getParameter("id"), 0);
            Product p = productDAO.findById(id);
            if (p == null) {
                ServletUtils.setFlash(req, "danger", "Không tìm thấy sản phẩm");
                ServletUtils.redirect(req, resp, URL);
                return;
            }
            BranchInventory mine = branchId == null ? null : stockDAO.inventoryMap(branchId).get(id);
            ServletUtils.loadFlash(req);
            req.setAttribute("product", p);
            req.setAttribute("mine", mine);
            req.setAttribute("branches", stockDAO.byProduct(id));
            req.setAttribute("movements", stockDAO.movements(branchId, id, null, null, 10));
            req.setAttribute("canAdjust", mine != null && canAdjust(me));
            ServletUtils.forward(req, resp, DETAIL);
            return;
        }

        ServletUtils.loadFlash(req);
        String q = ServletUtils.trim(req.getParameter("q"));
        int categoryId = ServletUtils.parseInt(req.getParameter("categoryId"), 0);
        List<Product> products = productDAO.search(q, categoryId > 0 ? categoryId : null, null, true);
        Map<Integer, BranchInventory> inventory =
                branchId == null ? new HashMap<>() : stockDAO.inventoryMap(branchId);

        req.setAttribute("products", products.size() > 100 ? products.subList(0, 100) : products);
        req.setAttribute("inventory", inventory);
        req.setAttribute("categories", categoryDAO.findAll());
        req.setAttribute("q", q);
        req.setAttribute("categoryId", categoryId);
        ServletUtils.forward(req, resp, LIST);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        int id = ServletUtils.parseInt(req.getParameter("productId"), 0);
        String qty = ServletUtils.trim(req.getParameter("quantity"));
        String reason = ServletUtils.trim(req.getParameter("reason"));
        String back = URL + "?action=detail&id=" + id;

        Validator v = new Validator()
                .intRange("quantity", qty, 0, 100000, "Số lượng thực tế")
                .required("reason", reason, "Lý do điều chỉnh")
                .maxLength("reason", reason, 255, "Lý do điều chỉnh");

        if (!"adjust".equals(ServletUtils.trim(req.getParameter("action"))) || !canAdjust(me)) {
            ServletUtils.setFlash(req, "danger", "Chỉ quản lý chi nhánh mới được điều chỉnh tồn kho");
        } else if (!v.isValid()) {
            ServletUtils.setFlash(req, "danger", v.getErrors().values().iterator().next());
        } else if (stockDAO.adjust(me.getBranchId(), id, Integer.parseInt(qty), me.getUserId(), reason)) {
            ServletUtils.setFlash(req, "success", "Đã điều chỉnh tồn kho");
        } else {
            ServletUtils.setFlash(req, "danger", "Không điều chỉnh được (sản phẩm chưa có tồn tại chi nhánh hoặc số lượng không đổi)");
        }
        ServletUtils.redirect(req, resp, back);
    }

    /** Chỉ MANAGER có chi nhánh. Muốn cho cả STAFF thì thêm "STAFF" vào điều kiện. */
    private boolean canAdjust(User me) {
        return me.getBranchId() != null && "MANAGER".equals(me.getRoleCode());
    }
}
