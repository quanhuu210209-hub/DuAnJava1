package Servlet.common;

import DAO.user.UserDAO;
import Filter.AuthFilter;
import Model.user.User;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** Y1: đăng nhập. URL: /login */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final String VIEW = "/auth.jsp";
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User u = ServletUtils.currentUser(req);
        if (u != null) {                               // đã đăng nhập thì khỏi vào trang login
            ServletUtils.redirect(req, resp, ServletUtils.homeOf(u.getRoleCode()));
            return;
        }
        ServletUtils.loadFlash(req);
        ServletUtils.forward(req, resp, VIEW);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = ServletUtils.trim(req.getParameter("username"));   // email hoặc SĐT
        String password = req.getParameter("password");

        Validator v = new Validator()
                .required("username", username, "Email/Số điện thoại")
                .maxLength("username", username, 150, "Email/Số điện thoại")
                .required("password", password, "Mật khẩu");

        if (!v.isValid()) {
            req.setAttribute("errors", v.getErrors());
            req.setAttribute("username", username);
            ServletUtils.forward(req, resp, VIEW);
            return;
        }

        User user = userDAO.login(username, password);
        if (user == null) {
            // Thông báo chung, không tiết lộ tài khoản có tồn tại hay không
            req.setAttribute("loginError", "Sai tài khoản hoặc mật khẩu, hoặc tài khoản đã bị khóa");
            req.setAttribute("username", username);
            ServletUtils.forward(req, resp, VIEW);
            return;
        }

        // Chống session fixation: hủy session cũ, tạo session mới sau khi đăng nhập
        HttpSession old = req.getSession(false);
        String returnTo = old == null ? null : (String) old.getAttribute("returnTo");
        if (old != null) old.invalidate();

        user.setPasswordHash(null);                    // không giữ hash trong session
        HttpSession session = req.getSession(true);
        session.setMaxInactiveInterval(30 * 60);
        session.setAttribute(ServletUtils.SESSION_USER, user);

        // returnTo do AuthFilter lưu (không lấy từ người dùng) và phải hợp vai trò
        String target = (returnTo != null && returnTo.startsWith("/") && !returnTo.startsWith("//")
                && AuthFilter.isAllowed(returnTo.split("\\?")[0], user.getRoleCode()))
                ? returnTo : ServletUtils.homeOf(user.getRoleCode());
        ServletUtils.redirect(req, resp, target);
    }
}
