package Servlet.common;

import DAO.admin.BrandDAO;
import DAO.admin.CategoryDAO;
import DAO.admin.ProductDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** Trang chủ công khai: danh sách sản phẩm đang bán. URL: / hoặc /home */
@WebServlet(urlPatterns = {"", "/home"})
public class HomeServlet extends HttpServlet {

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final BrandDAO brandDAO = new BrandDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ServletUtils.loadFlash(req);
        String keyword = ServletUtils.trim(req.getParameter("keyword"));
        Integer categoryId = ServletUtils.parseIntOrNull(req.getParameter("categoryId"));
        Integer brandId = ServletUtils.parseIntOrNull(req.getParameter("brandId"));

        req.setAttribute("products", productDAO.search(keyword, categoryId, brandId, true));
        req.setAttribute("categories", categoryDAO.findAll());
        req.setAttribute("brands", brandDAO.findAll());
        req.setAttribute("keyword", keyword);
        req.setAttribute("categoryId", categoryId);
        req.setAttribute("brandId", brandId);
        ServletUtils.forward(req, resp, "/index.jsp");
    }
}
