package Servlet.common;

import DAO.user.UserDAO;
import Model.user.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/** Đăng ký tài khoản khách hàng. URL: /register */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private static final String VIEW = "/register.jsp";
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User u = ServletUtils.currentUser(req);
        if (u != null) {
            ServletUtils.redirect(req, resp, ServletUtils.homeOf(u.getRoleCode()));
            return;
        }
        ServletUtils.loadFlash(req);
        ServletUtils.forward(req, resp, VIEW);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        String fullName = ServletUtils.trim(req.getParameter("fullName"));
        String email = ServletUtils.trim(req.getParameter("email"));
        String phone = ServletUtils.trim(req.getParameter("phone"));
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("confirmPassword");

        Map<String, String> errors = new LinkedHashMap<>();

        if (fullName == null || fullName.isEmpty()) {
            errors.put("fullName", "Họ và tên không được để trống");
        } else if (fullName.length() > 100) {
            errors.put("fullName", "Họ và tên tối đa 100 ký tự");
        }

        boolean hasEmail = email != null && !email.isEmpty();
        boolean hasPhone = phone != null && !phone.isEmpty();

        if (!hasEmail && !hasPhone) {
            errors.put("contact", "Vui lòng nhập ít nhất Email hoặc Số điện thoại");
        }

        if (hasEmail) {
            if (email.length() > 150) {
                errors.put("email", "Email tối đa 150 ký tự");
            } else if (!email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
                errors.put("email", "Email không hợp lệ");
            } else if (userDAO.emailExists(email)) {
                errors.put("email", "Email này đã được sử dụng");
            }
        }

        if (hasPhone) {
            if (phone.length() > 20) {
                errors.put("phone", "Số điện thoại tối đa 20 ký tự");
            } else if (!phone.matches("^(0|\\+84)[0-9]{8,10}$")) {
                errors.put("phone", "Số điện thoại không hợp lệ");
            } else if (userDAO.phoneExists(phone)) {
                errors.put("phone", "Số điện thoại này đã được sử dụng");
            }
        }

        if (password == null || password.isEmpty()) {
            errors.put("password", "Mật khẩu không được để trống");
        } else if (password.length() < 6) {
            errors.put("password", "Mật khẩu phải có ít nhất 6 ký tự");
        } else if (password.length() > 100) {
            errors.put("password", "Mật khẩu tối đa 100 ký tự");
        }

        if (confirmPassword == null || !confirmPassword.equals(password)) {
            errors.put("confirmPassword", "Mật khẩu nhập lại không khớp");
        }

        if (!errors.isEmpty()) {
            String firstError = errors.values().iterator().next();
            req.setAttribute("error", firstError);
            req.setAttribute("errors", errors);
            req.setAttribute("fullName", fullName == null ? "" : fullName);
            req.setAttribute("email", email == null ? "" : email);
            req.setAttribute("phone", phone == null ? "" : phone);
            ServletUtils.forward(req, resp, VIEW);
            return;
        }

        boolean ok = userDAO.registerCustomer(fullName, email, phone, password);
        if (!ok) {
            req.setAttribute("error", "Không thể tạo tài khoản, vui lòng thử lại");
            req.setAttribute("registerError", "Không thể tạo tài khoản, vui lòng thử lại");
            req.setAttribute("fullName", fullName == null ? "" : fullName);
            req.setAttribute("email", email == null ? "" : email);
            req.setAttribute("phone", phone == null ? "" : phone);
            ServletUtils.forward(req, resp, VIEW);
            return;
        }

        ServletUtils.setFlash(req, "success", "Đăng ký tài khoản thành công. Bạn có thể đăng nhập ngay.");
        ServletUtils.redirect(req, resp, "/login");
    }
}