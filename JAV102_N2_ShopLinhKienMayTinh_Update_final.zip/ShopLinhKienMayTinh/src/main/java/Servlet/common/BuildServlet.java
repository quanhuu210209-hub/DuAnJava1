package Servlet.common;

import DAO.admin.ProductDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Trang Build cấu hình PC (công khai): chọn linh kiện từ các sản phẩm đang bán. URL: /build */
@WebServlet("/build")
public class BuildServlet extends HttpServlet {

    private final ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("products", productDAO.search("", null, null, true));
        ServletUtils.forward(req, resp, "/build.jsp");
    }
}
