package Servlet.common;

import Model.user.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/** Hàm tiện ích dùng chung cho các Servlet. */
public class ServletUtils {

    public static final String SESSION_USER = "loginUser";

    public static String trim(String s) { return s == null ? "" : s.trim(); }

    public static int parseInt(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return def; }
    }

    /** Trả về null nếu rỗng hoặc không phải số (dùng cho tham số lọc tùy chọn). */
    public static Integer parseIntOrNull(String s) {
        try { return Integer.valueOf(s.trim()); } catch (Exception e) { return null; }
    }

    public static User currentUser(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        return s == null ? null : (User) s.getAttribute(SESSION_USER);
    }

    public static void forward(HttpServletRequest req, HttpServletResponse resp, String view)
            throws ServletException, IOException {
        req.getRequestDispatcher(view).forward(req, resp);
    }

    /** Redirect tới đường dẫn trong ứng dụng (tự thêm context path). */
    public static void redirect(HttpServletRequest req, HttpServletResponse resp, String path) throws IOException {
        resp.sendRedirect(req.getContextPath() + path);
    }

    /** Trang mặc định sau đăng nhập theo vai trò. */
    public static String homeOf(String roleCode) {
        if (roleCode == null) return "/home";
        switch (roleCode) {
            case "ADMIN":    return "/admin/product";
            case "MANAGER":
            case "STAFF":    return "/staff/order";
            default:         return "/home";
        }
    }

    // ---- Flash message: hiện 1 lần sau redirect (Post-Redirect-Get) ----

    public static void setFlash(HttpServletRequest req, String type, String message) {
        HttpSession s = req.getSession();
        s.setAttribute("flashType", type);      // success | danger | warning
        s.setAttribute("flashMessage", message);
    }

    /** Chuyển flash từ session sang request để JSP hiển thị rồi xóa khỏi session. */
    public static void loadFlash(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s == null) return;
        Object msg = s.getAttribute("flashMessage");
        if (msg != null) {
            req.setAttribute("flashMessage", msg);
            req.setAttribute("flashType", s.getAttribute("flashType"));
            s.removeAttribute("flashMessage");
            s.removeAttribute("flashType");
        }
    }
}
