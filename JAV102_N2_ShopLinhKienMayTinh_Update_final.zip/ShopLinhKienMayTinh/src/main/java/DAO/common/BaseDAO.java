package DAO.common;

import Util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.Serializable;
import java.util.List;
import java.util.function.Function;

/**
 * DAO nền cho mọi Entity: findById, findAll, insert, delete.
 * Mỗi thao tác dùng một Session riêng; thao tác ghi chạy trong một transaction
 * (thành công thì commit, lỗi thì rollback).
 */
public abstract class BaseDAO<T> {

    private final Class<T> type;
    private final String entityName;   // tên entity dùng trong HQL

    protected BaseDAO(Class<T> type, String entityName) {
        this.type = type;
        this.entityName = entityName;
    }

    public T findById(Serializable id) {
        return read(s -> s.get(type, id));
    }

    public List<T> findAll() {
        return read(s -> s.createQuery("from " + entityName, type).getResultList());
    }

    /** Thêm mới. Sau khi thành công, id được sinh sẽ nằm trong chính đối tượng truyền vào. */
    public boolean insert(T entity) {
        return write(s -> {
            s.persist(entity);
            return true;
        });
    }

    /** Xóa thật. Trả về false nếu không tồn tại hoặc đang bị ràng buộc khóa ngoại. */
    public boolean delete(Serializable id) {
        return write(s -> {
            T e = s.get(type, id);
            if (e == null) return false;
            s.remove(e);
            return true;
        });
    }

    // ---------- Hàm dùng cho các DAO con ----------

    /** Chạy truy vấn đọc. */
    protected <R> R read(Function<Session, R> work) {
        try (Session s = HibernateUtil.openSession()) {
            return work.apply(s);
        }
    }

    /** Chạy trong transaction; lambda trả về false để hủy (rollback). */
    protected boolean write(Function<Session, Boolean> work) {
        Session s = HibernateUtil.openSession();
        Transaction tx = s.beginTransaction();
        try {
            boolean ok = work.apply(s);
            if (ok) tx.commit();
            else tx.rollback();
            return ok;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            System.err.println("[" + getClass().getSimpleName() + "] " + ex);
            return false;
        } finally {
            s.close();
        }
    }
}
