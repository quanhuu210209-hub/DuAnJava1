package DAO.user;

import DAO.common.BaseDAO;
import Model.user.CustomerNotification;
import org.hibernate.query.Query;

import java.util.Collections;
import java.util.List;

/** Bảng Notification(NotificationID, UserID, Title, Content, IsRead, CreatedAt). UserID NULL = thông báo chung. */
public class CustomerNotificationDAO extends BaseDAO<CustomerNotification> {

    public CustomerNotificationDAO() {
        super(CustomerNotification.class, "CustomerNotification");
    }

    public List<CustomerNotification> findForUser(int userId) {
        try {
            return read(s -> {
                String hql = "FROM CustomerNotification n WHERE n.userId = :uid OR n.userId IS NULL ORDER BY n.createdAt DESC";
                Query<CustomerNotification> q = s.createQuery(hql, CustomerNotification.class);
                q.setParameter("uid", userId);
                return q.getResultList();
            });
        } catch (RuntimeException ex) {
            System.err.println("[CustomerNotificationDAO.findForUser] " + ex);
            return Collections.emptyList();
        }
    }

    public void markRead(int notificationId, int userId) {
        write(s -> {
            String hql = "UPDATE CustomerNotification n SET n.read = true WHERE n.notificationId = :nid AND (n.userId = :uid OR n.userId IS NULL)";
            s.createMutationQuery(hql)
                    .setParameter("nid", notificationId)
                    .setParameter("uid", userId)
                    .executeUpdate();
            return true;
        });
    }
}