package DAO.user;

import DAO.common.BaseDAO;
import Model.admin.Product;
import Model.user.Cart;
import Model.user.CartItem;
import Model.user.Customer;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.Session;

/** Giỏ hàng của khách: mỗi khách một Cart, các dòng nằm trong CartItem. */
public class CartDAO extends BaseDAO<Cart> {

    public CartDAO() { super(Cart.class, "Cart"); }

    /** Mã khách hàng ứng với tài khoản; null nếu tài khoản chưa có hồ sơ khách. */
    public Integer customerIdOf(int userId) {
        return read(s -> s.createQuery(
                "select c.customerId from Customer c where c.user.userId = :u", Integer.class)
                .setParameter("u", userId).setMaxResults(1).uniqueResult());
    }

    /** Các dòng trong giỏ (kèm sản phẩm), cũ trước mới sau. */
    public List<CartItem> items(int customerId) {
        return read(s -> s.createQuery(
                "from CartItem i where i.cart.customer.customerId = :c order by i.addedAt, i.cartItemId", CartItem.class)
                .setParameter("c", customerId).getResultList());
    }

    /** Thêm qty sản phẩm; đã có trong giỏ thì cộng dồn. */
    public boolean add(int customerId, int productId, int qty) {
        return write(s -> {
            Product p = s.get(Product.class, productId);
            if (p == null) return false;
            Cart cart = cartOf(s, customerId, true);
            if (cart == null) return false;
            CartItem it = itemOf(s, cart.getCartId(), productId);
            if (it == null) {
                it = new CartItem();
                it.setCart(cart);
                it.setProduct(p);
                it.setQuantity(qty);
                it.setAddedAt(LocalDateTime.now());
                s.persist(it);
            } else {
                it.setQuantity(it.getQuantity() + qty);
            }
            cart.setUpdatedAt(LocalDateTime.now());
            return true;
        });
    }

    /** Đặt lại số lượng; qty <= 0 thì xóa dòng. */
    public boolean setQuantity(int customerId, int productId, int qty) {
        return write(s -> {
            Cart cart = cartOf(s, customerId, false);
            if (cart == null) return false;
            CartItem it = itemOf(s, cart.getCartId(), productId);
            if (it == null) return false;
            if (qty <= 0) s.remove(it);
            else it.setQuantity(qty);
            cart.setUpdatedAt(LocalDateTime.now());
            return true;
        });
    }

    public boolean remove(int customerId, int productId) {
        return setQuantity(customerId, productId, 0);
    }

    public boolean clear(int customerId) {
        return write(s -> {
            Cart cart = cartOf(s, customerId, false);
            if (cart == null) return true;
            s.createMutationQuery("delete from CartItem i where i.cart.cartId = :c")
                    .setParameter("c", cart.getCartId()).executeUpdate();
            return true;
        });
    }

    // ---------- dùng nội bộ ----------

    private static Cart cartOf(Session s, int customerId, boolean create) {
        Cart cart = s.createQuery("from Cart c where c.customer.customerId = :c", Cart.class)
                .setParameter("c", customerId).setMaxResults(1).uniqueResult();
        if (cart == null && create) {
            Customer cu = s.get(Customer.class, customerId);
            if (cu == null) return null;
            cart = new Cart();
            cart.setCustomer(cu);
            cart.setCreatedAt(LocalDateTime.now());
            cart.setUpdatedAt(LocalDateTime.now());
            s.persist(cart);
        }
        return cart;
    }

    private static CartItem itemOf(Session s, int cartId, int productId) {
        return s.createQuery("from CartItem i where i.cart.cartId = :c and i.product.productId = :p", CartItem.class)
                .setParameter("c", cartId).setParameter("p", productId).setMaxResults(1).uniqueResult();
    }
}
