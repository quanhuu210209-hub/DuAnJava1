package DAO.user;

import DAO.common.BaseDAO;
import DAO.manager.BranchInventoryDAO;
import Model.admin.Branch;
import Model.admin.PaymentMethod;
import Model.admin.Product;
import Model.manager.BranchInventory;
import Model.staff.Invoice;
import Model.user.CartItem;
import Model.user.Customer;
import Model.user.Order;
import Model.user.OrderDetail;
import Model.user.Payment;
import Model.user.User;
import Util.OrderConst;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderDAO extends BaseDAO<Order> {

    public OrderDAO() { super(Order.class, "Orders"); }

    public List<Order> search(Integer branchId, String status, String channel, String keyword) {
        StringBuilder hql = new StringBuilder("select o from Orders o left join o.customer c where 1 = 1 ");
        Map<String, Object> params = new HashMap<>();
        if (branchId != null) { hql.append("and o.branch.branchId = :b "); params.put("b", branchId); }
        if (status != null && !status.isEmpty()) { hql.append("and o.status = :st "); params.put("st", status); }
        if ("online".equals(channel)) { hql.append("and o.channel <> :ch "); params.put("ch", OrderConst.CHANNEL_OFFLINE); }
        if ("offline".equals(channel)) { hql.append("and o.channel = :ch "); params.put("ch", OrderConst.CHANNEL_OFFLINE); }
        if (keyword != null && !keyword.isEmpty()) {
            hql.append("and (lower(o.orderCode) like :k or c.phone like :k or o.receiverPhone like :k) ");
            params.put("k", "%" + keyword.toLowerCase() + "%");
        }
        hql.append("order by o.createdAt desc");
        return read(s -> {
            org.hibernate.query.Query<Order> q = s.createQuery(hql.toString(), Order.class).setMaxResults(200);
            params.forEach(q::setParameter);
            return q.getResultList();
        });
    }

    public long countPendingOnline(int branchId) {
        return read(s -> s.createQuery(
                "select count(o) from Orders o where o.branch.branchId = :b and o.channel <> :ch and o.status in ('Pending', 'Paid')",
                Long.class).setParameter("b", branchId).setParameter("ch", OrderConst.CHANNEL_OFFLINE).uniqueResult());
    }

    public Order findByInvoiceOrCode(String key) {
        return read(s -> s.createQuery(
                "select o from Orders o left join fetch o.details d left join fetch d.product "
                + "where o.orderCode = :k or o.orderId in (select i.salesOrder.orderId from Invoice i where i.invoiceNo = :k)",
                Order.class).setParameter("k", key).setMaxResults(1).uniqueResult());
    }

    public List<Order> findByCustomer(int customerId) {
        return read(s -> s.createQuery(
                "from Orders o where o.customer.customerId = :c order by o.createdAt desc", Order.class)
                .setParameter("c", customerId).getResultList());
    }

    @Override
    public Order findById(java.io.Serializable id) {
        return read(s -> s.createQuery(
                "select o from Orders o left join fetch o.details d left join fetch d.product where o.orderId = :id",
                Order.class).setParameter("id", id).uniqueResult());
    }

    /** Lấy danh sách phương thức thanh toán đang hoạt động. */
    public List<PaymentMethod> findActivePaymentMethods() {
        return read(s -> s.createQuery(
                "from PaymentMethod pm where pm.active = true order by pm.paymentMethodId asc",
                PaymentMethod.class
        ).getResultList());
    }

    /**
     * Thanh toán trực tiếp đơn hàng online: tạo bản ghi Payment với mã tự tăng (PAY-000001...)
     * và cập nhật paymentStatus của đơn thành ORDER_PAID.
     */
    public boolean payOnlineOrder(int orderId, int customerId, int paymentMethodId) {
        try {
            return write(s -> {
                Order o = s.get(Order.class, orderId);
                if (o == null || o.getCustomer() == null || o.getCustomer().getCustomerId() != customerId) {
                    return false;
                }
                if ("Cancelled".equals(o.getStatus()) || OrderConst.ORDER_PAID.equals(o.getPaymentStatus())) {
                    return false;
                }

                PaymentMethod method = s.get(PaymentMethod.class, paymentMethodId);
                if (method == null || !method.isActive()) {
                    return false;
                }

                Number maxId = s.createQuery(
                        "select coalesce(max(p.paymentId), 0) from Payment p",
                        Number.class
                ).uniqueResult();
                long nextNum = (maxId != null ? maxId.longValue() : 0L) + 1L;
                String txRef = String.format("PAY-%06d", nextNum);

                LocalDateTime now = LocalDateTime.now();
                BigDecimal amount = o.getTotalAmount() != null ? o.getTotalAmount() : BigDecimal.ZERO;

                Payment pay = new Payment();
                pay.setSalesOrder(o);
                pay.setPaymentMethod(method);
                pay.setAmount(amount);
                pay.setStatus(OrderConst.PAYMENT_OK);
                pay.setTransactionRef(txRef);
                pay.setPaidAt(now);
                pay.setCreatedAt(now);
                s.persist(pay);

                o.setPaymentStatus(OrderConst.ORDER_PAID);
                o.setUpdatedAt(now);
                return true;
            });
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateStatus(int orderId, String status, int handledBy) {
        return write(s -> {
            Order o = s.createQuery(
                    "select o from Orders o left join fetch o.details d left join fetch d.product where o.orderId = :id",
                    Order.class).setParameter("id", orderId).uniqueResult();
            if (o == null) return false;
            LocalDateTime now = LocalDateTime.now();
            User staff = s.getReference(User.class, handledBy);

            if ("Paid".equals(o.getStatus()) && ("Shipping".equals(status) || "Completed".equals(status))) {
                for (OrderDetail d : o.getDetails()) {
                    BranchInventory inv = BranchInventoryDAO.of(s, o.getBranch().getBranchId(), d.getProduct().getProductId());
                    if (inv == null || inv.isHidden() || inv.getQuantity() < d.getQuantity()) return false;
                    BranchInventoryDAO.takeStock(s, inv, d.getQuantity(), o.getOrderId(), staff, now);
                }
            }
            if ("Paid".equals(status)) o.setPaymentStatus(OrderConst.ORDER_PAID);
            o.setStatus(status);
            o.setHandledBy(staff);
            o.setUpdatedAt(now);
            if ("Completed".equals(status)) o.setCompletedAt(now);
            return true;
        });
    }

    public boolean cancel(int orderId, int cancelledBy, String reason) {
        return write(s -> {
            Order o = s.get(Order.class, orderId);
            if (o == null || !("Pending".equals(o.getStatus()) || "Paid".equals(o.getStatus()))) return false;
            LocalDateTime now = LocalDateTime.now();
            o.setStatus("Cancelled");
            o.setCancelledAt(now);
            o.setCancelledBy(s.getReference(User.class, cancelledBy));
            o.setCancelReason(reason);
            o.setUpdatedAt(now);
            return true;
        });
    }

    /** Khách hàng tự hủy đơn của mình khi đơn đang ở trạng thái Pending hoặc Paid. */
    public boolean cancelCustomerOrder(int orderId, int customerId, int userId, String reason) {
        try {
            return write(s -> {
                Order o = s.get(Order.class, orderId);
                if (o == null || o.getCustomer() == null || o.getCustomer().getCustomerId() != customerId) {
                    return false;
                }
                if (!("Pending".equals(o.getStatus()) || "Paid".equals(o.getStatus()))) {
                    return false;
                }

                LocalDateTime now = LocalDateTime.now();
                String cleanReason = (reason == null || reason.isBlank())
                        ? "Khách hàng hủy đơn"
                        : reason.trim();

                o.setStatus("Cancelled");
                o.setCancelledAt(now);
                o.setCancelledBy(s.getReference(User.class, userId));
                o.setCancelReason(cleanReason);
                o.setUpdatedAt(now);
                return true;
            });
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public int createOnlineOrder(int customerId, int userId, Integer branchId,
                                 String receiveMethod, String receiverName,
                                 String receiverPhone, String shippingAddress, String note) {
        int[] out = {0};
        boolean ok = write(s -> {
            Customer customer = s.get(Customer.class, customerId);
            if (customer == null) return false;

            List<CartItem> cartItems = s.createQuery(
                    "from CartItem i where i.cart.customer.customerId = :c order by i.addedAt, i.cartItemId",
                    CartItem.class)
                    .setParameter("c", customerId)
                    .getResultList();
            if (cartItems.isEmpty()) return false;

            Branch branch = null;
            if (branchId != null && branchId > 0) {
                branch = s.get(Branch.class, branchId);
            }
            if (branch == null) {
                branch = s.createQuery("from Branch b order by b.branchId", Branch.class)
                        .setMaxResults(1)
                        .uniqueResult();
            }

            LocalDateTime now = LocalDateTime.now();
            User creator = s.getReference(User.class, userId);

            Order o = new Order();
            o.setOrderCode(OrderConst.newCode("ORD"));
            o.setCustomer(customer);
            o.setBranch(branch);
            o.setChannel("Online");
            o.setReceiveMethod((receiveMethod == null || receiveMethod.isBlank())
                    ? "Delivery" : receiveMethod.trim());
            o.setReceiverName((receiverName == null || receiverName.isBlank())
                    ? customer.getFullName() : receiverName.trim());
            o.setReceiverPhone((receiverPhone == null || receiverPhone.isBlank())
                    ? customer.getPhone() : receiverPhone.trim());
            o.setShippingAddress(shippingAddress == null ? "" : shippingAddress.trim());
            o.setNote(note == null ? "" : note.trim());

            BigDecimal subTotal = BigDecimal.ZERO;
            List<OrderDetail> details = new ArrayList<>();

            for (CartItem ci : cartItems) {
                Product p = s.get(Product.class, ci.getProduct().getProductId());
                if (p == null || ci.getQuantity() <= 0) return false;

                BigDecimal unitPrice = p.getPrice() == null ? BigDecimal.ZERO : p.getPrice();
                OrderDetail d = new OrderDetail();
                d.setSalesOrder(o);
                d.setProduct(p);
                d.setQuantity(ci.getQuantity());
                d.setUnitPrice(unitPrice);
                d.setWarrantyMonths(p.getWarrantyMonths());
                details.add(d);

                subTotal = subTotal.add(unitPrice.multiply(BigDecimal.valueOf(ci.getQuantity())));
            }

            BigDecimal shippingFee = BigDecimal.ZERO;
            o.setSubTotal(subTotal);
            o.setShippingFee(shippingFee);
            o.setTotalAmount(subTotal.add(shippingFee));
            o.setStatus("Pending");
            o.setPaymentStatus("UNPAID");
            o.setCreatedBy(creator);
            o.setCreatedAt(now);
            o.setUpdatedAt(now);

            s.persist(o);
            for (OrderDetail d : details) {
                s.persist(d);
            }

            s.createMutationQuery("delete from CartItem i where i.cart.customer.customerId = :c")
                    .setParameter("c", customerId)
                    .executeUpdate();

            out[0] = o.getOrderId();
            return true;
        });
        return ok ? out[0] : 0;
    }

    public int createCounterSale(int branchId, int staffId, int customerId, int paymentMethodId, Map<Integer, Integer> items) {
        int[] out = {0};
        boolean ok = write(s -> {
            PaymentMethod method = s.get(PaymentMethod.class, paymentMethodId);
            if (method == null || items.isEmpty()) return false;
            LocalDateTime now = LocalDateTime.now();
            User staff = s.getReference(User.class, staffId);

            Order o = new Order();
            List<OrderDetail> lines = new ArrayList<>();
            List<BranchInventory> stocks = new ArrayList<>();
            BigDecimal total = BigDecimal.ZERO;
            for (Map.Entry<Integer, Integer> e : items.entrySet()) {
                Product p = s.get(Product.class, e.getKey());
                BranchInventory stock = BranchInventoryDAO.of(s, branchId, e.getKey());
                if (p == null || stock == null || stock.isHidden() || stock.getQuantity() < e.getValue()) return false;
                stocks.add(stock);

                OrderDetail d = new OrderDetail();
                d.setSalesOrder(o);
                d.setProduct(p);
                d.setQuantity(e.getValue());
                d.setUnitPrice(p.getPrice());
                d.setWarrantyMonths(p.getWarrantyMonths());
                lines.add(d);
                total = total.add(p.getPrice().multiply(BigDecimal.valueOf(e.getValue())));
            }

            o.setOrderCode(OrderConst.newCode("POS"));
            o.setCustomer(s.getReference(Customer.class, customerId));
            o.setBranch(s.getReference(Branch.class, branchId));
            o.setChannel(OrderConst.CHANNEL_OFFLINE);
            o.setReceiveMethod(OrderConst.RECEIVE_PICKUP);
            o.setSubTotal(total);
            o.setShippingFee(BigDecimal.ZERO);
            o.setTotalAmount(total);
            o.setStatus("Completed");
            o.setPaymentStatus(OrderConst.ORDER_PAID);
            o.setCreatedBy(staff);
            o.setHandledBy(staff);
            o.setCreatedAt(now);
            o.setUpdatedAt(now);
            o.setCompletedAt(now);
            s.persist(o);
            for (OrderDetail d : lines) s.persist(d);
            for (int i = 0; i < lines.size(); i++) {
                BranchInventoryDAO.takeStock(s, stocks.get(i), lines.get(i).getQuantity(), o.getOrderId(), staff, now);
            }

            Payment pay = new Payment();
            pay.setSalesOrder(o);
            pay.setPaymentMethod(method);
            pay.setAmount(total);
            pay.setStatus(OrderConst.PAYMENT_OK);
            pay.setPaidAt(now);
            pay.setConfirmedBy(staff);
            pay.setCreatedAt(now);
            s.persist(pay);

            Invoice invoice = new Invoice();
            invoice.setInvoiceNo(OrderConst.newCode("HD"));
            invoice.setSalesOrder(o);
            invoice.setIssuedBy(staff);
            invoice.setIssuedAt(now);
            invoice.setPrintCount(0);
            s.persist(invoice);

            out[0] = o.getOrderId();
            return true;
        });
        return ok ? out[0] : 0;
    }
}