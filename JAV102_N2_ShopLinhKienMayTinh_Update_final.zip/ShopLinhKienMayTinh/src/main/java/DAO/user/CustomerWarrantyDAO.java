package DAO.user;

import DAO.common.BaseDAO;
import Model.admin.Branch;
import Model.staff.WarrantyRequest;
import Model.user.Customer;
import Model.user.Order;
import Model.user.OrderDetail;
import Model.user.User;
import Util.OrderConst;

import java.time.LocalDateTime;
import java.util.List;

/** Khách tự gửi và tra cứu yêu cầu bảo hành / đổi / trả (WarrantyRequests, Source = Online). */
public class CustomerWarrantyDAO extends BaseDAO<WarrantyRequest> {

    public CustomerWarrantyDAO() { super(WarrantyRequest.class, "WarrantyRequest"); }

    public List<WarrantyRequest> findByCustomer(int customerId) {
        return read(s -> s.createQuery(
                "from WarrantyRequest w where w.customer.customerId = :c order by w.createdAt desc", WarrantyRequest.class)
                .setParameter("c", customerId).setMaxResults(100).getResultList());
    }

    /** Các dòng hàng khách đã mua (đơn chưa hủy) để chọn khi gửi yêu cầu. */
    public List<OrderDetail> findPurchasedLines(int customerId) {
        return read(s -> s.createQuery(
                "from OrderDetail d where d.salesOrder.customer.customerId = :c and d.salesOrder.status <> 'Cancelled' "
              + "order by d.salesOrder.createdAt desc, d.orderDetailId", OrderDetail.class)
                .setParameter("c", customerId).setMaxResults(200).getResultList());
    }

    /** Trả về null nếu gửi thành công, ngược lại là thông báo lỗi để hiện cho khách. */
    public String submit(int customerId, int userId, int orderDetailId, String type, int quantity, String reason) {
        if (!OrderConst.TYPE_WARRANTY.equals(type) && !OrderConst.TYPE_RETURN.equals(type)
                && !OrderConst.TYPE_EXCHANGE.equals(type)) return "Loại yêu cầu không hợp lệ";
        if (reason == null || reason.trim().isEmpty()) return "Vui lòng mô tả lý do";
        if (quantity < 1) return "Số lượng không hợp lệ";

        String[] error = {null};
        boolean ok = write(s -> {
            OrderDetail d = s.get(OrderDetail.class, orderDetailId);
            if (d == null || d.getSalesOrder().getCustomer().getCustomerId() != customerId
                    || "Cancelled".equals(d.getSalesOrder().getStatus())) {
                error[0] = "Không tìm thấy sản phẩm trong đơn của bạn";
                return false;
            }
            Long done = s.createQuery("select coalesce(sum(w.quantity), 0) from WarrantyRequest w "
                    + "where w.orderDetail.orderDetailId = :d and w.status <> :rej", Long.class)
                    .setParameter("d", orderDetailId).setParameter("rej", OrderConst.WARRANTY_REJECTED).uniqueResult();
            int remaining = d.getQuantity() - (done == null ? 0 : done.intValue());
            if (quantity > remaining) {
                error[0] = "Số lượng vượt quá số đã mua (còn có thể gửi: " + Math.max(remaining, 0) + ")";
                return false;
            }
            Order o = d.getSalesOrder();
            LocalDateTime now = LocalDateTime.now();
            if (OrderConst.TYPE_WARRANTY.equals(type)) {
                LocalDateTime from = o.getCompletedAt() != null ? o.getCompletedAt() : o.getCreatedAt();
                if (from != null && from.plusMonths(d.getWarrantyMonths()).isBefore(now)) {
                    error[0] = "Sản phẩm đã hết thời hạn bảo hành";
                    return false;
                }
            }
            WarrantyRequest w = new WarrantyRequest();
            w.setRequestCode(OrderConst.newCode("BH"));
            w.setOrderDetail(d);
            w.setCustomer(s.getReference(Customer.class, customerId));
            w.setBranch(o.getBranch());
            w.setRequestType(type);
            w.setSource(OrderConst.WARRANTY_SOURCE_ONLINE);
            w.setQuantity(quantity);
            w.setReason(reason.trim());
            w.setReceivedBy(s.getReference(User.class, userId));   // tài khoản khách gửi
            w.setStatus(OrderConst.WARRANTY_PENDING);
            w.setRefundApproved(false);
            w.setCreatedAt(now);
            w.setUpdatedAt(now);
            s.persist(w);
            return true;
        });
        return ok ? null : (error[0] != null ? error[0] : "Không thể gửi yêu cầu, vui lòng thử lại");
    }
}
