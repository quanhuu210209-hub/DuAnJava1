package DAO.user;

import DAO.common.BaseDAO;
import Model.user.Customer;

import java.util.List;

public class CustomerDAO extends BaseDAO<Customer> {

    public CustomerDAO() { super(Customer.class, "Customer"); }

    /** Hồ sơ khách hàng gắn với tài khoản đăng nhập (null nếu chưa có). */
    public Customer findByUserId(int userId) {
        return read(s -> s.createQuery("from Customer c where c.user.userId = :u", Customer.class)
                .setParameter("u", userId).setMaxResults(1).uniqueResult());
    }

    public Customer findByPhone(String phone) {
        return read(s -> s.createQuery("from Customer c where c.phone = :p", Customer.class)
                .setParameter("p", phone).setMaxResults(1).uniqueResult());
    }

    /** Tìm theo số điện thoại hoặc họ tên (tối đa 30 kết quả). */
    public List<Customer> search(String keyword) {
        String k = "%" + keyword.toLowerCase() + "%";
        return read(s -> s.createQuery(
                "from Customer c where c.phone like :k or lower(c.fullName) like :k order by c.customerId desc", Customer.class)
                .setParameter("k", k).setMaxResults(30).getResultList());
    }

    /** Khách mới nhất, dùng khi chưa nhập từ khóa tìm kiếm. */
    public List<Customer> recent(int limit) {
        return read(s -> s.createQuery("from Customer c order by c.customerId desc", Customer.class)
                .setMaxResults(limit).getResultList());
    }
}
