package DAO.user;

import DAO.common.BaseDAO;
import Model.admin.ChatbotFaq;
import Model.user.ChatMessage;
import Model.user.ChatSession;
import Model.user.Customer;
import Util.OrderConst;

import java.text.Normalizer;
import java.time.LocalDateTime;
import java.util.List;

/** Chatbot tư vấn: so khớp từ khóa trong ChatbotFAQ (không phân biệt hoa thường, bỏ dấu) và lưu lịch sử chat. */
public class ChatbotDAO extends BaseDAO<ChatbotFaq> {

    public ChatbotDAO() { super(ChatbotFaq.class, "ChatbotFaq"); }

    /** Câu trả lời có nhiều từ khóa khớp nhất; null nếu không khớp từ khóa nào. */
    public String findAnswer(String message) {
        String msg = normalize(message);
        List<ChatbotFaq> faqs = read(s -> s.createQuery("from ChatbotFaq f where f.active = true", ChatbotFaq.class).getResultList());
        String best = null;
        int bestScore = 0;
        for (ChatbotFaq f : faqs) {
            int score = 0;
            for (String k : f.getKeywords().split("[,;\\n]")) {
                String key = normalize(k);
                if (key.length() >= 2 && msg.contains(key)) score += key.length();   // từ khóa dài thì ưu tiên hơn
            }
            if (score > bestScore) { bestScore = score; best = f.getAnswer(); }
        }
        return best;
    }

    public int createSession(int customerId, String token) {
        int[] out = {0};
        boolean ok = write(s -> {
            ChatSession cs = new ChatSession();
            cs.setCustomer(s.getReference(Customer.class, customerId));
            cs.setSessionToken(token);
            cs.setStartedAt(LocalDateTime.now());
            s.persist(cs);
            out[0] = cs.getChatSessionId();
            return true;
        });
        return ok ? out[0] : 0;
    }

    public void saveMessage(int sessionId, String sender, String content) {
        write(s -> {
            ChatMessage m = new ChatMessage();
            m.setChatSession(s.getReference(ChatSession.class, sessionId));
            m.setSender(sender);
            m.setContent(content);
            m.setCreatedAt(LocalDateTime.now());
            s.persist(m);
            return true;
        });
    }

    static String normalize(String text) {
        if (text == null) return "";
        String t = Normalizer.normalize(text.toLowerCase().trim(), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").replace('đ', 'd');
        return t;
    }
}
