package DAO.user;

import DAO.common.BaseDAO;
import Model.user.Customer;
import Model.user.CustomerAddress;

import java.time.LocalDateTime;
import java.util.List;

/** Sổ địa chỉ nhận hàng. Mọi thao tác đều ràng buộc theo customerId nên khách không sửa được địa chỉ người khác. */
public class CustomerAddressDAO extends BaseDAO<CustomerAddress> {

    public CustomerAddressDAO() { super(CustomerAddress.class, "CustomerAddress"); }

    public List<CustomerAddress> findByCustomer(int customerId) {
        return read(s -> s.createQuery(
                "from CustomerAddress a where a.customer.customerId = :c order by a.defaultAddress desc, a.addressId desc",
                CustomerAddress.class).setParameter("c", customerId).getResultList());
    }

    /** Địa chỉ đầu tiên luôn là mặc định. */
    public boolean add(int customerId, String name, String phone, String line, boolean makeDefault) {
        if (isBlank(name) || isBlank(phone) || isBlank(line)) return false;
        return write(s -> {
            Long existing = s.createQuery("select count(a) from CustomerAddress a where a.customer.customerId = :c", Long.class)
                    .setParameter("c", customerId).uniqueResult();
            boolean def = makeDefault || existing == null || existing == 0;
            if (def) clearDefault(s, customerId);
            CustomerAddress a = new CustomerAddress();
            a.setCustomer(s.getReference(Customer.class, customerId));
            a.setReceiverName(name.trim());
            a.setPhone(phone.trim());
            a.setAddressLine(line.trim());
            a.setDefaultAddress(def);
            a.setCreatedAt(LocalDateTime.now());
            s.persist(a);
            return true;
        });
    }

    public boolean setDefault(int addressId, int customerId) {
        return write(s -> {
            CustomerAddress a = s.get(CustomerAddress.class, addressId);
            if (a == null || a.getCustomer().getCustomerId() != customerId) return false;
            clearDefault(s, customerId);
            a.setDefaultAddress(true);
            return true;
        });
    }

    public boolean remove(int addressId, int customerId) {
        return write(s -> {
            CustomerAddress a = s.get(CustomerAddress.class, addressId);
            if (a == null || a.getCustomer().getCustomerId() != customerId) return false;
            boolean wasDefault = a.isDefaultAddress();
            s.remove(a);
            s.flush();
            if (wasDefault) {   // chuyển mặc định sang địa chỉ mới nhất còn lại
                CustomerAddress next = s.createQuery(
                        "from CustomerAddress x where x.customer.customerId = :c order by x.addressId desc", CustomerAddress.class)
                        .setParameter("c", customerId).setMaxResults(1).uniqueResult();
                if (next != null) next.setDefaultAddress(true);
            }
            return true;
        });
    }

    private void clearDefault(org.hibernate.Session s, int customerId) {
        s.createMutationQuery("update CustomerAddress a set a.defaultAddress = false where a.customer.customerId = :c")
                .setParameter("c", customerId).executeUpdate();
    }

    private static boolean isBlank(String v) { return v == null || v.trim().isEmpty(); }
}
