package DAO.user;

import DAO.common.BaseDAO;
import Model.user.Notification;

import java.util.List;

public class NotificationDAO extends BaseDAO<Notification> {

    public NotificationDAO() { super(Notification.class, "Notification"); }

    /** Thông báo của một người dùng, chưa đọc lên trước, mới nhất trước. */
    public List<Notification> findByUser(int userId) {
        return read(s -> s.createQuery(
                "from Notification n where n.user.userId = :u order by n.read, n.createdAt desc", Notification.class)
                .setParameter("u", userId).setMaxResults(100).getResultList());
    }

    public long countUnread(int userId) {
        return read(s -> s.createQuery(
                "select count(n) from Notification n where n.user.userId = :u and n.read = false", Long.class)
                .setParameter("u", userId).uniqueResult());
    }

    /** Đánh dấu đã đọc (chỉ thông báo của chính người dùng). */
    public boolean markRead(long id, int userId) {
        return write(s -> s.createMutationQuery(
                "update Notification n set n.read = true where n.notificationId = :id and n.user.userId = :u")
                .setParameter("id", id).setParameter("u", userId).executeUpdate() > 0);
    }

    public boolean markAllRead(int userId) {
        return write(s -> {
            s.createMutationQuery("update Notification n set n.read = true where n.user.userId = :u and n.read = false")
                    .setParameter("u", userId).executeUpdate();
            return true;
        });
    }
}
