package DAO.user;

import DAO.common.BaseDAO;
import Model.admin.Branch;
import Model.admin.Role;
import Model.user.User;
import Util.PasswordUtil;

import java.time.LocalDateTime;
import java.util.List;

public class UserDAO extends BaseDAO<User> {

    public UserDAO() { super(User.class, "User"); }

    /** Đăng nhập bằng email hoặc SĐT. Trả về null nếu sai thông tin / tài khoản bị khóa. */
    public User login(String emailOrPhone, String password) {
        User u = read(s -> s.createQuery(
                "from User u where (u.email = :id or u.phone = :id) and u.active = true", User.class)
                .setParameter("id", emailOrPhone).setMaxResults(1).uniqueResult());
        if (u != null && PasswordUtil.verify(password, u.getPasswordHash())) {
            final int id = u.getUserId();
            write(s -> {
                s.get(User.class, id).setLastLoginAt(LocalDateTime.now());
                return true;
            });
            return u;
        }
        return null;
    }

    @Override
    public List<User> findAll() {
        return read(s -> s.createQuery("from User u order by u.userId", User.class).getResultList());
    }

    /** Thêm user. user.role bắt buộc; user.branch có thể null. Mật khẩu thô sẽ được băm. */
    public boolean insert(User u, String rawPassword) {
        return write(s -> {
            u.setRole(s.getReference(Role.class, u.getRole().getRoleId()));
            u.setBranch(u.getBranch() == null ? null : s.getReference(Branch.class, u.getBranch().getBranchId()));
            u.setEmail(emptyToNull(u.getEmail()));   // index UNIQUE lọc NULL nên "" sẽ bị coi là trùng nhau
            u.setPhone(emptyToNull(u.getPhone()));
            u.setPasswordHash(PasswordUtil.hash(rawPassword));
            s.persist(u);
            return true;
        });
    }

    /** Cập nhật thông tin. newRawPassword rỗng/null = giữ nguyên mật khẩu. */
    public boolean update(User form, String newRawPassword) {
        return write(s -> {
            User u = s.get(User.class, form.getUserId());
            if (u == null) return false;
            u.setFullName(form.getFullName());
            u.setEmail(emptyToNull(form.getEmail()));
            u.setPhone(emptyToNull(form.getPhone()));
            u.setRole(s.getReference(Role.class, form.getRole().getRoleId()));
            u.setBranch(form.getBranch() == null ? null : s.getReference(Branch.class, form.getBranch().getBranchId()));
            u.setActive(form.isActive());
            if (newRawPassword != null && !newRawPassword.isEmpty()) u.setPasswordHash(PasswordUtil.hash(newRawPassword));
            return true;
        });
    }

    /** "Xóa" = khóa tài khoản (active = false) để không vỡ khóa ngoại với Orders, Payments... */
    public boolean deactivate(int userId) {
        return write(s -> {
            User u = s.get(User.class, userId);
            if (u == null) return false;
            u.setActive(false);
            return true;
        });
    }

    public boolean emailExists(String email, int excludeUserId) {
        return count("select count(u) from User u where u.email = :v and u.userId <> :id", email, excludeUserId);
    }

    public boolean phoneExists(String phone, int excludeUserId) {
        return count("select count(u) from User u where u.phone = :v and u.userId <> :id", phone, excludeUserId);
    }

    private boolean count(String hql, String value, int excludeId) {
        Long n = read(s -> s.createQuery(hql, Long.class)
                .setParameter("v", value).setParameter("id", excludeId).uniqueResult());
        return n != null && n > 0;
    }

    private static String emptyToNull(String s) {
        return (s == null || s.trim().isEmpty()) ? null : s.trim();
    }
    public boolean emailExists(String email) {
        String v = emptyToNull(email);
        if (v == null) return false;
        Long n = read(s -> s.createQuery("select count(u) from User u where lower(u.email) = :v", Long.class)
                .setParameter("v", v.toLowerCase()).uniqueResult());
        return n != null && n > 0;
    }

    public boolean phoneExists(String phone) {
        String v = emptyToNull(phone);
        if (v == null) return false;
        Long n = read(s -> s.createQuery("select count(u) from User u where u.phone = :v", Long.class)
                .setParameter("v", v).uniqueResult());
        return n != null && n > 0;
    }

    /** Đăng ký tài khoản vai trò CUSTOMER và tạo hồ sơ Customers gắn với UserID. */
    public boolean registerCustomer(String fullName, String email, String phone, String rawPassword) {
        return write(s -> {
            Model.admin.Role customerRole = s.createQuery(
                    "from Role r where upper(r.roleCode) = 'CUSTOMER'", Model.admin.Role.class)
                    .setMaxResults(1).uniqueResult();
            if (customerRole == null) return false;

            String cleanEmail = emptyToNull(email);
            String cleanPhone = emptyToNull(phone);
            String cleanName = fullName == null ? "" : fullName.trim();

            Model.user.User u = new Model.user.User();
            u.setRole(customerRole);
            u.setBranch(null);
            u.setFullName(cleanName);
            u.setEmail(cleanEmail == null ? null : cleanEmail.toLowerCase());
            u.setPhone(cleanPhone);
            u.setPasswordHash(PasswordUtil.hash(rawPassword));
            u.setVerified(false);
            u.setActive(true);
            u.setCreatedAt(LocalDateTime.now());
            s.persist(u);
            s.flush();

            Model.user.Customer c = new Model.user.Customer();
            c.setUser(u);
            c.setFullName(cleanName);
            c.setEmail(u.getEmail());
            c.setPhone(cleanPhone);
            c.setCreatedAt(LocalDateTime.now());
            s.persist(c);
            return true;
        });
    }
}
