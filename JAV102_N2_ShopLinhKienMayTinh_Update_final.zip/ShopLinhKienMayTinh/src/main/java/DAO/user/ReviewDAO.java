package DAO.user;

import DAO.common.BaseDAO;
import Model.admin.Product;
import Model.dto.ProductRating;
import Model.user.Customer;
import Model.user.Review;

import java.time.LocalDateTime;
import java.util.List;

/** Đánh giá phía khách: chỉ người đã mua (đơn chưa hủy) mới được đánh giá, mỗi sản phẩm một lần. */
public class ReviewDAO extends BaseDAO<Review> {

    public ReviewDAO() { super(Review.class, "Review"); }

    public Product findProduct(int productId) {
        return read(s -> s.get(Product.class, productId));
    }

    /** Các sản phẩm khách đã mua (đơn chưa hủy). */
    public List<Product> findPurchasedProducts(int customerId) {
        return read(s -> s.createQuery(
                "select distinct d.product from OrderDetail d "
              + "where d.salesOrder.customer.customerId = :c and d.salesOrder.status <> 'Cancelled'", Product.class)
                .setParameter("c", customerId).getResultList());
    }

    public boolean hasPurchased(int customerId, int productId) {
        Long n = read(s -> s.createQuery(
                "select count(d) from OrderDetail d where d.salesOrder.customer.customerId = :c "
              + "and d.product.productId = :p and d.salesOrder.status <> 'Cancelled'", Long.class)
                .setParameter("c", customerId).setParameter("p", productId).uniqueResult());
        return n != null && n > 0;
    }

    public boolean hasReviewed(int customerId, int productId) {
        Long n = read(s -> s.createQuery(
                "select count(r) from Review r where r.customer.customerId = :c and r.product.productId = :p", Long.class)
                .setParameter("c", customerId).setParameter("p", productId).uniqueResult());
        return n != null && n > 0;
    }

    /** Gửi đánh giá. Trả về false nếu chưa mua, đã đánh giá rồi hoặc dữ liệu sai. */
    public boolean submit(int customerId, int productId, int rating, String comment) {
        if (rating < 1 || rating > 5) return false;
        if (!hasPurchased(customerId, productId) || hasReviewed(customerId, productId)) return false;
        return write(s -> {
            Review r = new Review();
            r.setProduct(s.getReference(Product.class, productId));
            r.setCustomer(s.getReference(Customer.class, customerId));
            r.setRating(rating);
            r.setComment(comment == null ? "" : comment.trim());
            r.setVisible(true);                 // quản trị có thể ẩn ở /admin/review
            r.setCreatedAt(LocalDateTime.now());
            s.persist(r);
            return true;
        });
    }

    public List<Review> findVisibleByProduct(int productId) {
        return read(s -> s.createQuery(
                "from Review r where r.product.productId = :p and r.visible = true order by r.createdAt desc", Review.class)
                .setParameter("p", productId).setMaxResults(100).getResultList());
    }

    public ProductRating getRating(int productId) {
        Object[] row = read(s -> s.createQuery(
                "select avg(r.rating), count(r) from Review r where r.product.productId = :p and r.visible = true", Object[].class)
                .setParameter("p", productId).uniqueResult());
        double avg = (row == null || row[0] == null) ? 0 : ((Number) row[0]).doubleValue();
        long total = (row == null || row[1] == null) ? 0 : ((Number) row[1]).longValue();
        return new ProductRating(avg, total);
    }
}
