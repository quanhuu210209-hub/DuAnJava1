package DAO.staff;

import DAO.common.BaseDAO;
import Model.staff.Invoice;
import Model.user.Order;
import Model.user.Payment;
import Model.user.User;
import Util.OrderConst;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InvoiceDAO extends BaseDAO<Invoice> {

    public InvoiceDAO() { super(Invoice.class, "Invoice"); }

    /** Tra cứu hóa đơn theo số hóa đơn, mã đơn hoặc số điện thoại khách. branchId = null: tất cả chi nhánh. */
    public List<Invoice> search(Integer branchId, String keyword) {
        StringBuilder hql = new StringBuilder("select i from Invoice i join fetch i.salesOrder o where 1 = 1 ");
        Map<String, Object> params = new HashMap<>();
        if (branchId != null) { hql.append("and o.branch.branchId = :b "); params.put("b", branchId); }
        if (keyword != null && !keyword.isEmpty()) {
            hql.append("and (lower(i.invoiceNo) like :k or lower(o.orderCode) like :k or o.customer.phone like :k) ");
            params.put("k", "%" + keyword.toLowerCase() + "%");
        }
        hql.append("order by i.issuedAt desc");
        return read(s -> {
            org.hibernate.query.Query<Invoice> q = s.createQuery(hql.toString(), Invoice.class).setMaxResults(100);
            params.forEach(q::setParameter);
            return q.getResultList();
        });
    }

    /** Hóa đơn kèm đơn hàng, chi tiết và sản phẩm để in. */
    public Invoice findFull(int id) {
        return read(s -> s.createQuery(
                "select i from Invoice i join fetch i.salesOrder o left join fetch o.details d left join fetch d.product where i.invoiceId = :id",
                Invoice.class).setParameter("id", id).uniqueResult());
    }

    public Invoice findByOrderId(int orderId) {
        return read(s -> s.createQuery("from Invoice i where i.salesOrder.orderId = :o", Invoice.class)
                .setParameter("o", orderId).setMaxResults(1).uniqueResult());
    }

    public List<Payment> paymentsOf(int orderId) {
        return read(s -> s.createQuery("from Payment p where p.salesOrder.orderId = :o order by p.paymentId", Payment.class)
                .setParameter("o", orderId).getResultList());
    }

    /** Xuất hóa đơn cho đơn hàng; đơn đã có hóa đơn thì trả lại hóa đơn cũ. Trả về null nếu thất bại. */
    public Invoice issue(int orderId, int staffId) {
        Invoice existing = findByOrderId(orderId);
        if (existing != null) return existing;
        Invoice[] out = new Invoice[1];
        boolean ok = write(s -> {
            Invoice inv = new Invoice();
            inv.setInvoiceNo(OrderConst.newCode("HD"));
            inv.setSalesOrder(s.getReference(Order.class, orderId));
            inv.setIssuedBy(s.getReference(User.class, staffId));
            inv.setIssuedAt(LocalDateTime.now());
            inv.setPrintCount(0);
            s.persist(inv);
            out[0] = inv;
            return true;
        });
        return ok ? out[0] : null;
    }

    /** Tăng số lần in. */
    public void markPrinted(int id) {
        write(s -> {
            Invoice inv = s.get(Invoice.class, id);
            if (inv == null) return false;
            inv.setPrintCount(inv.getPrintCount() + 1);
            return true;
        });
    }
}
