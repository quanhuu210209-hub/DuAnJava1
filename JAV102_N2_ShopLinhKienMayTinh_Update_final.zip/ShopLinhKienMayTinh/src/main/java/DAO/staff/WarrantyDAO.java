package DAO.staff;

import DAO.common.BaseDAO;
import DAO.manager.BranchInventoryDAO;
import Model.manager.BranchInventory;
import Model.admin.Branch;
import Model.staff.WarrantyRequest;
import Model.user.Customer;
import Model.user.OrderDetail;
import Model.user.User;
import Util.OrderConst;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WarrantyDAO extends BaseDAO<WarrantyRequest> {

    public WarrantyDAO() { super(WarrantyRequest.class, "WarrantyRequest"); }

    /** Danh sách yêu cầu. branchId null = tất cả chi nhánh; status / keyword rỗng thì không lọc (keyword: mã yêu cầu hoặc SĐT khách). */
    public List<WarrantyRequest> search(Integer branchId, String status, String keyword) {
        StringBuilder hql = new StringBuilder("select w from WarrantyRequest w where 1 = 1 ");
        Map<String, Object> params = new HashMap<>();
        if (branchId != null) { hql.append("and w.branch.branchId = :b "); params.put("b", branchId); }
        if (status != null && !status.isEmpty()) { hql.append("and w.status = :st "); params.put("st", status); }
        if (keyword != null && !keyword.isEmpty()) {
            hql.append("and (lower(w.requestCode) like :k or w.customer.phone like :k) ");
            params.put("k", "%" + keyword.toLowerCase() + "%");
        }
        hql.append("order by w.createdAt desc");
        return read(s -> {
            org.hibernate.query.Query<WarrantyRequest> q = s.createQuery(hql.toString(), WarrantyRequest.class).setMaxResults(200);
            params.forEach(q::setParameter);
            return q.getResultList();
        });
    }

    /** Tổng số lượng đã được yêu cầu bảo hành/đổi trả cho một dòng đơn hàng (để không vượt số lượng đã mua). */
    public int requestedQuantity(int orderDetailId) {
        Long n = read(s -> s.createQuery(
                "select coalesce(sum(w.quantity), 0) from WarrantyRequest w where w.orderDetail.orderDetailId = :d", Long.class)
                .setParameter("d", orderDetailId).uniqueResult());
        return n == null ? 0 : n.intValue();
    }

    /** Tiếp nhận yêu cầu tại quầy. Trả về mã yêu cầu mới, 0 nếu thất bại. */
    public int receive(int branchId, int staffId, int orderDetailId, int customerId,
                       String type, int quantity, String reason) {
        int[] out = {0};
        boolean ok = write(s -> {
            LocalDateTime now = LocalDateTime.now();
            WarrantyRequest w = new WarrantyRequest();
            w.setRequestCode(OrderConst.newCode("BH"));
            w.setOrderDetail(s.getReference(OrderDetail.class, orderDetailId));
            w.setCustomer(s.getReference(Customer.class, customerId));
            w.setBranch(s.getReference(Branch.class, branchId));
            w.setRequestType(type);
            w.setSource(OrderConst.WARRANTY_SOURCE);
            w.setQuantity(quantity);
            w.setReason(reason);
            w.setReceivedBy(s.getReference(User.class, staffId));
            w.setStatus(OrderConst.WARRANTY_PENDING);
            w.setRefundApproved(false);
            w.setCreatedAt(now);
            w.setUpdatedAt(now);
            s.persist(w);
            out[0] = w.getRequestId();
            return true;
        });
        return ok ? out[0] : 0;
    }
    /** Duyệt / từ chối / hoàn tất: chỉ chuyển được khi yêu cầu đang ở một trong các trạng thái from. */
    public boolean handle(int id, int staffId, List<String> from, String to, String note) {
        return write(s -> {
            WarrantyRequest w = s.get(WarrantyRequest.class, id);
            if (w == null || !from.contains(w.getStatus())) return false;
            LocalDateTime now = LocalDateTime.now();
            w.setStatus(to);
            w.setHandledBy(s.getReference(User.class, staffId));
            if (!note.isEmpty()) w.setResolutionNote(note);
            w.setUpdatedAt(now);
            if (OrderConst.WARRANTY_DONE.equals(to)) restock(s, w, staffId, now);
            return true;
        });
    }

    /** Hoàn tiền (chỉ yêu cầu Trả hàng đang xử lý): số tiền <= đơn giá x số lượng, xong thì hoàn tất và nhập lại kho. */
    public boolean refund(int id, int staffId, BigDecimal amount, String note) {
        return write(s -> {
            WarrantyRequest w = s.get(WarrantyRequest.class, id);
            if (w == null || amount == null || w.isRefundApproved()
                    || !OrderConst.TYPE_RETURN.equals(w.getRequestType())
                    || !OrderConst.WARRANTY_PROCESSING.equals(w.getStatus())) return false;
            BigDecimal max = w.getOrderDetail().getUnitPrice().multiply(BigDecimal.valueOf(w.getQuantity()));
            if (amount.signum() < 0 || amount.compareTo(max) > 0) return false;
            LocalDateTime now = LocalDateTime.now();
            w.setRefundApproved(true);
            w.setRefundAmount(amount);
            w.setStatus(OrderConst.WARRANTY_DONE);
            w.setHandledBy(s.getReference(User.class, staffId));
            if (!note.isEmpty()) w.setResolutionNote(note);
            w.setUpdatedAt(now);
            restock(s, w, staffId, now);
            return true;
        });
    }

    /** Khách trả hàng: cộng lại tồn chi nhánh và ghi lịch sử kho. */
    private void restock(org.hibernate.Session s, WarrantyRequest w, int staffId, LocalDateTime now) {
        if (!OrderConst.TYPE_RETURN.equals(w.getRequestType())) return;
        BranchInventory inv = BranchInventoryDAO.of(s, w.getBranch().getBranchId(), w.getOrderDetail().getProduct().getProductId());
        if (inv == null) return;
        BranchInventoryDAO.moveStock(s, inv, w.getQuantity(), OrderConst.MOVEMENT_RETURN, OrderConst.REF_WARRANTY,
                w.getRequestId(), "Khách trả hàng " + w.getRequestCode(), s.getReference(User.class, staffId), now);
    }
}
