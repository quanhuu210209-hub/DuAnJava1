package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.Branch;

import java.util.List;

public class BranchDAO extends BaseDAO<Branch> {

    public BranchDAO() { super(Branch.class, "Branch"); }

    /** Chi nhánh đang hoạt động (dùng cho dropdown). */
    public List<Branch> findActive() {
        return read(s -> s.createQuery(
                "from Branch b where b.active = true order by b.branchName", Branch.class).getResultList());
    }
}
