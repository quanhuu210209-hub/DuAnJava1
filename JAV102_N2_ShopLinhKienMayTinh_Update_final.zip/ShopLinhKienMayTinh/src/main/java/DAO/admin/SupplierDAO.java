package DAO.admin;

import DAO.common.BaseDAO;
import Model.manager.Supplier;

import java.util.List;

public class SupplierDAO extends BaseDAO<Supplier> {

    public SupplierDAO() { super(Supplier.class, "Supplier"); }

    @Override
    public List<Supplier> findAll() {
        return read(s -> s.createQuery("from Supplier x order by x.supplierName", Supplier.class).getResultList());
    }

    /** Tìm theo tên hoặc số điện thoại (keyword rỗng = lấy tất cả). */
    public List<Supplier> search(String keyword) {
        return read(s -> s.createQuery(
                "from Supplier x where x.supplierName like :k or x.phone like :k order by x.supplierName", Supplier.class)
                .setParameter("k", "%" + keyword + "%").getResultList());
    }

    public boolean update(Supplier form) {
        return write(s -> {
            Supplier x = s.get(Supplier.class, form.getSupplierId());
            if (x == null) return false;
            x.setSupplierName(form.getSupplierName());
            x.setBranch(form.getBranch());
            x.setAddress(form.getAddress());
            x.setPhone(form.getPhone());
            x.setEmail(form.getEmail());
            x.setActive(form.isActive());
            return true;
        });
    }

    public boolean nameExists(String name, int excludeId) {
        Long n = read(s -> s.createQuery(
                "select count(x) from Supplier x where x.supplierName = :n and x.supplierId <> :id", Long.class)
                .setParameter("n", name).setParameter("id", excludeId).uniqueResult());
        return n != null && n > 0;
    }
}
