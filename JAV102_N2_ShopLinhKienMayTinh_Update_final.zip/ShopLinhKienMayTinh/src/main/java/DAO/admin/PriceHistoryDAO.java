package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.PriceHistory;

import java.util.List;

public class PriceHistoryDAO extends BaseDAO<PriceHistory> {

    public PriceHistoryDAO() { super(PriceHistory.class, "PriceHistory"); }

    /** Lịch sử giá mới nhất trước, lọc theo tên hoặc SKU sản phẩm (rỗng = tất cả), tối đa 200 dòng. */
    public List<PriceHistory> search(String keyword) {
        return read(s -> s.createQuery(
                "select h from PriceHistory h where lower(h.product.productName) like :k or lower(h.product.sku) like :k "
              + "order by h.changedAt desc", PriceHistory.class)
                .setParameter("k", "%" + keyword.toLowerCase() + "%")
                .setMaxResults(200).getResultList());
    }
}
