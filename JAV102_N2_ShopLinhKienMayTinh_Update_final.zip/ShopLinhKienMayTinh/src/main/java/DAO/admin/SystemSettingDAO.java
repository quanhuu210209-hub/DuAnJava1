package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.SystemSetting;
import Model.user.User;

import java.time.LocalDateTime;
import java.util.List;

public class SystemSettingDAO extends BaseDAO<SystemSetting> {

    public SystemSettingDAO() { super(SystemSetting.class, "SystemSetting"); }

    @Override
    public List<SystemSetting> findAll() {
        return read(s -> s.createQuery("from SystemSetting x order by x.settingKey", SystemSetting.class).getResultList());
    }

    /** Chỉ đổi giá trị của một cấu hình đã có (khóa cấu hình do hệ thống quy định). */
    public boolean updateValue(String key, String value, int userId) {
        return write(s -> {
            SystemSetting x = s.get(SystemSetting.class, key);
            if (x == null) return false;
            x.setSettingValue(value);
            x.setUpdatedBy(s.get(User.class, userId));
            x.setUpdatedAt(LocalDateTime.now());
            return true;
        });
    }
}
