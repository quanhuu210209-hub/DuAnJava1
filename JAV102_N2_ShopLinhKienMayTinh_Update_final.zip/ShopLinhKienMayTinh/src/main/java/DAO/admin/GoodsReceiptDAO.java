package DAO.admin;

import DAO.common.BaseDAO;
import DAO.manager.BranchInventoryDAO;
import Model.admin.Branch;
import Model.admin.Product;
import Model.manager.BranchInventory;
import Model.manager.BranchInventoryId;
import Model.manager.GoodsReceipt;
import Model.manager.GoodsReceiptDetail;
import Model.manager.StockMovement;
import Util.OrderConst;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.query.Query;

/** Phiếu nhập hàng: lưu phiếu + chi tiết, cộng tồn kho chi nhánh, ghi StockMovements trong CÙNG transaction. */
public class GoodsReceiptDAO extends BaseDAO<GoodsReceipt> {

    public GoodsReceiptDAO() { super(GoodsReceipt.class, "GoodsReceipt"); }

    /** Tìm theo mã phiếu hoặc tên nhà cung cấp; branchId null = tất cả chi nhánh. */
    public List<GoodsReceipt> search(String keyword, Integer branchId) {
        StringBuilder hql = new StringBuilder(
                "from GoodsReceipt r join fetch r.branch b join fetch r.supplier s left join fetch r.createdBy where 1 = 1 ");
        Map<String, Object> params = new HashMap<>();
        if (keyword != null && !keyword.trim().isEmpty()) {
            hql.append("and (r.receiptCode like :kw or s.supplierName like :kw) ");
            params.put("kw", "%" + keyword.trim() + "%");
        }
        if (branchId != null) { hql.append("and b.branchId = :br "); params.put("br", branchId); }
        hql.append("order by r.receiptDate desc");

        return read(s -> {
            Query<GoodsReceipt> q = s.createQuery(hql.toString(), GoodsReceipt.class);
            params.forEach(q::setParameter);
            return q.setMaxResults(200).getResultList();
        });
    }

    /** Phiếu kèm chi nhánh, nhà cung cấp, người tạo (để hiển thị sau khi đóng session). */
    public GoodsReceipt findDetail(int id) {
        return read(s -> s.createQuery(
                "from GoodsReceipt r join fetch r.branch join fetch r.supplier left join fetch r.createdBy where r.receiptId = :id",
                GoodsReceipt.class).setParameter("id", id).uniqueResult());
    }

    public List<GoodsReceiptDetail> lines(int receiptId) {
        return read(s -> s.createQuery(
                "from GoodsReceiptDetail d join fetch d.product where d.receipt.receiptId = :id order by d.receiptDetailId",
                GoodsReceiptDetail.class).setParameter("id", receiptId).getResultList());
    }

    /** Lưu phiếu. Người gọi phải gán sẵn code, branch, supplier, createdBy và các dòng đã hợp lệ. */
    public boolean create(GoodsReceipt r, List<GoodsReceiptDetail> lines) {
        return write(s -> {
            LocalDateTime now = LocalDateTime.now();
            BigDecimal total = BigDecimal.ZERO;
            for (GoodsReceiptDetail d : lines)
                total = total.add(d.getImportPrice().multiply(BigDecimal.valueOf(d.getQuantity())));
            r.setReceiptDate(now);
            r.setTotalAmount(total);
            s.persist(r);
            for (GoodsReceiptDetail d : lines) {
                d.setReceipt(r);
                s.persist(d);
                addStock(s, r, d, now);
            }
            return true;
        });
    }

    /** Cộng tồn (tạo dòng tồn nếu chưa có; giữ nguyên trạng thái ẩn) và ghi lịch sử nhập kho. */
    private static void addStock(Session s, GoodsReceipt r, GoodsReceiptDetail d, LocalDateTime now) {
        int branchId = r.getBranch().getBranchId();
        int productId = d.getProduct().getProductId();
        BranchInventory inv = BranchInventoryDAO.of(s, branchId, productId);
        boolean isNew = inv == null;
        if (isNew) {
            inv = new BranchInventory();
            inv.setId(new BranchInventoryId(branchId, productId));
            inv.setBranch(s.getReference(Branch.class, branchId));
            inv.setProduct(s.getReference(Product.class, productId));
            inv.setLowStockThreshold(5);   // trùng DEFAULT trong DB
        }
        inv.setQuantity(inv.getQuantity() + d.getQuantity());
        inv.setUpdatedAt(now);
        if (isNew) s.persist(inv);

        if (!OrderConst.RECORD_STOCK_MOVEMENT) return;
        StockMovement m = new StockMovement();
        m.setBranch(r.getBranch());
        m.setProduct(d.getProduct());
        m.setMovementType(OrderConst.MOVEMENT_IMPORT);
        m.setQuantityChange(d.getQuantity());
        m.setRefType(OrderConst.REF_RECEIPT);
        m.setRefId(r.getReceiptId());
        m.setNote("Nhập hàng " + r.getReceiptCode());
        m.setCreatedBy(r.getCreatedBy());
        m.setCreatedAt(now);
        s.persist(m);
    }
}
