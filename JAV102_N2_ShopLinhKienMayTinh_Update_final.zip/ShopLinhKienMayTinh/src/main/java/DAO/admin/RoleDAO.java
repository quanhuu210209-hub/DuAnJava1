package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.Role;

import java.util.List;

public class RoleDAO extends BaseDAO<Role> {

    public RoleDAO() { super(Role.class, "Role"); }

    @Override
    public List<Role> findAll() {
        return read(s -> s.createQuery("from Role r order by r.roleId", Role.class).getResultList());
    }
}
