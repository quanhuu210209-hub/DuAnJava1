package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.AuditLog;
import Model.user.User;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.query.Query;

/** Nhật ký hệ thống: ghi (log) và tra cứu (search). Chỉ thêm, không sửa/xóa. */
public class AuditLogDAO extends BaseDAO<AuditLog> {

    public AuditLogDAO() { super(AuditLog.class, "AuditLog"); }

    /** Ghi một dòng nhật ký. Lỗi ghi nhật ký không được làm hỏng nghiệp vụ chính nên chỉ trả true/false. */
    public static boolean log(User user, String action, String entityType, Object entityId, String detail) {
        AuditLog a = new AuditLog();
        a.setUser(user);
        a.setAction(action);
        a.setEntityType(entityType);
        a.setEntityId(entityId == null ? null : String.valueOf(entityId));
        a.setDetail(detail != null && detail.length() > 500 ? detail.substring(0, 500) : detail);
        a.setCreatedAt(LocalDateTime.now());
        return new AuditLogDAO().insert(a);
    }

    /** Tìm theo đối tượng, chi tiết hoặc tên người thực hiện; action rỗng = tất cả. Mới nhất trước, tối đa 200 dòng. */
    public List<AuditLog> search(String keyword, String action) {
        StringBuilder hql = new StringBuilder("from AuditLog a left join fetch a.user u where 1 = 1 ");
        Map<String, Object> params = new HashMap<>();
        if (keyword != null && !keyword.trim().isEmpty()) {
            hql.append("and (a.entityType like :kw or a.detail like :kw or u.fullName like :kw) ");
            params.put("kw", "%" + keyword.trim() + "%");
        }
        if (action != null && !action.trim().isEmpty()) {
            hql.append("and a.action = :act ");
            params.put("act", action.trim());
        }
        hql.append("order by a.createdAt desc, a.auditId desc");

        return read(s -> {
            Query<AuditLog> q = s.createQuery(hql.toString(), AuditLog.class);
            params.forEach(q::setParameter);
            return q.setMaxResults(200).getResultList();
        });
    }

    /** Các loại hành động đã có (dùng cho dropdown lọc). */
    public List<String> actions() {
        return read(s -> s.createQuery("select distinct a.action from AuditLog a order by a.action", String.class)
                .getResultList());
    }
}
