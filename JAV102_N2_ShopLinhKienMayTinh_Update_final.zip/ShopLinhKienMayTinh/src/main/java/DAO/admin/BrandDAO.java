package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.Brand;

import java.util.List;

public class BrandDAO extends BaseDAO<Brand> {

    public BrandDAO() { super(Brand.class, "Brand"); }

    @Override
    public List<Brand> findAll() {
        return read(s -> s.createQuery("from Brand b order by b.brandName", Brand.class).getResultList());
    }

    public boolean update(Brand form) {
        return write(s -> {
            Brand b = s.get(Brand.class, form.getBrandId());
            if (b == null) return false;
            b.setBrandName(form.getBrandName());
            b.setLogoUrl(form.getLogoUrl());
            b.setActive(form.isActive());
            return true;
        });
    }

    public boolean nameExists(String name, int excludeId) {
        Long n = read(s -> s.createQuery(
                "select count(b) from Brand b where b.brandName = :n and b.brandId <> :id", Long.class)
                .setParameter("n", name).setParameter("id", excludeId).uniqueResult());
        return n != null && n > 0;
    }
}
