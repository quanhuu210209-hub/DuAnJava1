package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.Category;

import java.util.List;

public class CategoryDAO extends BaseDAO<Category> {

    public CategoryDAO() { super(Category.class, "Category"); }

    @Override
    public List<Category> findAll() {
        return read(s -> s.createQuery("from Category c order by c.categoryName", Category.class).getResultList());
    }

    public boolean update(Category form) {
        return write(s -> {
            Category c = s.get(Category.class, form.getCategoryId());
            if (c == null) return false;
            c.setCategoryName(form.getCategoryName());
            c.setDescription(form.getDescription());
            c.setActive(form.isActive());
            return true;                       // entity đang được quản lý -> tự UPDATE khi commit
        });
    }

    /** Tên đã tồn tại chưa? (excludeId = 0 khi thêm mới) */
    public boolean nameExists(String name, int excludeId) {
        Long n = read(s -> s.createQuery(
                "select count(c) from Category c where c.categoryName = :n and c.categoryId <> :id", Long.class)
                .setParameter("n", name).setParameter("id", excludeId).uniqueResult());
        return n != null && n > 0;
    }
}
