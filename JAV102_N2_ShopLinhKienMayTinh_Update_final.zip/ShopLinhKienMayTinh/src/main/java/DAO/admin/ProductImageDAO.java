package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.Product;
import Model.admin.ProductImage;

import java.util.List;

public class ProductImageDAO extends BaseDAO<ProductImage> {

    public ProductImageDAO() { super(ProductImage.class, "ProductImage"); }

    public List<ProductImage> findByProduct(int productId) {
        return read(s -> s.createQuery(
                "from ProductImage i where i.product.productId = :p order by i.sortOrder, i.imageId", ProductImage.class)
                .setParameter("p", productId).getResultList());
    }

    public boolean add(int productId, String imageUrl, int sortOrder) {
        return write(s -> {
            Product p = s.get(Product.class, productId);
            if (p == null) return false;
            ProductImage i = new ProductImage();
            i.setProduct(p);
            i.setImageUrl(imageUrl);
            i.setSortOrder(sortOrder);
            s.persist(i);
            return true;
        });
    }
}
