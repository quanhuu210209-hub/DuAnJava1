package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.PriceHistory;
import Model.admin.Brand;
import Model.admin.Category;
import Model.admin.Product;
import Model.user.User;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.*;

public class ProductDAO extends BaseDAO<Product> {

    public ProductDAO() { super(Product.class, "Product"); }

    /**
     * Tìm/lọc sản phẩm. Tham số nào null thì bỏ qua.
     * @param onlyActive true: chỉ lấy sản phẩm đang bán (trang khách hàng)
     */
    public List<Product> search(String keyword, Integer categoryId, Integer brandId, boolean onlyActive) {
        StringBuilder hql = new StringBuilder("from Product p where 1 = 1 ");
        Map<String, Object> params = new HashMap<>();
        if (keyword != null && !keyword.trim().isEmpty()) {
            hql.append("and (p.productName like :kw or p.sku like :kw) ");
            params.put("kw", "%" + keyword.trim() + "%");
        }
        if (categoryId != null) { hql.append("and p.category.categoryId = :cat "); params.put("cat", categoryId); }
        if (brandId != null)    { hql.append("and p.brand.brandId = :brand ");     params.put("brand", brandId); }
        if (onlyActive)         { hql.append("and p.status = 'Active' "); }
        hql.append("order by p.productId desc");

        return read(s -> {
            Query<Product> q = s.createQuery(hql.toString(), Product.class);
            params.forEach(q::setParameter);
            List<Product> list = q.getResultList();
            fillStock(s, list);
            return list;
        });
    }

    @Override
    public List<Product> findAll() {
        return search(null, null, null, false);
    }

    @Override
    public Product findById(Serializable id) {
        return read(s -> {
            Product p = s.get(Product.class, id);
            if (p != null) fillStock(s, Collections.singletonList(p));
            return p;
        });
    }

    /**
     * Cập nhật sản phẩm. Nếu giá đổi thì ghi luôn lịch sử giá (PriceHistory) trong CÙNG transaction.
     * @param form đối tượng lấy từ form (category, brand, price... đã gán)
     */
    public boolean update(Product form, int changedByUserId) {
        return write(s -> {
            Product p = s.get(Product.class, form.getProductId());
            if (p == null) return false;

            p.setSku(form.getSku());
            p.setProductName(form.getProductName());
            p.setCategory(s.getReference(Category.class, form.getCategory().getCategoryId()));
            p.setBrand(s.getReference(Brand.class, form.getBrand().getBrandId()));
            p.setDescription(form.getDescription());
            p.setWarrantyMonths(form.getWarrantyMonths());
            p.setThumbnailUrl(form.getThumbnailUrl());
            p.setStatus(form.getStatus());
            p.setUpdatedAt(LocalDateTime.now());

            if (p.getPrice().compareTo(form.getPrice()) != 0) {
                PriceHistory h = new PriceHistory();
                h.setProduct(p);
                h.setOldPrice(p.getPrice());
                h.setNewPrice(form.getPrice());
                h.setChangedBy(s.getReference(User.class, changedByUserId));
                h.setReason("Điều chỉnh giá trên trang quản trị");
                s.persist(h);
                p.setPrice(form.getPrice());
            }
            return true;
        });
    }

    @Override
    public boolean insert(Product p) {
        return write(s -> {
            p.setCategory(s.getReference(Category.class, p.getCategory().getCategoryId()));
            p.setBrand(s.getReference(Brand.class, p.getBrand().getBrandId()));
            s.persist(p);
            return true;
        });
    }

    /** "Xóa" = ngừng kinh doanh (Status = 'Discontinued'), giữ nguyên dữ liệu đơn hàng cũ. */
    public boolean discontinue(int productId) {
        return write(s -> {
            Product p = s.get(Product.class, productId);
            if (p == null) return false;
            p.setStatus("Discontinued");
            p.setUpdatedAt(LocalDateTime.now());
            return true;
        });
    }

    public boolean skuExists(String sku, int excludeId) {
        Long n = read(s -> s.createQuery(
                "select count(p) from Product p where p.sku = :v and p.productId <> :id", Long.class)
                .setParameter("v", sku).setParameter("id", excludeId).uniqueResult());
        return n != null && n > 0;
    }

    /** Gán tổng tồn kho (mọi chi nhánh) cho từng sản phẩm bằng 1 truy vấn gom nhóm. */
    private void fillStock(Session s, List<Product> products) {
        if (products.isEmpty()) return;
        List<Object[]> rows = s.createQuery(
                "select i.id.productId, sum(i.quantity) from BranchInventory i group by i.id.productId",
                Object[].class).getResultList();
        Map<Integer, Long> stock = new HashMap<>();
        for (Object[] r : rows) stock.put((Integer) r[0], ((Number) r[1]).longValue());
        for (Product p : products) p.setStock(stock.getOrDefault(p.getProductId(), 0L).intValue());
    }
}
