package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.Product;
import Model.admin.ProductSpec;

import java.util.List;

public class ProductSpecDAO extends BaseDAO<ProductSpec> {

    public ProductSpecDAO() { super(ProductSpec.class, "ProductSpec"); }

    public List<ProductSpec> findByProduct(int productId) {
        return read(s -> s.createQuery(
                "from ProductSpec x where x.product.productId = :p order by x.specName", ProductSpec.class)
                .setParameter("p", productId).getResultList());
    }

    /** Thêm thông số; nếu sản phẩm đã có thông số cùng tên thì cập nhật giá trị. */
    public boolean save(int productId, String name, String value) {
        return write(s -> {
            Product p = s.get(Product.class, productId);
            if (p == null) return false;
            ProductSpec x = s.createQuery(
                    "from ProductSpec x where x.product.productId = :p and x.specName = :n", ProductSpec.class)
                    .setParameter("p", productId).setParameter("n", name).uniqueResult();
            if (x == null) {
                x = new ProductSpec();
                x.setProduct(p);
                x.setSpecName(name);
                s.persist(x);
            }
            x.setSpecValue(value);
            return true;
        });
    }
}
