package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.Policy;
import Model.user.User;

import java.time.LocalDateTime;
import java.util.List;

public class PolicyDAO extends BaseDAO<Policy> {

    public PolicyDAO() { super(Policy.class, "Policy"); }

    @Override
    public List<Policy> findAll() {
        return read(s -> s.createQuery("from Policy p order by p.policyType, p.title", Policy.class).getResultList());
    }

    public boolean update(Policy form, int userId) {
        return write(s -> {
            Policy p = s.get(Policy.class, form.getPolicyId());
            if (p == null) return false;
            p.setPolicyType(form.getPolicyType());
            p.setTitle(form.getTitle());
            p.setContent(form.getContent());
            p.setActive(form.isActive());
            p.setUpdatedBy(s.get(User.class, userId));
            p.setUpdatedAt(LocalDateTime.now());
            return true;
        });
    }
}
