package DAO.admin;

import DAO.common.BaseDAO;
import Model.staff.AssemblyJob;
import Model.user.Order;
import Model.user.User;

import java.util.List;

public class AssemblyJobDAO extends BaseDAO<AssemblyJob> {

    public AssemblyJobDAO() { super(AssemblyJob.class, "AssemblyJob"); }

    /** Danh sách việc lắp đặt, mới giao trước. status rỗng = tất cả. */
    public List<AssemblyJob> search(String status) {
        String hql = "from AssemblyJob j " + (status.isEmpty() ? "" : "where j.status = :st ") + "order by j.assignedAt desc";
        return read(s -> {
            org.hibernate.query.Query<AssemblyJob> q = s.createQuery(hql, AssemblyJob.class);
            if (!status.isEmpty()) q.setParameter("st", status);
            return q.getResultList();
        });
    }

    /** Đơn chưa hủy và chưa có việc lắp đặt (dùng cho dropdown khi giao việc mới). */
    public List<Order> availableOrders() {
        return read(s -> s.createQuery(
                "select o from Orders o where o.status <> 'Cancelled' "
              + "and o.orderId not in (select j.salesOrder.orderId from AssemblyJob j) order by o.createdAt desc",
                Order.class).setMaxResults(200).getResultList());
    }

    /** Nhân viên / quản lý đang hoạt động và thuộc một chi nhánh (người được giao việc). */
    public List<User> assignees() {
        return read(s -> s.createQuery(
                "select u from User u where u.active = true and upper(u.role.roleCode) in ('STAFF', 'MANAGER') "
              + "and u.branch is not null order by u.fullName", User.class).getResultList());
    }

    /** Chỉ đổi người thực hiện và yêu cầu; trả về false nếu việc không tồn tại hoặc đã hoàn thành. */
    public boolean update(AssemblyJob form) {
        return write(s -> {
            AssemblyJob j = s.get(AssemblyJob.class, form.getJobId());
            if (j == null || "Done".equals(j.getStatus())) return false;
            j.setAssignedTo(form.getAssignedTo());
            j.setRequirement(form.getRequirement());
            return true;
        });
    }
}
