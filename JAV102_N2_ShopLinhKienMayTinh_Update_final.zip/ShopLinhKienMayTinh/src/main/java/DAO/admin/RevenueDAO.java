package DAO.admin;

import Util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.query.NativeQuery;

import java.time.LocalDate;
import java.util.List;

/**
 * Thống kê doanh thu. Tính đơn đã thanh toán và chưa hủy (cùng điều kiện với các view vw_DailyRevenue,
 * vw_BestSellers, vw_StaffRevenue) nhưng lọc thêm theo khoảng ngày và chi nhánh.
 * Mỗi dòng kết quả là Object[] để JSP đọc theo chỉ số (${r[0]}, ${r[1]}...).
 */
public class RevenueDAO {

    private static final String WHERE =
            " where o.Status <> 'Cancelled' and o.PaymentStatus = 'Paid'"
          + " and o.CreatedAt >= :from and o.CreatedAt < :to";

    /** {tổng doanh thu, số đơn} */
    public Object[] summary(LocalDate from, LocalDate to, Integer branchId) {
        List<Object[]> rows = run("select coalesce(sum(o.TotalAmount), 0), count(*) from Orders o",
                "", from, to, branchId);
        return rows.get(0);
    }

    /** {ngày dd/MM/yyyy, số đơn, doanh thu}, ngày mới nhất trước. */
    public List<Object[]> byDay(LocalDate from, LocalDate to, Integer branchId) {
        return run("select min(convert(varchar(10), o.CreatedAt, 103)), count(*), sum(o.TotalAmount) from Orders o",
                " group by cast(o.CreatedAt as date) order by cast(o.CreatedAt as date) desc",
                from, to, branchId);
    }

    /** {tên sản phẩm, số lượng bán, doanh thu}, top 10 theo số lượng. */
    public List<Object[]> bestSellers(LocalDate from, LocalDate to, Integer branchId) {
        return run("select top 10 p.ProductName, sum(od.Quantity), sum(od.LineTotal) from Orders o"
                + " join OrderDetails od on od.OrderID = o.OrderID join Products p on p.ProductID = od.ProductID",
                " group by p.ProductID, p.ProductName order by sum(od.Quantity) desc",
                from, to, branchId);
    }

    /** {tên nhân viên, số đơn lập, doanh thu}, đơn lập tại quầy. */
    public List<Object[]> byStaff(LocalDate from, LocalDate to, Integer branchId) {
        return run("select u.FullName, count(*), sum(o.TotalAmount) from Orders o join Users u on u.UserID = o.CreatedBy",
                " group by o.CreatedBy, u.FullName order by sum(o.TotalAmount) desc",
                from, to, branchId);
    }

    /** Ghép: select + điều kiện chung + (chi nhánh) + group/order. `to` là ngày cuối được tính. */
    private List<Object[]> run(String select, String tail, LocalDate from, LocalDate to, Integer branchId) {
        String sql = select + WHERE + (branchId == null ? "" : " and o.BranchID = :b") + tail;
        try (Session s = HibernateUtil.openSession()) {
            NativeQuery<Object[]> q = s.createNativeQuery(sql, Object[].class);
            q.setParameter("from", from.atStartOfDay());
            q.setParameter("to", to.plusDays(1).atStartOfDay());
            if (branchId != null) q.setParameter("b", branchId);
            return q.getResultList();
        }
    }
}
