package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.PaymentMethod;

import java.util.List;

public class PaymentMethodDAO extends BaseDAO<PaymentMethod> {

    public PaymentMethodDAO() { super(PaymentMethod.class, "PaymentMethod"); }

    /** Các phương thức thanh toán đang được hỗ trợ. */
    public List<PaymentMethod> findActive() {
        return read(s -> s.createQuery(
                "from PaymentMethod m where m.active = true order by m.paymentMethodId", PaymentMethod.class).getResultList());
    }
}
