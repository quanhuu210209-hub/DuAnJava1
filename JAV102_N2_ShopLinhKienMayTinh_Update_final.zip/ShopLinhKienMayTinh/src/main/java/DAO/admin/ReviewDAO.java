package DAO.admin;

import DAO.common.BaseDAO;
import Model.user.Review;

import java.util.List;

public class ReviewDAO extends BaseDAO<Review> {

    public ReviewDAO() { super(Review.class, "Review"); }

    /**
     * Đánh giá mới nhất trước, tối đa 200 dòng.
     * status: "visible" (đang hiện) | "hidden" (đang ẩn) | rỗng (tất cả); keyword: tên sản phẩm hoặc nội dung.
     */
    public List<Review> search(String status, String keyword) {
        String hql = "select r from Review r where (lower(r.product.productName) like :k or lower(r.comment) like :k) "
                   + ("visible".equals(status) ? "and r.visible = true " : "hidden".equals(status) ? "and r.visible = false " : "")
                   + "order by r.createdAt desc";
        return read(s -> s.createQuery(hql, Review.class)
                .setParameter("k", "%" + keyword.toLowerCase() + "%")
                .setMaxResults(200).getResultList());
    }

    /** Ẩn hoặc hiện lại một đánh giá. */
    public boolean setVisible(int reviewId, boolean visible) {
        return write(s -> {
            Review r = s.get(Review.class, reviewId);
            if (r == null) return false;
            r.setVisible(visible);
            return true;
        });
    }
}
