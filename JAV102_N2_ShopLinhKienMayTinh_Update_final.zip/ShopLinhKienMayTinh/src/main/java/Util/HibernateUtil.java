package Util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Giữ SessionFactory duy nhất của ứng dụng (tạo 1 lần, rất tốn kém).
 * Cấu hình đọc từ src/main/resources/hibernate.cfg.xml.
 */
public class HibernateUtil {

    private static SessionFactory factory;

    private HibernateUtil() {}

    public static synchronized SessionFactory getSessionFactory() {
        if (factory == null || factory.isClosed()) {
            try {
                factory = new Configuration().configure().buildSessionFactory();
            } catch (Throwable ex) {
                ex.printStackTrace();   // lỗi cấu hình/kết nối CSDL hiện rõ trong console Tomcat
                throw new ExceptionInInitializerError(ex);
            }
        }
        return factory;
    }

    /** Mở 1 Session mới. Người gọi chịu trách nhiệm đóng (BaseDAO đã lo việc này). */
    public static Session openSession() {
        return getSessionFactory().openSession();
    }

    public static synchronized void shutdown() {
        if (factory != null && !factory.isClosed()) factory.close();
    }
}
