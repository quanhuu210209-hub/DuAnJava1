package Util;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Validate dữ liệu phía server (yêu cầu Y4). Mỗi trường chỉ giữ lỗi đầu tiên.
 * Dùng: Validator v = new Validator(); v.required("name", name, "Tên").maxLength("name", name, 100, "Tên");
 *       if (!v.isValid()) { request.setAttribute("errors", v.getErrors()); ... }
 */
public class Validator {

    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PHONE = Pattern.compile("^(0|\\+84)\\d{9}$");

    private final Map<String, String> errors = new LinkedHashMap<>();

    public Validator required(String field, String value, String label) {
        if (value == null || value.trim().isEmpty()) put(field, label + " không được để trống");
        return this;
    }

    public Validator maxLength(String field, String value, int max, String label) {
        if (value != null && value.length() > max) put(field, label + " tối đa " + max + " ký tự");
        return this;
    }

    public Validator minLength(String field, String value, int min, String label) {
        if (value != null && !value.isEmpty() && value.length() < min) put(field, label + " tối thiểu " + min + " ký tự");
        return this;
    }

    /** Bỏ qua nếu rỗng (kết hợp với required nếu bắt buộc). */
    public Validator email(String field, String value) {
        if (notEmpty(value) && !EMAIL.matcher(value).matches()) put(field, "Email không đúng định dạng");
        return this;
    }

    public Validator phone(String field, String value) {
        if (notEmpty(value) && !PHONE.matcher(value).matches())
            put(field, "Số điện thoại phải gồm 10 chữ số, bắt đầu bằng 0 (hoặc +84)");
        return this;
    }

    public Validator pattern(String field, String value, String regex, String message) {
        if (notEmpty(value) && !Pattern.matches(regex, value)) put(field, message);
        return this;
    }

    /** Số nguyên trong khoảng [min, max]; value là chuỗi thô từ form. */
    public Validator intRange(String field, String raw, int min, int max, String label) {
        if (!notEmpty(raw)) { put(field, label + " không được để trống"); return this; }
        try {
            int n = Integer.parseInt(raw.trim());
            if (n < min || n > max) put(field, label + " phải từ " + min + " đến " + max);
        } catch (NumberFormatException e) {
            put(field, label + " phải là số nguyên");
        }
        return this;
    }

    /** Số tiền VND: số nguyên không âm, tối đa 15 chữ số (cột DECIMAL(18,0)). */
    public Validator money(String field, String raw, String label) {
        if (!notEmpty(raw)) { put(field, label + " không được để trống"); return this; }
        if (!raw.trim().matches("\\d{1,15}")) put(field, label + " phải là số nguyên không âm");
        return this;
    }

    public Validator oneOf(String field, String value, String label, String... allowed) {
        for (String a : allowed) if (a.equals(value)) return this;
        put(field, label + " không hợp lệ");
        return this;
    }

    /** Thêm lỗi tùy ý (ví dụ trùng email). */
    public Validator error(String field, String message) {
        put(field, message);
        return this;
    }

    public boolean isValid() { return errors.isEmpty(); }
    public Map<String, String> getErrors() { return errors; }

    private void put(String field, String msg) { errors.putIfAbsent(field, msg); }
    private static boolean notEmpty(String s) { return s != null && !s.trim().isEmpty(); }
}
