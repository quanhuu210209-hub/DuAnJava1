package Util;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/** Lấy UserID của khách đang đăng nhập. Sửa lại nếu session của bạn đặt tên khác. */
public class AuthUtil {
    public static Integer currentUserId(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s == null) return null;
        Object o = s.getAttribute("userId");
        if (o instanceof Integer) return (Integer) o;
        for (String key : new String[]{"user", "account", "customer", "loginUser"}) {
            o = s.getAttribute(key);
            if (o != null) break;
        }
        if (o == null) return null;
        for (String m : new String[]{"getUserID", "getUserId", "getId", "getID", "getCustomerID"}) {
            try {
                Object v = o.getClass().getMethod(m).invoke(o);
                if (v instanceof Number) return ((Number) v).intValue();
            } catch (Exception ignored) { }
        }
        return null;
    }
}
