package Util;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

/**
 * Băm mật khẩu bằng PBKDF2 (có sẵn trong JDK, không cần thư viện ngoài).
 * Định dạng lưu vào cột Users.PasswordHash:  iterations:salt:hash  (Base64), ~100 ký tự < 255.
 */
public class PasswordUtil {

    private static final int ITERATIONS = 65536;
    private static final int KEY_LENGTH = 256;

    public static String hash(String password) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        byte[] h = pbkdf2(password.toCharArray(), salt, ITERATIONS);
        return ITERATIONS + ":" + Base64.getEncoder().encodeToString(salt)
                          + ":" + Base64.getEncoder().encodeToString(h);
    }

    public static boolean verify(String password, String stored) {
        if (password == null || stored == null) return false;
        String[] p = stored.split(":");
        if (p.length != 3) return false;           // ví dụ 'REPLACE_WITH_REAL_HASH' -> false
        try {
            int iter = Integer.parseInt(p[0]);
            byte[] salt = Base64.getDecoder().decode(p[1]);
            byte[] expected = Base64.getDecoder().decode(p[2]);
            byte[] actual = pbkdf2(password.toCharArray(), salt, iter);
            return java.security.MessageDigest.isEqual(expected, actual); // so sánh hằng thời gian
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static byte[] pbkdf2(char[] pw, byte[] salt, int iter) {
        try {
            SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            return f.generateSecret(new PBEKeySpec(pw, salt, iter, KEY_LENGTH)).getEncoded();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Chạy file này để sinh hash dán vào script SQL (thay REPLACE_WITH_REAL_HASH). */
    public static void main(String[] args) {
        System.out.println(hash(args.length > 0 ? args[0] : "123456"));
    }
}
