package Util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Giá trị ghi vào DB khi bán tại quầy và hàm sinh mã.
 * Nếu SQL Server báo vi phạm CHECK constraint thì sửa đúng các hằng số bên dưới cho khớp script tạo bảng.
 */
public final class OrderConst {

    private OrderConst() { }

    public static final String CHANNEL_OFFLINE = "Offline";   // Orders.Channel
    public static final String RECEIVE_PICKUP  = "Pickup";    // Orders.ReceiveMethod
    public static final String ORDER_PAID      = "Paid";      // Orders.PaymentStatus
    public static final String PAYMENT_OK      = "Success";   // Payments.Status

    // Bảo hành / đổi trả (WarrantyRequests)
    public static final String WARRANTY_SOURCE = "Offline";   // WarrantyRequests.Source: nhận tại quầy
    public static final String WARRANTY_SOURCE_ONLINE = "Online"; // WarrantyRequests.Source: khách tự gửi trên web
    public static final String CHAT_USER = "User";            // ChatMessages.Sender
    public static final String CHAT_BOT  = "Bot";
    public static final String WARRANTY_PENDING = "Pending";  // WarrantyRequests.Status: chờ quản lý chi nhánh xử lý
    public static final String TYPE_WARRANTY = "Warranty";    // WarrantyRequests.RequestType
    public static final String TYPE_RETURN   = "Return";
    public static final String TYPE_EXCHANGE = "Exchange";
    public static final String WARRANTY_PROCESSING = "Processing";  // đã duyệt, đang xử lý
    public static final String WARRANTY_DONE       = "Completed";   // đã xử lý xong
    public static final String WARRANTY_REJECTED   = "Rejected";    // từ chối

    // Lịch sử xuất kho (StockMovements)
    public static final boolean RECORD_STOCK_MOVEMENT = true; // false nếu chưa muốn ghi StockMovements
    public static final String MOVEMENT_SALE = "Sale";        // StockMovements.MovementType
    public static final String REF_ORDER     = "Order";       // StockMovements.RefType
    public static final String MOVEMENT_IMPORT = "Import";       // StockMovements.MovementType
    public static final String REF_RECEIPT     = "GoodsReceipt"; // StockMovements.RefType
    public static final String MOVEMENT_ADJUST = "Adjust";       // StockMovements.MovementType: kiểm kê / điều chỉnh
    public static final String MOVEMENT_RETURN = "Return";       // StockMovements.MovementType: khách trả hàng
    public static final String REF_WARRANTY    = "Warranty";     // StockMovements.RefType

    /** Mã duy nhất theo thời điểm, ví dụ POS260521103045123. */
    public static String newCode(String prefix) {
        return prefix + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmssSSS"));
    }
}
