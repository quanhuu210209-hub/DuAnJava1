<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chi tiết sản phẩm — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1><c:out value="${product.productName}"/></h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <p><a href="${pageContext.request.contextPath}/staff/stock">&larr; Tra cứu sản phẩm</a></p>
    <c:if test="${not empty product.thumbnailUrl}"><img src="<c:out value='${product.thumbnailUrl}'/>" alt="" class="stock-thumb"></c:if>
    <div class="table-card"><table>
        <tr><th>SKU</th><td><c:out value="${product.sku}"/></td></tr>
        <tr><th>Danh mục</th><td><c:out value="${product.category.categoryName}"/></td></tr>
        <tr><th>Thương hiệu</th><td><c:out value="${product.brand.brandName}"/></td></tr>
        <tr><th>Giá bán</th><td><t:money value="${product.price}"/></td></tr>
        <tr><th>Chính sách bảo hành</th><td>${product.warrantyMonths} tháng</td></tr>
        <tr><th>Mô tả</th><td><c:out value="${product.description}"/></td></tr>
        <tr><th>Tồn tại chi nhánh của bạn</th><td>
            <c:choose>
                <c:when test="${empty mine}">Chưa có dữ liệu tồn kho</c:when>
                <c:when test="${mine.hidden}">Đang ẩn tại chi nhánh</c:when>
                <c:otherwise>${mine.quantity} (cảnh báo khi còn ≤ ${mine.lowStockThreshold})</c:otherwise>
            </c:choose>
        </td></tr>
    </table></div>

    <h2>Thông số kỹ thuật</h2>
    <div class="table-card"><table>
        <c:forEach var="sp" items="${product.specs}">
            <tr><th><c:out value="${sp.specName}"/></th><td><c:out value="${sp.specValue}"/></td></tr>
        </c:forEach>
        <c:if test="${empty product.specs}"><tr><td>Chưa có thông số.</td></tr></c:if>
    </table></div>

    <h2>Tồn kho các chi nhánh</h2>
    <div class="table-card"><table>
        <thead><tr><th>Chi nhánh</th><th>Số lượng</th></tr></thead>
        <tbody>
        <c:forEach var="b" items="${branches}">
            <tr><td><c:out value="${b.branch.branchName}"/></td><td>${b.quantity}</td></tr>
        </c:forEach>
        <c:if test="${empty branches}"><tr><td colspan="2">Chưa có chi nhánh nào bán sản phẩm này.</td></tr></c:if>
        </tbody>
    </table></div>
    <p class="hint">Chỉ xem: nhân viên không được sửa giá hoặc số lượng tồn kho.</p>
  </div>
</div>
</body>
</html>
