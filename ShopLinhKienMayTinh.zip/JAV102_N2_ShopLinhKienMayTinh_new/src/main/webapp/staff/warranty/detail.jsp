<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chi tiết yêu cầu — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Yêu cầu <c:out value="${request.requestCode}"/></h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <p><a href="${pageContext.request.contextPath}/staff/warranty">&larr; Danh sách yêu cầu</a></p>
    <div class="table-card"><table>
        <tr><th>Trạng thái</th><td><c:out value="${request.status}"/></td></tr>
        <tr><th>Loại yêu cầu</th><td><c:out value="${empty types[request.requestType] ? request.requestType : types[request.requestType]}"/></td></tr>
        <tr><th>Khách hàng</th><td><c:out value="${request.customer.fullName}"/> - <c:out value="${request.customer.phone}"/></td></tr>
        <tr><th>Sản phẩm</th><td><c:out value="${request.orderDetail.product.productName}"/> (SL: ${request.quantity})</td></tr>
        <tr><th>Chi nhánh</th><td><c:out value="${request.branch.branchName}"/></td></tr>
        <tr><th>Lý do</th><td><c:out value="${request.reason}"/></td></tr>
        <tr><th>Nhân viên tiếp nhận</th><td><c:out value="${request.receivedBy.fullName}"/></td></tr>
        <tr><th>Ngày tiếp nhận</th><td><t:dt value="${request.createdAt}"/></td></tr>
        <tr><th>Kết quả xử lý</th><td><c:out value="${empty request.resolutionNote ? 'Chờ quản lý chi nhánh xử lý' : request.resolutionNote}"/></td></tr>
        <c:if test="${request.refundApproved}"><tr><th>Hoàn tiền</th><td><t:money value="${request.refundAmount}"/></td></tr></c:if>
    </table></div>
  </div>
</div>
</body>
</html>
