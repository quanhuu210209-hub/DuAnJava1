package DAO.manager;

import DAO.common.BaseDAO;
import Model.manager.BranchInventory;
import Model.manager.BranchInventoryId;
import Model.manager.StockMovement;
import Model.user.User;
import Util.OrderConst;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

/** Tồn kho theo chi nhánh. Sản phẩm bị ẩn tại chi nhánh coi như không bán. */
public class BranchInventoryDAO extends BaseDAO<BranchInventory> {

    public BranchInventoryDAO() { super(BranchInventory.class, "BranchInventory"); }

    /** productId -> số lượng tồn của chi nhánh (không gồm sản phẩm bị ẩn). */
    public Map<Integer, Integer> stockMap(int branchId) {
        return read(s -> {
            Map<Integer, Integer> m = new HashMap<>();
            for (Object[] r : s.createQuery(
                    "select i.id.productId, i.quantity from BranchInventory i where i.branch.branchId = :b and i.hidden = false",
                    Object[].class).setParameter("b", branchId).getResultList()) {
                m.put((Integer) r[0], (Integer) r[1]);
            }
            return m;
        });
    }

    /** productId -> dòng tồn kho của chi nhánh (có số lượng, ngưỡng cảnh báo, trạng thái ẩn). */
    public Map<Integer, BranchInventory> inventoryMap(int branchId) {
        return read(s -> {
            Map<Integer, BranchInventory> m = new HashMap<>();
            for (BranchInventory i : s.createQuery("from BranchInventory i where i.branch.branchId = :b", BranchInventory.class)
                    .setParameter("b", branchId).getResultList()) {
                m.put(i.getProduct().getProductId(), i);
            }
            return m;
        });
    }

    /** Tồn của một sản phẩm tại chi nhánh (0 nếu chưa có hoặc bị ẩn). */
    public int quantity(int branchId, int productId) {
        Integer q = read(s -> s.createQuery(
                "select i.quantity from BranchInventory i where i.branch.branchId = :b and i.product.productId = :p and i.hidden = false",
                Integer.class).setParameter("b", branchId).setParameter("p", productId).setMaxResults(1).uniqueResult());
        return q == null ? 0 : q;
    }

    /** Tồn của một sản phẩm ở tất cả chi nhánh (để tư vấn khách khi chi nhánh mình hết hàng). */
    public List<BranchInventory> byProduct(int productId) {
        return read(s -> s.createQuery(
                "from BranchInventory i where i.product.productId = :p and i.hidden = false order by i.branch.branchName",
                BranchInventory.class).setParameter("p", productId).getResultList());
    }

    /** Sản phẩm sắp hết hàng tại chi nhánh: số lượng <= ngưỡng cảnh báo. */
    public List<BranchInventory> lowStock(int branchId) {
        return read(s -> s.createQuery(
                "from BranchInventory i where i.branch.branchId = :b and i.hidden = false and i.quantity <= i.lowStockThreshold order by i.quantity",
                BranchInventory.class).setParameter("b", branchId).getResultList());
    }

    // ---------- dùng trong transaction của DAO khác ----------

    /** Dòng tồn kho của (chi nhánh, sản phẩm) trong session đang mở; null nếu chưa có. */
    public static BranchInventory of(Session s, int branchId, int productId) {
        BranchInventoryId key = new BranchInventoryId();
        key.setBranchId(branchId);
        key.setProductId(productId);
        return s.get(BranchInventory.class, key);
    }

    /** Xuất kho khi bán: trừ tồn và ghi lịch sử StockMovements (nếu bật). Người gọi phải kiểm tra đủ hàng trước. */
    public static void takeStock(Session s, BranchInventory inv, int qty, Integer orderId, User staff, LocalDateTime now) {
        inv.setQuantity(inv.getQuantity() - qty);
        inv.setUpdatedAt(now);
        if (!OrderConst.RECORD_STOCK_MOVEMENT) return;
        StockMovement m = new StockMovement();
        m.setBranch(inv.getBranch());
        m.setProduct(inv.getProduct());
        m.setMovementType(OrderConst.MOVEMENT_SALE);
        m.setQuantityChange(-qty);
        m.setRefType(OrderConst.REF_ORDER);
        m.setRefId(orderId);
        m.setCreatedBy(staff);
        m.setCreatedAt(now);
        s.persist(m);
    }
}
