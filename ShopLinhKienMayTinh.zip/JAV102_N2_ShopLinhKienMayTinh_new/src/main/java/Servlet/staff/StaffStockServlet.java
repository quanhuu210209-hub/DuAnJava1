package Servlet.staff;

import DAO.admin.CategoryDAO;
import DAO.admin.ProductDAO;
import DAO.manager.BranchInventoryDAO;
import Model.admin.Product;
import Model.manager.BranchInventory;
import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Tra cứu tồn kho và thông tin sản phẩm (chỉ xem, không sửa giá hay tồn kho).
 * URL: /staff/stock?action=list|detail&id=&q=&categoryId=
 */
@WebServlet("/staff/stock")
public class StaffStockServlet extends HttpServlet {

    private static final String LIST   = "/staff/stock/list.jsp";
    private static final String DETAIL = "/staff/stock/detail.jsp";
    private static final String URL    = "/staff/stock";

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final BranchInventoryDAO stockDAO = new BranchInventoryDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        Integer branchId = me.getBranchId();   // Admin không thuộc chi nhánh nào

        if ("detail".equals(ServletUtils.trim(req.getParameter("action")))) {
            int id = ServletUtils.parseInt(req.getParameter("id"), 0);
            Product p = productDAO.findById(id);
            if (p == null) {
                ServletUtils.setFlash(req, "danger", "Không tìm thấy sản phẩm");
                ServletUtils.redirect(req, resp, URL);
                return;
            }
            req.setAttribute("product", p);
            req.setAttribute("mine", branchId == null ? null : stockDAO.inventoryMap(branchId).get(id));
            req.setAttribute("branches", stockDAO.byProduct(id));
            ServletUtils.forward(req, resp, DETAIL);
            return;
        }

        ServletUtils.loadFlash(req);
        String q = ServletUtils.trim(req.getParameter("q"));
        int categoryId = ServletUtils.parseInt(req.getParameter("categoryId"), 0);
        List<Product> products = productDAO.search(q, categoryId > 0 ? categoryId : null, null, true);
        Map<Integer, BranchInventory> inventory =
                branchId == null ? new HashMap<>() : stockDAO.inventoryMap(branchId);

        req.setAttribute("products", products.size() > 100 ? products.subList(0, 100) : products);
        req.setAttribute("inventory", inventory);
        req.setAttribute("categories", categoryDAO.findAll());
        req.setAttribute("q", q);
        req.setAttribute("categoryId", categoryId);
        ServletUtils.forward(req, resp, LIST);
    }
}
