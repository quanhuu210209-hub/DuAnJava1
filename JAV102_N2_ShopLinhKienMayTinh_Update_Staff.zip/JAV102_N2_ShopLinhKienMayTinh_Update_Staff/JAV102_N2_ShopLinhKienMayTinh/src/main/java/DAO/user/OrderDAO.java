package DAO.user;

import DAO.common.BaseDAO;
import DAO.manager.BranchInventoryDAO;
import Model.admin.Branch;
import Model.admin.PaymentMethod;
import Model.admin.Product;
import Model.manager.BranchInventory;
import Model.staff.Invoice;
import Model.user.Customer;
import Model.user.Order;
import Model.user.OrderDetail;
import Model.user.Payment;
import Model.user.User;
import Util.OrderConst;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderDAO extends BaseDAO<Order> {

    // Entity Order ánh xạ bảng Orders và đặt tên "Orders" trong HQL (vì ORDER là từ khóa của HQL)
    public OrderDAO() { super(Order.class, "Orders"); }

    /**
     * Danh sách đơn. Tham số null / rỗng thì không lọc (Admin xem tất cả, Manager/Staff lọc theo chi nhánh).
     * channel: "online" (mọi đơn không phải bán tại quầy) | "offline" (bán tại quầy); keyword: mã đơn hoặc SĐT khách.
     */
    public List<Order> search(Integer branchId, String status, String channel, String keyword) {
        StringBuilder hql = new StringBuilder("select o from Orders o left join o.customer c where 1 = 1 ");
        Map<String, Object> params = new HashMap<>();
        if (branchId != null) { hql.append("and o.branch.branchId = :b "); params.put("b", branchId); }
        if (status != null && !status.isEmpty()) { hql.append("and o.status = :st "); params.put("st", status); }
        if ("online".equals(channel)) { hql.append("and o.channel <> :ch "); params.put("ch", OrderConst.CHANNEL_OFFLINE); }
        if ("offline".equals(channel)) { hql.append("and o.channel = :ch "); params.put("ch", OrderConst.CHANNEL_OFFLINE); }
        if (keyword != null && !keyword.isEmpty()) {
            hql.append("and (lower(o.orderCode) like :k or c.phone like :k or o.receiverPhone like :k) ");
            params.put("k", "%" + keyword.toLowerCase() + "%");
        }
        hql.append("order by o.createdAt desc");
        return read(s -> {
            org.hibernate.query.Query<Order> q = s.createQuery(hql.toString(), Order.class).setMaxResults(200);
            params.forEach(q::setParameter);
            return q.getResultList();
        });
    }

    /** Số đơn online của chi nhánh đang chờ xử lý (Pending hoặc Paid). */
    public long countPendingOnline(int branchId) {
        return read(s -> s.createQuery(
                "select count(o) from Orders o where o.branch.branchId = :b and o.channel <> :ch and o.status in ('Pending', 'Paid')",
                Long.class).setParameter("b", branchId).setParameter("ch", OrderConst.CHANNEL_OFFLINE).uniqueResult());
    }

    /** Tìm đơn (kèm chi tiết) theo số hóa đơn hoặc mã đơn; null nếu không có. */
    public Order findByInvoiceOrCode(String key) {
        return read(s -> s.createQuery(
                "select o from Orders o left join fetch o.details d left join fetch d.product "
                + "where o.orderCode = :k or o.orderId in (select i.salesOrder.orderId from Invoice i where i.invoiceNo = :k)",
                Order.class).setParameter("k", key).setMaxResults(1).uniqueResult());
    }

    /** Đơn hàng của một khách (trang "Đơn của tôi"). */
    public List<Order> findByCustomer(int customerId) {
        return read(s -> s.createQuery(
                "from Orders o where o.customer.customerId = :c order by o.createdAt desc", Order.class)
                .setParameter("c", customerId).getResultList());
    }

    /** Lấy 1 đơn kèm danh sách chi tiết và sản phẩm. */
    @Override
    public Order findById(java.io.Serializable id) {
        return read(s -> s.createQuery(
                "select o from Orders o left join fetch o.details d left join fetch d.product where o.orderId = :id",
                Order.class).setParameter("id", id).uniqueResult());
    }

    /**
     * Đổi trạng thái đơn: Pending, Paid, Shipping, Completed (hủy dùng cancel()).
     * Pending -> Paid: ghi nhận đã thanh toán. Paid -> Shipping/Completed: xuất kho tại chi nhánh xử lý đơn
     * (thiếu hàng thì hủy toàn bộ thay đổi và trả về false).
     */
    public boolean updateStatus(int orderId, String status, int handledBy) {
        return write(s -> {
            Order o = s.createQuery(
                    "select o from Orders o left join fetch o.details d left join fetch d.product where o.orderId = :id",
                    Order.class).setParameter("id", orderId).uniqueResult();
            if (o == null) return false;
            LocalDateTime now = LocalDateTime.now();
            User staff = s.getReference(User.class, handledBy);

            if ("Paid".equals(o.getStatus()) && ("Shipping".equals(status) || "Completed".equals(status))) {
                for (OrderDetail d : o.getDetails()) {
                    BranchInventory inv = BranchInventoryDAO.of(s, o.getBranch().getBranchId(), d.getProduct().getProductId());
                    if (inv == null || inv.isHidden() || inv.getQuantity() < d.getQuantity()) return false;
                    BranchInventoryDAO.takeStock(s, inv, d.getQuantity(), o.getOrderId(), staff, now);
                }
            }
            if ("Paid".equals(status)) o.setPaymentStatus(OrderConst.ORDER_PAID);
            o.setStatus(status);
            o.setHandledBy(staff);
            o.setUpdatedAt(now);
            if ("Completed".equals(status)) o.setCompletedAt(now);
            return true;
        });
    }

    /** Chỉ hủy được đơn đang Pending hoặc Paid. */
    public boolean cancel(int orderId, int cancelledBy, String reason) {
        return write(s -> {
            Order o = s.get(Order.class, orderId);
            if (o == null || !("Pending".equals(o.getStatus()) || "Paid".equals(o.getStatus()))) return false;
            LocalDateTime now = LocalDateTime.now();
            o.setStatus("Cancelled");
            o.setCancelledAt(now);
            o.setCancelledBy(s.getReference(User.class, cancelledBy));
            o.setCancelReason(reason);
            o.setUpdatedAt(now);
            return true;
        });
    }

    /**
     * Bán tại quầy trong một giao dịch: tạo đơn (Completed, đã thanh toán), chi tiết đơn, trừ tồn kho chi nhánh,
     * ghi thanh toán và xuất hóa đơn. items: productId -> số lượng. Trả về mã đơn mới, 0 nếu thất bại (đã rollback).
     */
    public int createCounterSale(int branchId, int staffId, int customerId, int paymentMethodId, Map<Integer, Integer> items) {
        int[] out = {0};
        boolean ok = write(s -> {
            PaymentMethod method = s.get(PaymentMethod.class, paymentMethodId);
            if (method == null || items.isEmpty()) return false;
            LocalDateTime now = LocalDateTime.now();
            User staff = s.getReference(User.class, staffId);

            Order o = new Order();
            List<OrderDetail> lines = new ArrayList<>();
            List<BranchInventory> stocks = new ArrayList<>();
            BigDecimal total = BigDecimal.ZERO;
            for (Map.Entry<Integer, Integer> e : items.entrySet()) {
                Product p = s.get(Product.class, e.getKey());
                BranchInventory stock = BranchInventoryDAO.of(s, branchId, e.getKey());
                if (p == null || stock == null || stock.isHidden() || stock.getQuantity() < e.getValue()) return false;
                stocks.add(stock);

                OrderDetail d = new OrderDetail();
                d.setSalesOrder(o);
                d.setProduct(p);
                d.setQuantity(e.getValue());
                d.setUnitPrice(p.getPrice());
                d.setWarrantyMonths(p.getWarrantyMonths());
                lines.add(d);
                total = total.add(p.getPrice().multiply(BigDecimal.valueOf(e.getValue())));
            }

            o.setOrderCode(OrderConst.newCode("POS"));
            o.setCustomer(s.getReference(Customer.class, customerId));
            o.setBranch(s.getReference(Branch.class, branchId));
            o.setChannel(OrderConst.CHANNEL_OFFLINE);
            o.setReceiveMethod(OrderConst.RECEIVE_PICKUP);
            o.setSubTotal(total);
            o.setShippingFee(BigDecimal.ZERO);
            o.setTotalAmount(total);
            o.setStatus("Completed");
            o.setPaymentStatus(OrderConst.ORDER_PAID);
            o.setCreatedBy(staff);
            o.setHandledBy(staff);
            o.setCreatedAt(now);
            o.setUpdatedAt(now);
            o.setCompletedAt(now);
            s.persist(o);
            for (OrderDetail d : lines) s.persist(d);
            for (int i = 0; i < lines.size(); i++) {
                BranchInventoryDAO.takeStock(s, stocks.get(i), lines.get(i).getQuantity(), o.getOrderId(), staff, now);
            }

            Payment pay = new Payment();
            pay.setSalesOrder(o);
            pay.setPaymentMethod(method);
            pay.setAmount(total);
            pay.setStatus(OrderConst.PAYMENT_OK);
            pay.setPaidAt(now);
            pay.setConfirmedBy(staff);
            pay.setCreatedAt(now);
            s.persist(pay);

            Invoice invoice = new Invoice();
            invoice.setInvoiceNo(OrderConst.newCode("HD"));
            invoice.setSalesOrder(o);
            invoice.setIssuedBy(staff);
            invoice.setIssuedAt(now);
            invoice.setPrintCount(0);
            s.persist(invoice);

            out[0] = o.getOrderId();
            return true;
        });
        return ok ? out[0] : 0;
    }
}
