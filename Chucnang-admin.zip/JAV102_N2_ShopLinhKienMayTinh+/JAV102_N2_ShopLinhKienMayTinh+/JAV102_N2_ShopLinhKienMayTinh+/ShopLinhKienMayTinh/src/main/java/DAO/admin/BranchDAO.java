package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.Branch;
import Model.user.User;

import java.util.List;

public class BranchDAO extends BaseDAO<Branch> {

    public BranchDAO() { super(Branch.class, "Branch"); }

    @Override
    public List<Branch> findAll() {
        return read(s -> s.createQuery("from Branch b order by b.branchName", Branch.class).getResultList());
    }

    /** Chi nhánh đang hoạt động (dùng cho dropdown). */
    public List<Branch> findActive() {
        return read(s -> s.createQuery(
                "from Branch b where b.active = true order by b.branchName", Branch.class).getResultList());
    }

    public boolean update(Branch form) {
        return write(s -> {
            Branch b = s.get(Branch.class, form.getBranchId());
            if (b == null) return false;
            b.setBranchName(form.getBranchName());
            b.setAddress(form.getAddress());
            b.setPhone(form.getPhone());
            b.setManagerUser(form.getManagerUser() == null
                    ? null : s.getReference(User.class, form.getManagerUser().getUserId()));
            b.setActive(form.isActive());
            return true;
        });
    }

    public boolean nameExists(String name, int excludeId) {
        Long n = read(s -> s.createQuery(
                "select count(b) from Branch b where b.branchName = :n and b.branchId <> :id", Long.class)
                .setParameter("n", name).setParameter("id", excludeId).uniqueResult());
        return n != null && n > 0;
    }
}