package Servlet.user;

import DAO.user.CustomerDAO;
import DAO.user.OrderDAO;
import Model.user.Customer;
import Model.user.Order;
import Model.user.User;
import Servlet.common.ServletUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** Khách hàng xem đơn của mình. URL: /user/order  hoặc /user/order?id= */
@WebServlet("/user/order")
public class UserOrderServlet extends HttpServlet {

    private final OrderDAO orderDAO = new OrderDAO();
    private final CustomerDAO customerDAO = new CustomerDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User me = ServletUtils.currentUser(req);
        Customer customer = customerDAO.findByUserId(me.getUserId());
        if (customer == null) {
            ServletUtils.setFlash(req, "warning", "Tài khoản chưa có hồ sơ khách hàng");
            ServletUtils.redirect(req, resp, "/home");
            return;
        }

        int id = ServletUtils.parseInt(req.getParameter("id"), 0);
        if (id > 0) {
            Order o = orderDAO.findById(id);
            // Chống xem đơn của người khác bằng cách đoán id
            if (o == null || o.getCustomer() == null || o.getCustomer().getCustomerId() != customer.getCustomerId()) {
                ServletUtils.setFlash(req, "danger", "Không tìm thấy đơn hàng");
                ServletUtils.redirect(req, resp, "/user/order");
                return;
            }
            req.setAttribute("order", o);
            ServletUtils.forward(req, resp, "/user/order/detail.jsp");
            return;
        }

        ServletUtils.loadFlash(req);
        req.setAttribute("orders", orderDAO.findByCustomer(customer.getCustomerId()));
        ServletUtils.forward(req, resp, "/user/order/list.jsp");
    }
}
