package Servlet.admin;

import DAO.user.OrderDAO;
import Model.user.Order;
import Servlet.common.ServletUtils;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Báo cáo doanh thu toàn hệ thống (Y32). URL: /admin/report?from=yyyy-MM-dd&to=yyyy-MM-dd
 * Chỉ tính các đơn đã Completed. Mặc định xem tháng hiện tại.
 * Gom nhóm theo ngày bằng vòng lặp Java cho dễ đọc, không dùng HQL group by phức tạp.
 */
@WebServlet("/admin/report")
public class ReportServlet extends HttpServlet {

    private static final String VIEW = "/admin/report/revenue.jsp";
    private static final DateTimeFormatter FMT = DateTimeFormatter.ISO_LOCAL_DATE;

    private final OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        LocalDate today = LocalDate.now();
        LocalDate from = parseDate(req.getParameter("from"), today.withDayOfMonth(1));
        LocalDate to = parseDate(req.getParameter("to"), today);
        if (to.isBefore(from)) to = from;

        List<Order> orders = orderDAO.findCompletedBetween(from.atStartOfDay(), to.atTime(23, 59, 59));

        Map<LocalDate, long[]> countByDay = new LinkedHashMap<>();
        Map<LocalDate, BigDecimal> revenueByDay = new LinkedHashMap<>();
        for (LocalDate d = from; !d.isAfter(to); d = d.plusDays(1)) {
            countByDay.put(d, new long[]{0});
            revenueByDay.put(d, BigDecimal.ZERO);
        }

        BigDecimal grandTotal = BigDecimal.ZERO;
        for (Order o : orders) {
            LocalDate d = o.getCompletedAt().toLocalDate();
            countByDay.get(d)[0]++;
            revenueByDay.put(d, revenueByDay.get(d).add(o.getTotalAmount()));
            grandTotal = grandTotal.add(o.getTotalAmount());
        }

        List<Map<String, Object>> rows = new ArrayList<>();
        for (LocalDate d : countByDay.keySet()) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("date", d);
            row.put("orderCount", countByDay.get(d)[0]);
            row.put("revenue", revenueByDay.get(d));
            rows.add(row);
        }

        req.setAttribute("rows", rows);
        req.setAttribute("grandTotal", grandTotal);
        req.setAttribute("orderCount", orders.size());
        req.setAttribute("from", from.format(FMT));
        req.setAttribute("to", to.format(FMT));
        ServletUtils.forward(req, resp, VIEW);
    }

    private static LocalDate parseDate(String raw, LocalDate def) {
        if (raw == null || raw.trim().isEmpty()) return def;
        try {
            return LocalDate.parse(raw.trim(), FMT);
        } catch (DateTimeParseException e) {
            return def;
        }
    }
}