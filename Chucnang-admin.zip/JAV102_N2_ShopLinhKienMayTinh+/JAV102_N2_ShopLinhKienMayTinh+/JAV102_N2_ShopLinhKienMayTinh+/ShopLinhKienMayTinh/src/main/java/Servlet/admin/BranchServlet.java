package Servlet.admin;

import DAO.admin.BranchDAO;
import DAO.user.UserDAO;
import Model.admin.Branch;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** CRUD Chi nhánh. URL: /admin/branch?action=list|new|edit&id=  (POST: save | delete) */
@WebServlet("/admin/branch")
public class BranchServlet extends HttpServlet {

    private static final String LIST = "/admin/branch/list.jsp";
    private static final String FORM = "/admin/branch/form.jsp";
    private static final String URL  = "/admin/branch";
    private final BranchDAO dao = new BranchDAO();
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        switch (action) {
            case "new":
                Branch b = new Branch();
                b.setActive(true);
                showForm(req, resp, b);
                break;
            case "edit":
                Branch found = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
                if (found == null) {
                    ServletUtils.setFlash(req, "danger", "Không tìm thấy chi nhánh");
                    ServletUtils.redirect(req, resp, URL);
                    return;
                }
                showForm(req, resp, found);
                break;
            default:
                ServletUtils.loadFlash(req);
                req.setAttribute("branches", dao.findAll());
                ServletUtils.forward(req, resp, LIST);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        if ("delete".equals(action)) {
            int id = ServletUtils.parseInt(req.getParameter("id"), 0);
            if (dao.delete(id)) ServletUtils.setFlash(req, "success", "Đã xóa chi nhánh");
            else ServletUtils.setFlash(req, "danger",
                    "Không xóa được vì chi nhánh đang có dữ liệu liên quan (tồn kho, đơn hàng...). Hãy chuyển sang trạng thái ẩn.");
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        int managerId = ServletUtils.parseInt(req.getParameter("managerUserId"), 0);
        Branch b = new Branch();
        b.setBranchId(ServletUtils.parseInt(req.getParameter("branchId"), 0));
        b.setBranchName(ServletUtils.trim(req.getParameter("branchName")));
        b.setAddress(ServletUtils.trim(req.getParameter("address")));
        b.setPhone(ServletUtils.trim(req.getParameter("phone")));
        b.setManagerUser(managerId == 0 ? null : userDAO.findById(managerId));
        b.setActive(req.getParameter("active") != null);

        Validator v = new Validator()
                .required("branchName", b.getBranchName(), "Tên chi nhánh")
                .maxLength("branchName", b.getBranchName(), 150, "Tên chi nhánh")
                .required("address", b.getAddress(), "Địa chỉ")
                .maxLength("address", b.getAddress(), 300, "Địa chỉ")
                .maxLength("phone", b.getPhone(), 20, "Số điện thoại");
        if (!b.getPhone().isEmpty()) v.phone("phone", b.getPhone());
        if (v.isValid() && dao.nameExists(b.getBranchName(), b.getBranchId()))
            v.error("branchName", "Tên chi nhánh đã tồn tại");

        if (!v.isValid()) {
            req.setAttribute("errors", v.getErrors());
            showForm(req, resp, b);
            return;
        }

        if (b.getPhone().isEmpty()) b.setPhone(null);
        boolean ok = b.getBranchId() == 0 ? dao.insert(b) : dao.update(b);
        ServletUtils.setFlash(req, ok ? "success" : "danger",
                ok ? "Đã lưu chi nhánh" : "Lưu thất bại, vui lòng thử lại");
        ServletUtils.redirect(req, resp, URL);
    }

    private void showForm(HttpServletRequest req, HttpServletResponse resp, Branch b)
            throws ServletException, IOException {
        req.setAttribute("branch", b);
        req.setAttribute("users", userDAO.findAll());
        ServletUtils.forward(req, resp, FORM);
    }
}