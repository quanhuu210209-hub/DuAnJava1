package DAO.user;

import DAO.common.BaseDAO;
import Model.user.Order;
import Model.user.User;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderDAO extends BaseDAO<Order> {

    // Entity Order ánh xạ bảng Orders và đặt tên "Orders" trong HQL (vì ORDER là từ khóa của HQL)
    public OrderDAO() { super(Order.class, "Orders"); }

    /** Danh sách đơn. branchId / status = null thì không lọc (Admin xem tất cả, Manager/Staff lọc theo chi nhánh). */
    public List<Order> search(Integer branchId, String status) {
        StringBuilder hql = new StringBuilder("from Orders o where 1 = 1 ");
        Map<String, Object> params = new HashMap<>();
        if (branchId != null) { hql.append("and o.branch.branchId = :b "); params.put("b", branchId); }
        if (status != null && !status.isEmpty()) { hql.append("and o.status = :st "); params.put("st", status); }
        hql.append("order by o.createdAt desc");
        return read(s -> {
            org.hibernate.query.Query<Order> q = s.createQuery(hql.toString(), Order.class);
            params.forEach(q::setParameter);
            return q.getResultList();
        });
    }

    /** Đơn hàng của một khách (trang "Đơn của tôi"). */
    public List<Order> findByCustomer(int customerId) {
        return read(s -> s.createQuery(
                "from Orders o where o.customer.customerId = :c order by o.createdAt desc", Order.class)
                .setParameter("c", customerId).getResultList());
    }

    /** Lấy 1 đơn kèm danh sách chi tiết và sản phẩm. */
    @Override
    public Order findById(java.io.Serializable id) {
        return read(s -> s.createQuery(
                "select o from Orders o left join fetch o.details d left join fetch d.product where o.orderId = :id",
                Order.class).setParameter("id", id).uniqueResult());
    }

    /** Đổi trạng thái đơn: Pending, Paid, Shipping, Completed. Hủy đơn dùng cancel(). */
    public boolean updateStatus(int orderId, String status, int handledBy) {
        return write(s -> {
            Order o = s.get(Order.class, orderId);
            if (o == null) return false;
            LocalDateTime now = LocalDateTime.now();
            o.setStatus(status);
            o.setHandledBy(s.getReference(User.class, handledBy));
            o.setUpdatedAt(now);
            if ("Completed".equals(status)) o.setCompletedAt(now);
            return true;
        });
    }

    /**
     * Các đơn đã hoàn tất (Completed) trong khoảng thời gian, dùng cho báo cáo doanh thu (Y32).
     * Doanh thu chỉ tính trên đơn đã hoàn tất, không tính đơn đang xử lý hoặc đã hủy.
     */
    public List<Order> findCompletedBetween(LocalDateTime from, LocalDateTime to) {
        return read(s -> s.createQuery(
                "from Orders o where o.status = 'Completed' and o.completedAt between :f and :t order by o.completedAt",
                Order.class).setParameter("f", from).setParameter("t", to).getResultList());
    }
    
    
    /** Chỉ hủy được đơn đang Pending hoặc Paid. */
    public boolean cancel(int orderId, int cancelledBy, String reason) {
        return write(s -> {
            Order o = s.get(Order.class, orderId);
            if (o == null || !("Pending".equals(o.getStatus()) || "Paid".equals(o.getStatus()))) return false;
            LocalDateTime now = LocalDateTime.now();
            o.setStatus("Cancelled");
            o.setCancelledAt(now);
            o.setCancelledBy(s.getReference(User.class, cancelledBy));
            o.setCancelReason(reason);
            o.setUpdatedAt(now);
            return true;
        });
    }
}
