package Servlet.admin;

import DAO.admin.PriceHistoryDAO;
import DAO.admin.ProductDAO;
import Model.admin.Product;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.math.BigDecimal;

/**
 * Quản lý & điều chỉnh giá (Y31). URL: /admin/price?action=list|history&id=  (POST: update-price)
 * Sửa đầy đủ thông tin sản phẩm vẫn làm ở /admin/product; trang này chỉ tập trung vào GIÁ
 * và xem lại lịch sử đổi giá cho từng sản phẩm.
 */
@WebServlet("/admin/price")
public class PriceServlet extends HttpServlet {

    private static final String LIST    = "/admin/price/list.jsp";
    private static final String HISTORY = "/admin/price/history.jsp";
    private static final String URL     = "/admin/price";

    private final ProductDAO dao = new ProductDAO();
    private final PriceHistoryDAO historyDAO = new PriceHistoryDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        if ("history".equals(action)) {
            Product p = dao.findById(ServletUtils.parseInt(req.getParameter("id"), 0));
            if (p == null) {
                ServletUtils.setFlash(req, "danger", "Không tìm thấy sản phẩm");
                ServletUtils.redirect(req, resp, URL);
                return;
            }
            req.setAttribute("product", p);
            req.setAttribute("history", historyDAO.findByProduct(p.getProductId()));
            ServletUtils.forward(req, resp, HISTORY);
            return;
        }

        ServletUtils.loadFlash(req);
        String keyword = ServletUtils.trim(req.getParameter("keyword"));
        req.setAttribute("products", dao.search(keyword, null, null, false));
        req.setAttribute("keyword", keyword);
        ServletUtils.forward(req, resp, LIST);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int productId = ServletUtils.parseInt(req.getParameter("productId"), 0);
        String priceRaw = ServletUtils.trim(req.getParameter("newPrice"));
        String reason = ServletUtils.trim(req.getParameter("reason"));

        Validator v = new Validator().money("newPrice", priceRaw, "Giá mới");
        if (!v.isValid()) {
            ServletUtils.setFlash(req, "danger", v.getErrors().values().iterator().next());
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        boolean ok = dao.updatePrice(productId, new BigDecimal(priceRaw), reason,
                ServletUtils.currentUser(req).getUserId());
        ServletUtils.setFlash(req, ok ? "success" : "danger",
                ok ? "Đã cập nhật giá" : "Giá mới trùng giá cũ hoặc sản phẩm không tồn tại");
        ServletUtils.redirect(req, resp, URL);
    }
}