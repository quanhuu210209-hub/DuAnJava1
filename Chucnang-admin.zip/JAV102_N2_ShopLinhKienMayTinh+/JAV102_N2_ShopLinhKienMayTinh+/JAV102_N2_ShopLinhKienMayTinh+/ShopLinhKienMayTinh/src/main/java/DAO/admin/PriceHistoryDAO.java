package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.PriceHistory;

import java.util.List;

public class PriceHistoryDAO extends BaseDAO<PriceHistory> {

    public PriceHistoryDAO() { super(PriceHistory.class, "PriceHistory"); }

    /** Lịch sử đổi giá của 1 sản phẩm, mới nhất trước. */
    public List<PriceHistory> findByProduct(int productId) {
        return read(s -> s.createQuery(
                "from PriceHistory h where h.product.productId = :p order by h.changedAt desc",
                PriceHistory.class).setParameter("p", productId).getResultList());
    }
}