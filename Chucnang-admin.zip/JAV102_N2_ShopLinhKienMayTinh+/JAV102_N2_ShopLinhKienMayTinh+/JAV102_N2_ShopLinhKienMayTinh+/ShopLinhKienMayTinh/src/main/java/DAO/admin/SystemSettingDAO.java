package DAO.admin;

import DAO.common.BaseDAO;
import Model.admin.SystemSetting;
import Model.user.User;

import java.time.LocalDateTime;
import java.util.List;

public class SystemSettingDAO extends BaseDAO<SystemSetting> {

    public SystemSettingDAO() { super(SystemSetting.class, "SystemSetting"); }

    @Override
    public List<SystemSetting> findAll() {
        return read(s -> s.createQuery(
                "from SystemSetting st order by st.settingKey", SystemSetting.class).getResultList());
    }

    public boolean keyExists(String key) {
        return findById(key) != null;
    }

    /** Thêm mới 1 cấu hình (settingKey chưa tồn tại). */
    public boolean insert(SystemSetting form, int updatedByUserId) {
        return write(s -> {
            form.setUpdatedBy(s.getReference(User.class, updatedByUserId));
            form.setUpdatedAt(LocalDateTime.now());
            s.persist(form);
            return true;
        });
    }

    public boolean update(SystemSetting form, int updatedByUserId) {
        return write(s -> {
            SystemSetting st = s.get(SystemSetting.class, form.getSettingKey());
            if (st == null) return false;
            st.setSettingValue(form.getSettingValue());
            st.setDescription(form.getDescription());
            st.setUpdatedBy(s.getReference(User.class, updatedByUserId));
            st.setUpdatedAt(LocalDateTime.now());
            return true;
        });
    }
}