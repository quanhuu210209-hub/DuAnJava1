package DAO.user;

import DAO.common.BaseDAO;
import Model.user.Customer;

public class CustomerDAO extends BaseDAO<Customer> {

    public CustomerDAO() { super(Customer.class, "Customer"); }

    /** Hồ sơ khách hàng gắn với tài khoản đăng nhập (null nếu chưa có). */
    public Customer findByUserId(int userId) {
        return read(s -> s.createQuery("from Customer c where c.user.userId = :u", Customer.class)
                .setParameter("u", userId).setMaxResults(1).uniqueResult());
    }
}
