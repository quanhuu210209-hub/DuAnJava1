package Servlet.admin;

import DAO.admin.SystemSettingDAO;
import Model.admin.SystemSetting;
import Servlet.common.ServletUtils;
import Util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** Cấu hình hệ thống (Y33). URL: /admin/setting?action=list|new|edit&key=  (POST: save | delete) */
@WebServlet("/admin/setting")
public class SystemSettingServlet extends HttpServlet {

    private static final String LIST = "/admin/setting/list.jsp";
    private static final String FORM = "/admin/setting/form.jsp";
    private static final String URL  = "/admin/setting";
    private final SystemSettingDAO dao = new SystemSettingDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        switch (action) {
            case "new":
                req.setAttribute("setting", new SystemSetting());
                req.setAttribute("isNew", true);
                ServletUtils.forward(req, resp, FORM);
                break;
            case "edit":
                SystemSetting found = dao.findById(ServletUtils.trim(req.getParameter("key")));
                if (found == null) {
                    ServletUtils.setFlash(req, "danger", "Không tìm thấy cấu hình");
                    ServletUtils.redirect(req, resp, URL);
                    return;
                }
                req.setAttribute("setting", found);
                req.setAttribute("isNew", false);
                ServletUtils.forward(req, resp, FORM);
                break;
            default:
                ServletUtils.loadFlash(req);
                req.setAttribute("settings", dao.findAll());
                ServletUtils.forward(req, resp, LIST);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = ServletUtils.trim(req.getParameter("action"));
        if ("delete".equals(action)) {
            String key = ServletUtils.trim(req.getParameter("key"));
            if (dao.delete(key)) ServletUtils.setFlash(req, "success", "Đã xóa cấu hình");
            else ServletUtils.setFlash(req, "danger", "Xóa thất bại, vui lòng thử lại");
            ServletUtils.redirect(req, resp, URL);
            return;
        }

        boolean isNew = "1".equals(ServletUtils.trim(req.getParameter("isNew")));
        SystemSetting st = new SystemSetting();
        st.setSettingKey(ServletUtils.trim(req.getParameter("settingKey")));
        st.setSettingValue(ServletUtils.trim(req.getParameter("settingValue")));
        st.setDescription(ServletUtils.trim(req.getParameter("description")));

        Validator v = new Validator()
                .required("settingKey", st.getSettingKey(), "Mã cấu hình")
                .maxLength("settingKey", st.getSettingKey(), 100, "Mã cấu hình")
                .pattern("settingKey", st.getSettingKey(), "[A-Za-z0-9_.]+", "Mã cấu hình chỉ gồm chữ, số, dấu chấm, gạch dưới")
                .required("settingValue", st.getSettingValue(), "Giá trị")
                .maxLength("settingValue", st.getSettingValue(), 500, "Giá trị")
                .maxLength("description", st.getDescription(), 255, "Mô tả");
        if (v.isValid() && isNew && dao.keyExists(st.getSettingKey()))
            v.error("settingKey", "Mã cấu hình này đã tồn tại");

        if (!v.isValid()) {
            req.setAttribute("errors", v.getErrors());
            req.setAttribute("setting", st);
            req.setAttribute("isNew", isNew);
            ServletUtils.forward(req, resp, FORM);
            return;
        }

        if (st.getDescription().isEmpty()) st.setDescription(null);
        int userId = ServletUtils.currentUser(req).getUserId();
        boolean ok = isNew ? dao.insert(st, userId) : dao.update(st, userId);
        ServletUtils.setFlash(req, ok ? "success" : "danger",
                ok ? "Đã lưu cấu hình" : "Lưu thất bại, vui lòng thử lại");
        ServletUtils.redirect(req, resp, URL);
    }
}