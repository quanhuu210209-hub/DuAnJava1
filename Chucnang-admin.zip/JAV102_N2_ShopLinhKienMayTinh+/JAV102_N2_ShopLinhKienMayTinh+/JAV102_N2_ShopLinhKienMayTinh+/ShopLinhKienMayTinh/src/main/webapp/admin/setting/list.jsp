<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cấu hình hệ thống — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Cấu hình hệ thống</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header"><span></span><a href="${pageContext.request.contextPath}/admin/setting?action=new" class="btn-solid">+ Thêm cấu hình</a></div>
    <div class="table-card"><table>
        <thead><tr><th>Mã</th><th>Giá trị</th><th>Mô tả</th><th>Cập nhật lúc</th><th>Người cập nhật</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="st" items="${settings}">
            <tr>
                <td><c:out value="${st.settingKey}"/></td>
                <td><c:out value="${st.settingValue}"/></td>
                <td><c:out value="${st.description}"/></td>
                <td><t:dt value="${st.updatedAt}"/></td>
                <td><c:out value="${st.updatedBy.fullName}"/></td>
                <td>
                    <a href="${pageContext.request.contextPath}/admin/setting?action=edit&key=${st.settingKey}" class="btn-xs ghost">Sửa</a>
                    <form method="post" action="${pageContext.request.contextPath}/admin/setting" class="inline"
                          onsubmit="return confirm('Xóa cấu hình này?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="key" value="${st.settingKey}">
                        <button type="submit" class="btn-xs danger">Xóa</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty settings}"><tr><td colspan="6">Chưa có cấu hình nào.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>