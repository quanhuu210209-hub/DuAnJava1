<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>

<aside class="sidebar">
  <div class="sidebar-logo-badge">
    <span class="logo-badge-box">CT</span>
    <span class="logo-badge-text">CoreTech</span>
    <span class="sidebar-role-tag">Admin</span>
  </div>

  <nav class="sidebar-menu">
    <div class="menu-group">Danh mục hàng hóa</div>
    <a href="${pageContext.request.contextPath}/admin/product" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/admin/product/') ? 'active' : ''}"><span class="icon">📦</span> Sản phẩm</a>
    <a href="${pageContext.request.contextPath}/admin/category" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/admin/category/') ? 'active' : ''}"><span class="icon">🗂</span> Danh mục</a>
    <a href="${pageContext.request.contextPath}/admin/brand" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/admin/brand/') ? 'active' : ''}"><span class="icon">🏷</span> Thương hiệu</a>
    <a href="${pageContext.request.contextPath}/admin/price" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/admin/price/') ? 'active' : ''}"><span class="icon">💲</span> Giá &amp; lịch sử</a>

    <div class="menu-group">Bán hàng</div>
    <a href="${pageContext.request.contextPath}/staff/order" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/staff/order/') ? 'active' : ''}"><span class="icon">🧾</span> Đơn hàng</a>

    <div class="menu-group">Báo cáo</div>
    <a href="${pageContext.request.contextPath}/admin/report" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/admin/report/') ? 'active' : ''}"><span class="icon">📊</span> Doanh thu</a>

    <div class="menu-group">Hệ thống</div>
    <a href="${pageContext.request.contextPath}/admin/branch" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/admin/branch/') ? 'active' : ''}"><span class="icon">🏬</span> Chi nhánh</a>
    <a href="${pageContext.request.contextPath}/admin/user" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/admin/user/') ? 'active' : ''}"><span class="icon">👥</span> Người dùng</a>
    <a href="${pageContext.request.contextPath}/admin/setting" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/admin/setting/') ? 'active' : ''}"><span class="icon">⚙</span> Cấu hình hệ thống</a>
  </nav>

  <div class="sidebar-footer-card">
    <div class="footer-card-identity">
      <span class="footer-card-avatar">${fn:toUpperCase(fn:substring(sessionScope.loginUser.fullName, 0, 1))}</span>
      <div class="footer-card-text">
        <div class="footer-card-name"><c:out value="${sessionScope.loginUser.fullName}"/></div>
        <span class="footer-card-tag">${sessionScope.loginUser.roleCode}</span>
      </div>
    </div>
    <div class="footer-card-divider"></div>
    <div class="footer-card-actions">
      <a href="${pageContext.request.contextPath}/home" class="btn-xs ghost">⬡ Về trang chủ</a>
      <a href="${pageContext.request.contextPath}/logout" class="btn-xs ghost">↩ Đăng xuất</a>
    </div>
  </div>
</aside>