<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Quản lý giá — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Quản lý &amp; điều chỉnh giá</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="get" action="${pageContext.request.contextPath}/admin/price" class="filter-form">
        <input type="text" name="keyword" value="<c:out value='${keyword}'/>" placeholder="Tìm theo tên hoặc SKU">
        <button type="submit">Tìm</button>
    </form>
    <div class="table-card"><table>
        <thead><tr><th>SKU</th><th>Sản phẩm</th><th>Giá hiện tại</th><th>Giá mới</th><th>Lý do</th><th></th></tr></thead>
        <tbody>
        <c:forEach var="p" items="${products}">
            <tr>
                <td><c:out value="${p.sku}"/></td>
                <td><c:out value="${p.productName}"/></td>
                <td><t:money value="${p.price}"/></td>
                <td>
                    <form method="post" action="${pageContext.request.contextPath}/admin/price" class="inline"
                          onsubmit="return confirm('Xác nhận đổi giá sản phẩm này?');">
                        <input type="hidden" name="productId" value="${p.productId}">
                        <input type="text" name="newPrice" inputmode="numeric" style="width:120px"
                               placeholder="Giá mới" data-type="money">
                </td>
                <td>
                        <input type="text" name="reason" style="width:160px" placeholder="Lý do (không bắt buộc)">
                </td>
                <td>
                        <button type="submit" class="btn-xs ghost">Đổi giá</button>
                    </form>
                    <a href="${pageContext.request.contextPath}/admin/price?action=history&id=${p.productId}" class="btn-xs ghost">Lịch sử</a>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty products}"><tr><td colspan="6">Không có sản phẩm nào.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>