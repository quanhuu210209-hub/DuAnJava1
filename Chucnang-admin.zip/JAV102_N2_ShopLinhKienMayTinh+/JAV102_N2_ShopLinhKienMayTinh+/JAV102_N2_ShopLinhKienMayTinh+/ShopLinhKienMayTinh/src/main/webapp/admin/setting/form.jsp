<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cấu hình hệ thống — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>${isNew ? 'Thêm cấu hình' : 'Sửa cấu hình'}</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="post" action="${pageContext.request.contextPath}/admin/setting" data-validate>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="isNew" value="${isNew ? '1' : '0'}">
        <div class="form-row">
            <label for="settingKey">Mã cấu hình *</label>
            <input id="settingKey" name="settingKey" type="text" value="<c:out value='${setting.settingKey}'/>"
                   required maxlength="100" data-label="Mã cấu hình" ${isNew ? '' : 'readonly'}>
            <span class="field-error" data-for="settingKey"><c:out value="${errors.settingKey}"/></span>
        </div>
        <div class="form-row">
            <label for="settingValue">Giá trị *</label>
            <input id="settingValue" name="settingValue" type="text" value="<c:out value='${setting.settingValue}'/>"
                   required maxlength="500" data-label="Giá trị">
            <span class="field-error" data-for="settingValue"><c:out value="${errors.settingValue}"/></span>
        </div>
        <div class="form-row">
            <label for="description">Mô tả</label>
            <input id="description" name="description" type="text" value="<c:out value='${setting.description}'/>"
                   maxlength="255" data-label="Mô tả">
            <span class="field-error" data-for="description"><c:out value="${errors.description}"/></span>
        </div>
        <button type="submit">Lưu</button>
        <a href="${pageContext.request.contextPath}/admin/setting">Hủy</a>
    </form>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>