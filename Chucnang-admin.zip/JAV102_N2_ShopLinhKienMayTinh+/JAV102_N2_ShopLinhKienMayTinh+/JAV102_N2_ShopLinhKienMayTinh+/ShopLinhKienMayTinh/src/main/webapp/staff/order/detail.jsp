<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chi tiết đơn hàng — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/staff.css">
</head>
<body>

<%@ include file="/staff/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Đơn hàng <c:out value="${order.orderCode}"/></h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <p><a href="${pageContext.request.contextPath}/staff/order">&larr; Danh sách đơn</a></p>
    <div class="table-card"><table>
        <tr><th>Trạng thái</th><td><t:orderStatus value="${order.status}"/></td></tr>
        <tr><th>Chi nhánh</th><td><c:out value="${order.branch.branchName}"/></td></tr>
        <tr><th>Kênh bán</th><td><c:out value="${order.channel}"/> / <c:out value="${order.receiveMethod}"/></td></tr>
        <tr><th>Người nhận</th><td><c:out value="${order.receiverName}"/> - <c:out value="${order.receiverPhone}"/></td></tr>
        <tr><th>Địa chỉ giao</th><td><c:out value="${order.shippingAddress}"/></td></tr>
        <tr><th>Thanh toán</th><td><c:out value="${order.paymentStatus}"/></td></tr>
        <tr><th>Ngày tạo</th><td><t:dt value="${order.createdAt}"/></td></tr>
        <c:if test="${order.status == 'Cancelled'}">
            <tr><th>Lý do hủy</th><td><c:out value="${order.cancelReason}"/></td></tr>
        </c:if>
    </table></div>

    <h2>Sản phẩm</h2>
    <div class="table-card"><table>
        <thead><tr><th>Sản phẩm</th><th>Số lượng</th><th>Đơn giá</th><th>Thành tiền</th></tr></thead>
        <tbody>
        <c:forEach var="d" items="${order.details}">
            <tr>
                <td><c:out value="${d.product.productName}"/></td>
                <td>${d.quantity}</td>
                <td><t:money value="${d.unitPrice}"/></td>
                <td><t:money value="${d.lineTotal}"/></td>
            </tr>
        </c:forEach>
        </tbody>
        <tfoot>
            <tr><th colspan="3">Phí vận chuyển</th><td><t:money value="${order.shippingFee}"/></td></tr>
            <tr><th colspan="3">Tổng cộng</th><td><t:money value="${order.totalAmount}"/></td></tr>
        </tfoot>
    </table></div>

    <c:if test="${not empty nextStatuses}">
        <h2>Cập nhật trạng thái</h2>
        <c:forEach var="ns" items="${nextStatuses}">
            <form method="post" action="${pageContext.request.contextPath}/staff/order" class="inline">
                <input type="hidden" name="action" value="status">
                <input type="hidden" name="id" value="${order.orderId}">
                <input type="hidden" name="status" value="${ns}">
                <button type="submit">Chuyển sang: <t:orderStatus value="${ns}"/></button>
            </form>
        </c:forEach>
    </c:if>

    <c:if test="${order.status == 'Pending' or order.status == 'Paid'}">
        <h2>Hủy đơn</h2>
        <form method="post" action="${pageContext.request.contextPath}/staff/order" data-validate onsubmit="return confirm('Hủy đơn hàng này?');">
            <input type="hidden" name="action" value="cancel">
            <input type="hidden" name="id" value="${order.orderId}">
            <div class="form-row">
                <label for="reason">Lý do hủy *</label>
                <input id="reason" name="reason" type="text" required maxlength="255" data-label="Lý do hủy">
                <span class="field-error" data-for="reason"></span>
            </div>
            <button type="submit">Hủy đơn</button>
        </form>
    </c:if>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>
