<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>

<aside class="sidebar">
  <div class="sidebar-logo-badge">
    <span class="logo-badge-box">CT</span>
    <span class="logo-badge-text">CoreTech</span>
    <span class="sidebar-role-tag">Nhân viên</span>
  </div>

  <nav class="sidebar-menu">
    <div class="menu-group">Bán hàng</div>
    <a href="${pageContext.request.contextPath}/staff/order" class="nav-item ${fn:startsWith(pageContext.request.servletPath, '/staff/order/') ? 'active' : ''}"><span class="icon">🧾</span> Đơn hàng</a>
  </nav>

  <div class="sidebar-footer-card">
    <div class="footer-card-identity">
      <span class="footer-card-avatar">${fn:toUpperCase(fn:substring(sessionScope.loginUser.fullName, 0, 1))}</span>
      <div class="footer-card-text">
        <div class="footer-card-name"><c:out value="${sessionScope.loginUser.fullName}"/></div>
        <span class="footer-card-tag">${sessionScope.loginUser.roleCode}</span>
      </div>
    </div>
    <div class="footer-card-divider"></div>
    <div class="footer-card-actions">
      <a href="${pageContext.request.contextPath}/home" class="btn-xs ghost">⬡ Về trang chủ</a>
      <a href="${pageContext.request.contextPath}/logout" class="btn-xs ghost">↩ Đăng xuất</a>
    </div>
  </div>
</aside>
