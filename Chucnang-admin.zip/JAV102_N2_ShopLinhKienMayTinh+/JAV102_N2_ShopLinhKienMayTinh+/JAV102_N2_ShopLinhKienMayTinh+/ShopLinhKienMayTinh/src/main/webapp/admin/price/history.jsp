<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Lịch sử giá — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Lịch sử giá — <c:out value="${product.productName}"/></h1>
    </div>
  </div>

  <div class="content">
    <div class="page-header"><span></span><a href="${pageContext.request.contextPath}/admin/price" class="btn-xs ghost">&larr; Quay lại danh sách</a></div>
    <div class="table-card"><table>
        <thead><tr><th>Thời gian</th><th>Giá cũ</th><th>Giá mới</th><th>Người đổi</th><th>Lý do</th></tr></thead>
        <tbody>
        <c:forEach var="h" items="${history}">
            <tr>
                <td><t:dt value="${h.changedAt}"/></td>
                <td><t:money value="${h.oldPrice}"/></td>
                <td><t:money value="${h.newPrice}"/></td>
                <td><c:out value="${h.changedBy.fullName}"/></td>
                <td><c:out value="${h.reason}"/></td>
            </tr>
        </c:forEach>
        <c:if test="${empty history}"><tr><td colspan="5">Sản phẩm này chưa đổi giá lần nào.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>