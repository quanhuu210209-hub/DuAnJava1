<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sản phẩm — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Quản lý sản phẩm</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header"><span></span><a href="${pageContext.request.contextPath}/admin/product?action=new" class="btn-solid">+ Thêm sản phẩm</a></div>
    <form method="get" action="${pageContext.request.contextPath}/admin/product" class="filter-form">
        <input type="text" name="keyword" value="<c:out value='${keyword}'/>" placeholder="Tìm theo tên hoặc SKU">
        <select name="categoryId">
            <option value="">-- Danh mục --</option>
            <c:forEach var="c" items="${categories}">
                <option value="${c.categoryId}" ${categoryId == c.categoryId ? 'selected' : ''}><c:out value="${c.categoryName}"/></option>
            </c:forEach>
        </select>
        <select name="brandId">
            <option value="">-- Thương hiệu --</option>
            <c:forEach var="b" items="${brands}">
                <option value="${b.brandId}" ${brandId == b.brandId ? 'selected' : ''}><c:out value="${b.brandName}"/></option>
            </c:forEach>
        </select>
        <button type="submit">Lọc</button>
    </form>
    <div class="table-card"><table>
        <thead><tr><th>ID</th><th>SKU</th><th>Tên sản phẩm</th><th>Danh mục</th><th>Thương hiệu</th><th>Giá</th><th>Tồn kho</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="p" items="${products}">
            <tr>
                <td>${p.productId}</td>
                <td><c:out value="${p.sku}"/></td>
                <td><c:out value="${p.productName}"/></td>
                <td><c:out value="${p.category.categoryName}"/></td>
                <td><c:out value="${p.brand.brandName}"/></td>
                <td><t:money value="${p.price}"/></td>
                <td>${p.stock}</td>
                <td>${p.status == 'Active' ? 'Đang bán' : (p.status == 'Hidden' ? 'Ẩn' : 'Ngừng kinh doanh')}</td>
                <td>
                    <a href="${pageContext.request.contextPath}/admin/product?action=edit&id=${p.productId}" class="btn-xs ghost">Sửa</a>
                    <c:if test="${p.status != 'Discontinued'}">
                        <form method="post" action="${pageContext.request.contextPath}/admin/product" class="inline"
                              onsubmit="return confirm('Ngừng kinh doanh sản phẩm này?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="${p.productId}">
                            <button type="submit">Ngừng KD</button>
                        </form>
                    </c:if>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty products}"><tr><td colspan="9">Không có sản phẩm.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>
