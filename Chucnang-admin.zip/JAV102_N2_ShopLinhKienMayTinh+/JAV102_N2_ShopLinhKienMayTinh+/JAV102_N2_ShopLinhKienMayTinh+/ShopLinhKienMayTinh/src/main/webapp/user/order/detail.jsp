<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chi tiết đơn hàng — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/user.css">
</head>
<body>

<%@ include file="/user/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Đơn hàng <c:out value="${order.orderCode}"/></h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <p><a href="${pageContext.request.contextPath}/user/order">&larr; Đơn của tôi</a></p>
    <div class="table-card"><table>
        <tr><th>Trạng thái</th><td><t:orderStatus value="${order.status}"/></td></tr>
        <tr><th>Người nhận</th><td><c:out value="${order.receiverName}"/> - <c:out value="${order.receiverPhone}"/></td></tr>
        <tr><th>Địa chỉ giao</th><td><c:out value="${order.shippingAddress}"/></td></tr>
        <tr><th>Ngày đặt</th><td><t:dt value="${order.createdAt}"/></td></tr>
    </table></div>
    <div class="table-card"><table>
        <thead><tr><th>Sản phẩm</th><th>Số lượng</th><th>Đơn giá</th><th>Thành tiền</th></tr></thead>
        <tbody>
        <c:forEach var="d" items="${order.details}">
            <tr>
                <td><c:out value="${d.product.productName}"/></td>
                <td>${d.quantity}</td>
                <td><t:money value="${d.unitPrice}"/></td>
                <td><t:money value="${d.lineTotal}"/></td>
            </tr>
        </c:forEach>
        </tbody>
        <tfoot><tr><th colspan="3">Tổng cộng</th><td><t:money value="${order.totalAmount}"/></td></tr></tfoot>
    </table></div>
  </div>
</div>
</body>
</html>
