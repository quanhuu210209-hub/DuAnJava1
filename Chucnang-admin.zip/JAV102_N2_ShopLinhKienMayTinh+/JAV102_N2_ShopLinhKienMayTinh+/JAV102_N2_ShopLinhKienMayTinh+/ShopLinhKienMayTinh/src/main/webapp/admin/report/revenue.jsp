<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Báo cáo doanh thu — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Báo cáo doanh thu toàn hệ thống</h1>
    </div>
  </div>

  <div class="content">
    <form method="get" action="${pageContext.request.contextPath}/admin/report" class="filter-form">
        <label>Từ ngày <input type="date" name="from" value="${from}"></label>
        <label>Đến ngày <input type="date" name="to" value="${to}"></label>
        <button type="submit">Xem báo cáo</button>
    </form>

    <div class="page-header">
        <span>Tổng ${orderCount} đơn hoàn tất, doanh thu <t:money value="${grandTotal}"/></span>
        <span></span>
    </div>

    <div class="table-card"><table>
        <thead><tr><th>Ngày</th><th>Số đơn hoàn tất</th><th>Doanh thu</th></tr></thead>
        <tbody>
        <c:forEach var="r" items="${rows}">
            <tr>
                <td>${r.date}</td>
                <td>${r.orderCount}</td>
                <td><t:money value="${r.revenue}"/></td>
            </tr>
        </c:forEach>
        <c:if test="${empty rows}"><tr><td colspan="3">Không có dữ liệu trong khoảng thời gian này.</td></tr></c:if>
        </tbody>
        <tfoot>
            <tr><th>Tổng</th><th>${orderCount}</th><th><t:money value="${grandTotal}"/></th></tr>
        </tfoot>
    </table></div>
  </div>
</div>
</body>
</html>