        // Cart State
        let cartItems = [];

        // Cart Actions
        function updateCartUI() {
            const badge = document.getElementById('cart-badge');
            const drawerCount = document.getElementById('cart-drawer-count');
            const container = document.getElementById('cart-items-container');
            const emptyState = document.getElementById('cart-empty-state');
            const summary = document.getElementById('cart-footer-summary');
            const subtotalEl = document.getElementById('cart-subtotal');
            const totalEl = document.getElementById('cart-total');

            const totalCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
            const totalAmount = cartItems.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

            if (badge) badge.textContent = totalCount;
            if (drawerCount) drawerCount.textContent = totalCount;

            if (cartItems.length === 0) {
                if (container) container.innerHTML = '';
                if (emptyState) emptyState.classList.remove('hidden');
                if (summary) summary.classList.add('opacity-50', 'pointer-events-none');
                if (subtotalEl) subtotalEl.textContent = '0₫';
                if (totalEl) totalEl.textContent = '0₫';
                return;
            }

            if (emptyState) emptyState.classList.add('hidden');
            if (summary) summary.classList.remove('opacity-50', 'pointer-events-none');
            if (subtotalEl) subtotalEl.textContent = formatVND(totalAmount);
            if (totalEl) totalEl.textContent = formatVND(totalAmount);

            if (container) {
                container.innerHTML = cartItems.map(item => `
<div class="flex items-center gap-3 p-3 rounded-2xl bg-surface-container/60 border border-surface-container-high/60">
    ${item.product.image ? `
        <img src="${item.product.image}" alt="${item.product.name}" class="w-16 h-16 object-contain rounded-xl shrink-0 bg-surface-container-high/40 p-1" />
    ` : `
        <div class="w-16 h-16 rounded-xl bg-surface-container-high/40 flex items-center justify-center text-primary shrink-0">
            <span class="material-symbols-outlined text-[24px]">memory</span>
        </div>
    `}
    <div class="flex-1 min-w-0">
        <h4 class="font-headline-sm text-xs text-white font-medium truncate">${item.product.name}</h4>
        <div class="text-xs font-headline-md font-bold text-primary mt-0.5">${formatVND(item.product.price)}</div>
        <div class="flex items-center gap-2 mt-2">
            <div class="inline-flex items-center rounded-lg bg-surface-container-low border border-surface-container-high/80 text-xs">
                <button type="button" onclick="changeCartQty('${item.product.id}', -1)" class="w-6 h-6 flex items-center justify-center text-on-surface hover:text-white">-</button>
                <span class="w-6 text-center font-bold font-label-technical text-white">${item.quantity}</span>
                <button type="button" onclick="changeCartQty('${item.product.id}', 1)" class="w-6 h-6 flex items-center justify-center text-on-surface hover:text-white">+</button>
            </div>
        </div>
    </div>
    <button type="button" onclick="removeFromCart('${item.product.id}')" class="text-on-surface-variant hover:text-red-400 p-1 transition-colors">
        <span class="material-symbols-outlined text-[18px]">delete</span>
    </button>
</div>
`).join('');
            }
        }

        async function loadCart() {
            const items = await cartApi();
            if (items) { cartItems = items; updateCartUI(); }
        }

        async function addToCart(prod, qty = 1) {
            if (!requireCustomer()) return false;
            const items = await cartApi('add', prod.id, qty);
            if (!items) return false;
            cartItems = items;
            updateCartUI();
            showToast(`Đã thêm "${prod.name}" vào giỏ hàng!`);
            return true;
        }

        async function changeCartQty(productId, delta) {
            const item = cartItems.find(i => i.product.id === productId);
            if (!item) return;
            const items = await cartApi('qty', productId, item.quantity + delta);
            if (items) { cartItems = items; updateCartUI(); }
        }

        async function removeFromCart(productId) {
            const items = await cartApi('remove', productId);
            if (items) {
                cartItems = items;
                updateCartUI();
                showToast("Đã xóa linh kiện khỏi giỏ hàng");
            }
        }

        function openCart() {
            const overlay = document.getElementById('cart-drawer-overlay');
            const panel = document.getElementById('cart-drawer-panel');
            if (!overlay || !panel) return;
            overlay.classList.remove('hidden');
            setTimeout(() => panel.classList.remove('translate-x-full'), 10);
        }

        function closeCart() {
            const overlay = document.getElementById('cart-drawer-overlay');
            const panel = document.getElementById('cart-drawer-panel');
            if (!overlay || !panel) return;
            panel.classList.add('translate-x-full');
            setTimeout(() => overlay.classList.add('hidden'), 300);
        }

        function handleAddToCart(btn) {
            const card = btn.closest('.product-card');
            if (!card) return;
            const prod = {
                id: card.dataset.id,
                name: card.dataset.name,
                price: parseFloat(card.dataset.price) || 0,
                image: card.dataset.image,
                category: card.dataset.category,
                brand: card.dataset.brand
            };
            addToCart(prod, 1);
        }

        // Build cấu hình nằm ở trang riêng /build
        function handleAddToBuilder(btn) {
            const card = btn.closest('.product-card');
            if (card) location.href = APP.ctx + '/build?add=' + encodeURIComponent(card.dataset.id);
        }

        // Auth Modal Interactions
        function openAuthModal(tab = 'login') {
            const modal = document.getElementById('auth-modal');
            if (modal) {
                modal.classList.remove('hidden');
                modal.classList.add('flex');
                switchAuthTab(tab);
            }
        }

        function closeAuthModal() {
            const modal = document.getElementById('auth-modal');
            if (modal) {
                modal.classList.add('hidden');
                modal.classList.remove('flex');
            }
        }

        function switchAuthTab(tab) {
            const loginBtn = document.getElementById('tab-login-btn');
            const regBtn = document.getElementById('tab-register-btn');
            const loginForm = document.getElementById('login-form');
            const regForm = document.getElementById('register-form');

            if (tab === 'login') {
                if (loginBtn) loginBtn.className = "flex-1 py-2 text-xs font-label-technical uppercase tracking-wider rounded-lg font-bold bg-primary text-on-primary transition-all shadow-sm";
                if (regBtn) regBtn.className = "flex-1 py-2 text-xs font-label-technical uppercase tracking-wider rounded-lg font-medium text-on-surface-variant hover:text-white transition-all";
                if (loginForm) loginForm.classList.remove('hidden');
                if (regForm) regForm.classList.add('hidden');
            } else {
                if (regBtn) regBtn.className = "flex-1 py-2 text-xs font-label-technical uppercase tracking-wider rounded-lg font-bold bg-primary text-on-primary transition-all shadow-sm";
                if (loginBtn) loginBtn.className = "flex-1 py-2 text-xs font-label-technical uppercase tracking-wider rounded-lg font-medium text-on-surface-variant hover:text-white transition-all";
                if (regForm) regForm.classList.remove('hidden');
                if (loginForm) loginForm.classList.add('hidden');
            }
        }

        // DOM Event Listeners
        document.addEventListener('DOMContentLoaded', () => {
            updateCartUI();
            // Giỏ hàng lưu trong DB: khách đăng nhập thì tải giỏ về; ?cart=1 (từ trang Build) thì mở luôn ngăn giỏ
            if (APP.role === 'CUSTOMER') {
                loadCart().then(() => {
                    if (new URLSearchParams(location.search).get('cart') === '1') openCart();
                });
            }

            // Cart Drawer
            const openCartBtn = document.getElementById('open-cart-btn');
            const closeCartBtn = document.getElementById('close-cart-btn');
            const cartOverlay = document.getElementById('cart-drawer-overlay');
            const cartEmptyShopBtn = document.getElementById('cart-empty-shop-btn');
            const checkoutBtn = document.getElementById('cart-checkout-btn');

            if (openCartBtn) openCartBtn.addEventListener('click', openCart);
            if (closeCartBtn) closeCartBtn.addEventListener('click', closeCart);
            if (cartOverlay) {
                cartOverlay.addEventListener('click', (e) => {
                    if (e.target === cartOverlay) closeCart();
                });
            }
            if (cartEmptyShopBtn) {
                cartEmptyShopBtn.addEventListener('click', () => {
                    closeCart();
                    const catSec = document.getElementById('catalog-section');
                    if (catSec) catSec.scrollIntoView({ behavior: 'smooth' });
                });
            }
            if (checkoutBtn) {
                checkoutBtn.addEventListener('click', () => {
                    if (cartItems.length === 0) return;
                    showToast("Tính năng đặt hàng trực tuyến đang đồng bộ dữ liệu chi nhánh!", "info");
                });
            }

            // Các nút Build cấu hình -> sang trang /build
            ['open-builder-btn', 'hero-builder-btn', 'trigger-builder-catalog-btn', 'cta-builder-btn'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.addEventListener('click', () => { location.href = APP.ctx + '/build'; });
            });

            // Auth Modal
            const openLoginBtn = document.getElementById('open-login-btn');
            const openRegisterBtn = document.getElementById('open-register-btn');
            const closeAuthBtn = document.getElementById('close-auth-btn');
            const authModal = document.getElementById('auth-modal');
            const tabLoginBtn = document.getElementById('tab-login-btn');
            const tabRegisterBtn = document.getElementById('tab-register-btn');

            if (openLoginBtn) openLoginBtn.addEventListener('click', () => openAuthModal('login'));
            if (openRegisterBtn) openRegisterBtn.addEventListener('click', () => openAuthModal('register'));

            if (closeAuthBtn) closeAuthBtn.addEventListener('click', closeAuthModal);
            if (authModal) {
                authModal.addEventListener('click', (e) => {
                    if (e.target === authModal) closeAuthModal();
                });
            }
            if (tabLoginBtn) tabLoginBtn.addEventListener('click', () => switchAuthTab('login'));
            if (tabRegisterBtn) tabRegisterBtn.addEventListener('click', () => switchAuthTab('register'));

            // Mobile Search Toggle
            const toggleMobileSearch = document.getElementById('toggle-mobile-search');
            const mobileSearchBar = document.getElementById('mobile-search-bar');
            if (toggleMobileSearch && mobileSearchBar) {
                toggleMobileSearch.addEventListener('click', () => {
                    mobileSearchBar.classList.toggle('hidden');
                    mobileSearchBar.classList.toggle('flex');
                });
            }

            // Client-Side In-Page Filtering & Sorting
            const inpageSearchInput = document.getElementById('inpage-search-input');
            const priceFilterSelect = document.getElementById('price-filter-select');
            const sortFilterSelect = document.getElementById('sort-filter-select');
            const countText = document.getElementById('filtered-count-text');
            const jsEmptyState = document.getElementById('js-empty-state');
            const resetInpageFilterBtn = document.getElementById('reset-inpage-filter-btn');
            const grid = document.getElementById('products-grid');

            function filterAndSortCards() {
                if (!grid) return;
                const cards = Array.from(grid.querySelectorAll('.product-card'));
                if (cards.length === 0) return;

                const q = inpageSearchInput ? inpageSearchInput.value.toLowerCase().trim() : '';
                const priceFilter = priceFilterSelect ? priceFilterSelect.value : 'all';
                const sortBy = sortFilterSelect ? sortFilterSelect.value : 'featured';

                let visibleCount = 0;

                cards.forEach(card => {
                    const name = (card.dataset.name || '').toLowerCase();
                    const sku = (card.dataset.sku || '').toLowerCase();
                    const brand = (card.dataset.brand || '').toLowerCase();
                    const category = (card.dataset.category || '').toLowerCase();
                    const price = parseFloat(card.dataset.price) || 0;

                    let matchSearch = (q === '') || name.includes(q) || sku.includes(q) || brand.includes(q) || category.includes(q);

                    let matchPrice = true;
                    if (priceFilter === 'under10') matchPrice = (price < 10000000);
                    else if (priceFilter === '10to25') matchPrice = (price >= 10000000 && price <= 25000000);
                    else if (priceFilter === 'above25') matchPrice = (price > 25000000);

                    if (matchSearch && matchPrice) {
                        card.style.display = '';
                        visibleCount++;
                    } else {
                        card.style.display = 'none';
                    }
                });

                // Sorting visible cards
                if (sortBy === 'price-asc') {
                    cards.sort((a, b) => (parseFloat(a.dataset.price) || 0) - (parseFloat(b.dataset.price) || 0));
                    cards.forEach(c => grid.appendChild(c));
                } else if (sortBy === 'price-desc') {
                    cards.sort((a, b) => (parseFloat(b.dataset.price) || 0) - (parseFloat(a.dataset.price) || 0));
                    cards.forEach(c => grid.appendChild(c));
                } else if (sortBy === 'name') {
                    cards.sort((a, b) => (a.dataset.name || '').localeCompare(b.dataset.name || ''));
                    cards.forEach(c => grid.appendChild(c));
                }

                if (countText) {
                    countText.innerHTML = `Đang hiển thị <strong class="text-primary font-semibold">${visibleCount}</strong> / ${cards.length} sản phẩm`;
                }

                if (visibleCount === 0 && cards.length > 0) {
                    if (jsEmptyState) jsEmptyState.classList.remove('hidden');
                } else {
                    if (jsEmptyState) jsEmptyState.classList.add('hidden');
                }
            }

            if (inpageSearchInput) {
                inpageSearchInput.addEventListener('input', filterAndSortCards);
            }
            if (priceFilterSelect) {
                priceFilterSelect.addEventListener('change', filterAndSortCards);
            }
            if (sortFilterSelect) {
                sortFilterSelect.addEventListener('change', filterAndSortCards);
            }
            if (resetInpageFilterBtn) {
                resetInpageFilterBtn.addEventListener('click', () => {
                    if (inpageSearchInput) inpageSearchInput.value = '';
                    if (priceFilterSelect) priceFilterSelect.value = 'all';
                    if (sortFilterSelect) sortFilterSelect.value = 'featured';
                    filterAndSortCards();
                });
            }
        });
