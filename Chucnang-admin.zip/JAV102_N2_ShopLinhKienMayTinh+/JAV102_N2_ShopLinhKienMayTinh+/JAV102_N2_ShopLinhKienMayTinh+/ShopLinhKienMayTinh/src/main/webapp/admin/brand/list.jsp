<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chi nhánh — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Chi nhánh</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <div class="page-header"><span></span><a href="${pageContext.request.contextPath}/admin/branch?action=new" class="btn-solid">+ Thêm chi nhánh</a></div>
    <div class="table-card"><table>
        <thead><tr><th>ID</th><th>Tên chi nhánh</th><th>Địa chỉ</th><th>Điện thoại</th><th>Quản lý</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="b" items="${branches}">
            <tr>
                <td>${b.branchId}</td>
                <td><c:out value="${b.branchName}"/></td>
                <td><c:out value="${b.address}"/></td>
                <td><c:out value="${b.phone}"/></td>
                <td><c:out value="${b.managerUser.fullName}"/></td>
                <td>${b.active ? 'Đang hoạt động' : 'Ẩn'}</td>
                <td>
                    <a href="${pageContext.request.contextPath}/admin/branch?action=edit&id=${b.branchId}" class="btn-xs ghost">Sửa</a>
                    <form method="post" action="${pageContext.request.contextPath}/admin/branch" class="inline"
                          onsubmit="return confirm('Xóa chi nhánh này?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="${b.branchId}">
                        <button type="submit" class="btn-xs danger">Xóa</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty branches}"><tr><td colspan="7">Chưa có chi nhánh.</td></tr></c:if>
        </tbody>
    </table></div>
  </div>
</div>
</body>
</html>