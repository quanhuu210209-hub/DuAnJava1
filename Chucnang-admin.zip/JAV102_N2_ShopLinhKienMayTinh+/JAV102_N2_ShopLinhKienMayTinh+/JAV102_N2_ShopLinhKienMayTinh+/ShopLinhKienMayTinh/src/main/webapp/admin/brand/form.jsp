<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<c:set var="isNew" value="${branch.branchId == 0}"/>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chi nhánh — CoreTech</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/admin.css">
</head>
<body>

<%@ include file="/admin/sidebar.jsp" %>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>${isNew ? 'Thêm chi nhánh' : 'Sửa chi nhánh'}</h1>
    </div>
  </div>

  <div class="content">
    <c:if test="${not empty flashMessage}">
      <div class="alert alert-${flashType}"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="post" action="${pageContext.request.contextPath}/admin/branch" data-validate>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="branchId" value="${branch.branchId}">
        <div class="form-row">
            <label for="branchName">Tên chi nhánh *</label>
            <input id="branchName" name="branchName" type="text" value="<c:out value='${branch.branchName}'/>"
                   required maxlength="150" data-label="Tên chi nhánh">
            <span class="field-error" data-for="branchName"><c:out value="${errors.branchName}"/></span>
        </div>
        <div class="form-row">
            <label for="address">Địa chỉ *</label>
            <input id="address" name="address" type="text" value="<c:out value='${branch.address}'/>"
                   required maxlength="300" data-label="Địa chỉ">
            <span class="field-error" data-for="address"><c:out value="${errors.address}"/></span>
        </div>
        <div class="form-row">
            <label for="phone">Điện thoại</label>
            <input id="phone" name="phone" type="text" value="<c:out value='${branch.phone}'/>"
                   maxlength="20" data-label="Điện thoại">
            <span class="field-error" data-for="phone"><c:out value="${errors.phone}"/></span>
        </div>
        <div class="form-row">
            <label for="managerUserId">Quản lý chi nhánh</label>
            <select id="managerUserId" name="managerUserId">
                <option value="0">-- Không chọn --</option>
                <c:forEach var="u" items="${users}">
                    <option value="${u.userId}" ${branch.managerUser.userId == u.userId ? 'selected' : ''}>
                        <c:out value="${u.fullName}"/> (${u.role.roleCode})
                    </option>
                </c:forEach>
            </select>
        </div>
        <div class="form-row">
            <label><input type="checkbox" name="active" ${branch.active ? 'checked' : ''}> Đang hoạt động</label>
        </div>
        <button type="submit">Lưu</button>
        <a href="${pageContext.request.contextPath}/admin/branch">Hủy</a>
    </form>
  </div>
</div>
<script src="${pageContext.request.contextPath}/assets/js/common/validate.js"></script>
</body>
</html>